import { secrets } from "base44:runtime";

// Complete customer notification system for Malayali Cafe. One call fans a
// single order event out to Push + SMS + WhatsApp + Email, honouring per-customer
// channel preferences, preventing duplicates per (order, status, channel),
// and writing a delivery log for every attempt. Each channel is fully
// isolated — one failing channel never blocks the others, and no channel
// ever sends a fake message: when provider credentials are missing the
// attempt is logged as "not_configured" and skipped.
// Imported by create_checkout / refresh_order_status / updateOrderStatus.

const RESTAURANT_NAME = "Malayali Cafe";
const APP_URL = "https://malayalis-taste-hub.base44.app";

export const CUSTOMER_STATUS_LABELS = {
  received: "Order Received",
  payment_confirmed: "Order Accepted",
  preparing: "Preparing",
  ready: "Ready",
  out_for_delivery: "Out for Delivery",
  delivered: "Delivered",
  completed: "Order Complete",
  cancelled: "Order Cancelled",
};

const STATUS_MESSAGES = {
  received: "We have received your order and sent it to the kitchen.",
  payment_confirmed: "Your order has been accepted and your payment is confirmed.",
  preparing: "Your food is being freshly prepared.",
  ready: "Your order is ready!",
  out_for_delivery: "Your order is on its way to you.",
  delivered: "Your order has been delivered. Enjoy your meal!",
  completed: "Thank you for ordering from Malayali Cafe!",
  cancelled: "Your order has been cancelled. Contact us if you have any questions.",
};

// --- Validation -----------------------------------------------------------

export function isValidEmail(v) {
  return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(v || "").trim());
}

// Normalizes a mobile number to E.164 (+digits). Returns null when invalid.
export function normalizeMobile(v) {
  const digits = String(v || "").replace(/[\s()\-.]/g, "").replace(/^\+/, "");
  if (!/^\d{7,15}$/.test(digits)) return null;
  return "+" + digits;
}

// --- Order adapters -------------------------------------------------------
// Both order entities normalize to the same customer payload shape.

export function orderToCustomerPayload(order) {
  return {
    order_number: order.order_number,
    customer_name: order.customer_name,
    mobile: order.mobile,
    email: order.customer_email,
    items: order.items || [],
    total: Number(order.total ?? 0),
    address: order.address || "",
    track_url: `${APP_URL}/track/${order.order_number}`,
  };
}

export function syncedOrderToCustomerPayload(o) {
  return {
    order_number: o.order_number,
    customer_name: o.customer_name,
    mobile: o.customer_phone,
    email: o.customer_email,
    items: o.items || [],
    total: Number(o.grand_total ?? 0),
    address: o.delivery_address || "",
    track_url: `${APP_URL}/track/${o.order_number}`,
  };
}

// --- Customer channel preferences ----------------------------------------
// All channels default to enabled; a saved preference record can turn any
// of them off and override the WhatsApp number.

export async function getCustomerPrefs(base44, payload) {
  const defaults = { push: true, sms: true, whatsapp: true, email: true, whatsapp_number: "" };
  try {
    const records = await base44.asServiceRole.entities.CustomerNotificationPref.filter({
      mobile: payload.mobile,
    });
    const pref = records && records[0];
    if (!pref) return defaults;
    return {
      push: pref.push_enabled !== false,
      sms: pref.sms_enabled !== false,
      whatsapp: pref.whatsapp_enabled !== false,
      email: pref.email_enabled !== false,
      whatsapp_number: pref.whatsapp_number || "",
    };
  } catch (e) {
    // Preference lookup must never block notifications.
    return defaults;
  }
}

// --- Delivery log ---------------------------------------------------------

async function logNotification(base44, entry) {
  try {
    await base44.asServiceRole.entities.NotificationLog.create({
      order_number: entry.order_number,
      channel: entry.channel,
      event_status: entry.event_status,
      recipient: entry.recipient || "",
      status: entry.status,
      error_message: entry.error_message || "",
      provider_message_id: entry.provider_message_id || "",
    });
  } catch (e) {
    console.error("notification log write failed:", e?.message || e);
  }
}

// --- Channel senders ------------------------------------------------------

// Twilio REST API for SMS and WhatsApp. Returns { ok, configured?, error?, provider_message_id? }.
async function twilioSend(kind, to, text) {
  const accountSid = secrets.get("TWILIO_ACCOUNT_SID");
  const authToken = secrets.get("TWILIO_AUTH_TOKEN");
  const from = kind === "whatsapp" ? secrets.get("TWILIO_WHATSAPP_FROM") : secrets.get("TWILIO_SMS_FROM");
  if (!accountSid || !authToken || !from) {
    return {
      ok: false,
      configured: false,
      error:
        "Twilio secrets not configured. Required: TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, " +
        (kind === "whatsapp" ? "TWILIO_WHATSAPP_FROM" : "TWILIO_SMS_FROM") +
        ". No message was sent.",
    };
  }
  try {
    const form = new URLSearchParams();
    if (kind === "whatsapp") {
      form.set("From", "whatsapp:+" + String(from).replace(/\D/g, ""));
      form.set("To", "whatsapp:" + to);
    } else {
      form.set("From", from);
      form.set("To", to);
    }
    form.set("Body", text);
    const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`, {
      method: "POST",
      headers: {
        Authorization: "Basic " + btoa(`${accountSid}:${authToken}`),
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: form.toString(),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return { ok: false, error: data?.message || `Twilio responded ${res.status}` };
    return { ok: true, provider_message_id: data.sid || "" };
  } catch (e) {
    return { ok: false, error: e?.message || String(e) };
  }
}

// Native mobile push — sent to the customer's registered app account,
// matched by the email on the order.
async function sendPush(base44, payload, title, body) {
  if (!isValidEmail(payload.email))
    return { ok: false, error: "No valid email on the order to identify the customer's app account." };
  try {
    const users = await base44.asServiceRole.entities.User.filter({ email: payload.email });
    const user = users && users[0];
    if (!user)
      return { ok: false, error: "Customer has no registered app account — push unavailable." };
    await base44.asServiceRole.integrations.Core.SendPushNotification({
      user_id: user.id,
      title,
      content: body,
      action_label: "Track Order",
      action_url: `/track/${payload.order_number}`,
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e?.message || String(e) };
  }
}

function statusEmailHtml(payload, label, message) {
  const rows = (payload.items || [])
    .map((it) => {
      const sub = Number(it.subtotal ?? it.total ?? Number(it.price || 0) * Number(it.quantity || 0));
      return `<tr><td style="padding:8px 0;border-bottom:1px solid #eee;color:#1A322B;">${it.quantity}× ${it.name}</td><td style="padding:8px 0;border-bottom:1px solid #eee;text-align:right;color:#1A322B;">€${sub.toFixed(2)}</td></tr>`;
    })
    .join("");
  return `<div style="font-family:Arial,Helvetica,sans-serif;max-width:520px;margin:0 auto;border:1px solid #AF8B45;border-radius:8px;overflow:hidden;">
  <div style="background:#1A322B;padding:20px;text-align:center;">
    <h1 style="color:#FDFBF7;font-size:20px;margin:0;">Malayali Cafe</h1>
    <p style="color:#AF8B45;font-size:13px;margin:6px 0 0;letter-spacing:1px;text-transform:uppercase;">${label}</p>
  </div>
  <div style="padding:20px;background:#FDFBF7;">
    <p style="font-size:15px;color:#1A322B;margin:0 0 8px;">Hi ${payload.customer_name},</p>
    <p style="font-size:15px;color:#1A322B;margin:0 0 12px;">${message}</p>
    <p style="font-size:13px;color:#1A322B;margin:0 0 8px;"><strong>Order #${payload.order_number}</strong> &middot; Total <strong>&euro;${payload.total.toFixed(2)}</strong></p>
    <table style="width:100%;border-collapse:collapse;font-size:13px;margin:12px 0;">${rows}</table>
    ${payload.address ? `<p style="font-size:12px;color:#777;margin:0 0 12px;">Delivering to: ${payload.address}</p>` : ""}
    <a href="${payload.track_url}" style="display:inline-block;background:#AF8B45;color:#1A322B;padding:12px 24px;border-radius:24px;text-decoration:none;font-weight:bold;font-size:13px;">Track your order</a>
  </div>
</div>`;
}

async function sendEmail(base44, payload, subject, html) {
  try {
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: payload.email,
      subject,
      body: html,
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e?.message || String(e) };
  }
}

// --- Orchestrator ---------------------------------------------------------

// Sends the given order event to all enabled channels. opts.skipChannels
// lets callers suppress a channel that another existing email already covers
// (duplicate protection across flows).
export async function notifyCustomerOrderEvent(base44, payload, statusKey, opts = {}) {
  try {
    const label = CUSTOMER_STATUS_LABELS[statusKey];
    const message = STATUS_MESSAGES[statusKey];
    if (!label || !message) return;
    const skipChannels = Array.isArray(opts.skipChannels) ? opts.skipChannels : [];

    const prefs = await getCustomerPrefs(base44, payload);
    const mobile = normalizeMobile(payload.mobile);
    // WhatsApp defaults to the order's mobile number unless the customer
    // saved a different WhatsApp number in their preferences.
    const whatsappNumber = normalizeMobile(prefs.whatsapp_number || payload.mobile);
    const emailValid = isValidEmail(payload.email);

    // Duplicate protection: if this (order, status) was already processed on
    // a channel, it is never sent again there.
    let alreadyProcessed = [];
    try {
      const logs = await base44.asServiceRole.entities.NotificationLog.filter({
        order_number: payload.order_number,
        event_status: statusKey,
      });
      alreadyProcessed = (logs || []).map((l) => l.channel);
    } catch (e) {
      // ignore — proceed without dedupe protection rather than dropping the event
    }

    const shortText =
      `${RESTAURANT_NAME}: ${label} — Order #${payload.order_number}. ` +
      `${message} Total €${payload.total.toFixed(2)}. Track: ${payload.track_url}`;
    const title = `${RESTAURANT_NAME}: ${label}`;

    const channels = [
      {
        channel: "push",
        recipient: payload.email || "",
        enabled: prefs.push,
        valid: emailValid,
        invalidReason: "No valid email on the order to identify the customer's app account.",
        run: () => sendPush(base44, payload, title, `Order #${payload.order_number} — ${message}`),
      },
      {
        channel: "sms",
        recipient: mobile || payload.mobile || "",
        enabled: prefs.sms,
        valid: !!mobile,
        invalidReason: "Invalid mobile number.",
        run: () => twilioSend("sms", mobile, shortText),
      },
      {
        channel: "whatsapp",
        recipient: whatsappNumber || "",
        enabled: prefs.whatsapp,
        valid: !!whatsappNumber,
        invalidReason: "Invalid WhatsApp number.",
        run: () => twilioSend("whatsapp", whatsappNumber, shortText),
      },
      {
        channel: "email",
        recipient: payload.email || "",
        enabled: prefs.email,
        valid: emailValid,
        invalidReason: "Invalid email address.",
        run: () =>
          sendEmail(base44, payload, `${label} — Order #${payload.order_number} · Malayali Cafe`, statusEmailHtml(payload, label, message)),
      },
    ];

    for (const channel of channels) {
      try {
        if (skipChannels.includes(channel.channel)) continue;
        if (alreadyProcessed.includes(channel.channel)) {
          await logNotification(base44, {
            order_number: payload.order_number,
            channel: channel.channel,
            event_status: statusKey,
            recipient: channel.recipient,
            status: "duplicate_skipped",
            error_message: "Already notified for this order status.",
          });
          continue;
        }
        if (!channel.enabled) {
          await logNotification(base44, {
            order_number: payload.order_number,
            channel: channel.channel,
            event_status: statusKey,
            recipient: channel.recipient,
            status: "disabled",
            error_message: "Disabled by customer notification preference.",
          });
          continue;
        }
        if (!channel.valid) {
          await logNotification(base44, {
            order_number: payload.order_number,
            channel: channel.channel,
            event_status: statusKey,
            recipient: channel.recipient,
            status: "invalid_recipient",
            error_message: channel.invalidReason,
          });
          continue;
        }
        const result = await channel.run();
        await logNotification(base44, {
          order_number: payload.order_number,
          channel: channel.channel,
          event_status: statusKey,
          recipient: channel.recipient,
          status: result.ok ? "sent" : result.configured === false ? "not_configured" : "failed",
          error_message: result.ok ? "" : result.error || "Unknown error",
          provider_message_id: result.provider_message_id || "",
        });
      } catch (e) {
        // Channel isolation: log and move on to the next channel.
        await logNotification(base44, {
          order_number: payload.order_number,
          channel: channel.channel,
          event_status: statusKey,
          recipient: channel.recipient,
          status: "failed",
          error_message: e?.message || String(e),
        });
      }
    }
  } catch (e) {
    console.error("notifyCustomerOrderEvent failed:", e?.message || e);
  }
}