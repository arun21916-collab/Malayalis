import { secrets } from "base44:runtime";

// Shared logic for the two-way order sync between the customer ordering app
// and this restaurant manager app. Imported by receiveOrder / getOrderStatus /
// updateOrderStatus — never duplicated.

export const ORDER_STATUSES = [
  "pending",
  "accepted",
  "preparing",
  "ready",
  "out_for_delivery",
  "delivered",
  "cancelled",
];

export const STATUS_LABELS = {
  pending: "Pending",
  accepted: "Accepted",
  preparing: "Preparing",
  ready: "Ready",
  out_for_delivery: "Out for Delivery",
  delivered: "Delivered",
  cancelled: "Cancelled",
};

export const ORDER_TYPES = ["delivery", "takeaway", "dine_in"];

// Validates the shared API key sent by the customer app's backend.
// The key travels in the `x-api-key` header or the `api_key` body field —
// never from browser JavaScript.
export function checkApiKey(req, body) {
  const expected = secrets.get("CUSTOMER_APP_API_KEY");
  if (!expected) return { configured: false, valid: false };
  const provided = req.headers.get("x-api-key") || (body && body.api_key) || "";
  return { configured: true, valid: provided === expected };
}

// Fire-and-forget sync audit trail.
export function logSync(base44, event, orderRef, detail, actor) {
  return base44.asServiceRole.entities.SyncLog.create({
    event,
    order_ref: orderRef || "",
    detail: detail || "",
    actor: actor || "",
  }).catch((e) => console.error("sync log write failed:", e?.message || e));
}

// Unique order number for orders received from the customer app.
export function generateOrderNumber() {
  return "MS" + Date.now().toString().slice(-7) + Math.floor(Math.random() * 90 + 10);
}

export function normalizeItems(items) {
  return items.map((it) => {
    const quantity = Number(it.quantity);
    const price = Number(it.price);
    const total = Number(it.total);
    return {
      name: String(it.name || "").trim(),
      quantity: Number.isFinite(quantity) ? quantity : 0,
      price: Number.isFinite(price) ? +price.toFixed(2) : 0,
      total: Number.isFinite(total) ? +total.toFixed(2) : +(quantity * price).toFixed(2),
    };
  });
}

// Returns an error message string, or null when the payload is valid.
export function validateOrderPayload(body) {
  if (!body || typeof body !== "object") return "Request body must be a JSON object.";
  if (!body.order_id || !String(body.order_id).trim()) return "order_id is required.";
  if (!body.customer_name || !String(body.customer_name).trim()) return "customer_name is required.";
  if (!body.customer_phone || !String(body.customer_phone).trim()) return "customer_phone is required.";
  if (
    body.customer_email &&
    !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(body.customer_email))
  )
    return "customer_email is not a valid email address.";
  if (!ORDER_TYPES.includes(body.order_type))
    return `order_type must be one of: ${ORDER_TYPES.join(", ")}.`;
  if (!Array.isArray(body.items) || body.items.length === 0)
    return "items must be a non-empty array.";
  for (const it of body.items) {
    if (!it || !it.name || !String(it.name).trim()) return "Each item must have a name.";
    if (!Number.isFinite(Number(it.quantity)) || Number(it.quantity) <= 0)
      return `Item "${it.name}" must have a quantity greater than 0.`;
    if (!Number.isFinite(Number(it.price)) || Number(it.price) < 0)
      return `Item "${it.name}" must have a price of 0 or more.`;
  }
  if (!Number.isFinite(Number(body.grand_total)) || Number(body.grand_total) < 0)
    return "grand_total must be a number of 0 or more.";
  return null;
}

// Builds the database record from a validated payload.
export function buildOrderRecord(body) {
  const num = (v) => (Number.isFinite(Number(v)) ? +Number(v).toFixed(2) : 0);
  return {
    source_order_id: String(body.order_id).trim(),
    customer_name: String(body.customer_name).trim(),
    customer_phone: String(body.customer_phone).trim(),
    customer_email: String(body.customer_email || "").trim().toLowerCase(),
    delivery_address: String(body.delivery_address || "").trim(),
    order_type: body.order_type,
    items: normalizeItems(body.items),
    subtotal: num(body.subtotal),
    delivery_fee: num(body.delivery_fee),
    discount: num(body.discount),
    grand_total: num(body.grand_total),
    payment_method: String(body.payment_method || "unknown"),
    payment_status: String(body.payment_status || "unknown"),
    customer_notes: String(body.customer_notes || ""),
    source_created_at: body.created_at ? String(body.created_at) : "",
    status: "pending",
    status_history: [
      { status: "pending", changed_by: "customer-app", changed_at: new Date().toISOString() },
    ],
  };
}

// Finds a synced order by source order id, order number, or internal id.
export async function findOrderByRef(base44, ref) {
  if (!ref) return null;
  const r = String(ref).trim();
  let found = await base44.asServiceRole.entities.SyncedOrder.filter({ source_order_id: r });
  if (found && found.length > 0) return found[0];
  found = await base44.asServiceRole.entities.SyncedOrder.filter({ order_number: r });
  if (found && found.length > 0) return found[0];
  try {
    return await base44.asServiceRole.entities.SyncedOrder.get(r);
  } catch (e) {
    return null;
  }
}

// ---------------------------------------------------------------------------
// OUTBOUND SYNC (customer-app side of this app): push orders placed in this
// storefront to the restaurant manager app, and pull staff status changes
// back. The API key never leaves the server — the browser only invokes
// backend functions via the SDK.
// ---------------------------------------------------------------------------

export const MANAGER_APP_URL = "https://malayalis-order-sync.base44.app";
const RECEIVE_ENDPOINT = `${MANAGER_APP_URL}/functions/receiveOrder`;
const STATUS_ENDPOINT = `${MANAGER_APP_URL}/functions/getOrderStatus`;

// Maps a manager-app status onto this app's Order status vocabulary.
export const MANAGER_TO_LOCAL_STATUS = {
  // lowercase receiver statuses
  pending: "received",
  new: "received",
  accepted: "payment_confirmed",
  preparing: "preparing",
  ready: "ready",
  out_for_delivery: "out_for_delivery",
  delivered: "delivered",
  cancelled: "cancelled",
};

const LOCAL_PIPELINE = [
  "received",
  "payment_confirmed",
  "preparing",
  "ready",
  "out_for_delivery",
  "delivered",
  "completed",
];

// A remote status only overrides the local one when it moves the order
// forward (or cancels it) — staff changes here are never rolled back.
export function shouldApplyStatus(current, next) {
  if (!next || next === current) return false;
  if (next === "cancelled")
    return !["delivered", "completed", "cancelled"].includes(current);
  const ci = LOCAL_PIPELINE.indexOf(current);
  const ni = LOCAL_PIPELINE.indexOf(next);
  if (ci === -1 || ni === -1) return true;
  return ni > ci;
}

// Builds the exact payload contract expected by receiveOrder.
export function buildOutboundPayload(order) {
  return {
    order_id: order.id,
    customer_name: order.customer_name,
    customer_phone: order.mobile,
    customer_email: order.customer_email,
    // The receiver app requires a non-empty delivery_address even for
    // pickup orders — send a clear placeholder when the customer has none.
    delivery_address: String(order.address || "").trim() || "Pickup — collect at restaurant",
    order_type: order.order_type === "delivery" ? "delivery" : "takeaway",
    // Explicit delivery type flag ("PICKUP" / "DELIVERY") for the receiver
    // app's pickup/delivery categorisation. order_type above must stay in the
    // receiver's own vocabulary (delivery / takeaway) to pass its validation.
    delivery_type: order.order_type === "delivery" ? "DELIVERY" : "PICKUP",
    items: (order.items || []).map((it) => ({
      name: it.name,
      quantity: it.quantity,
      price: it.price,
      total: it.subtotal ?? +(Number(it.price) * Number(it.quantity)).toFixed(2),
    })),
    subtotal: order.subtotal ?? 0,
    delivery_fee: order.delivery_fee ?? 0,
    discount: order.discount ?? 0,
    grand_total: order.total ?? 0,
    total: order.total ?? 0,
    payment_method: order.payment_method,
    payment_status: order.payment_status,
    customer_notes: order.notes || "",
    created_at: order.created_date || new Date().toISOString(),
  };
}

// Pushes a just-placed order to the manager app. Called via waitUntil so a
// sync failure can never block or break checkout. Every attempt is logged.
export async function pushOrderToManager(base44, order) {
  const apiKey = secrets.get("CUSTOMER_APP_API_KEY");
  // Persist the sync outcome on the order itself, so failures stay visible
  // and the push can be retried (see refresh_order_status).
  const setSyncStatus = (status) =>
    base44.asServiceRole.entities.Order.update(order.id, { sync_status: status }).catch((e) =>
      console.error("sync status write failed:", e?.message || e)
    );
  if (!apiKey) {
    await setSyncStatus("failed");
    await logSync(base44, "push_failed", order.order_number, "CUSTOMER_APP_API_KEY secret is not configured", "customer-app");
    return { success: false, error: "CUSTOMER_APP_API_KEY not configured" };
  }
  try {
    const res = await fetch(RECEIVE_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": apiKey },
      body: JSON.stringify(buildOutboundPayload(order)),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      await setSyncStatus("failed");
      await logSync(base44, "push_failed", order.order_number, data?.error || `Manager app responded ${res.status}`, "customer-app");
      return { success: false, error: data?.error || `Manager app responded ${res.status}` };
    }
    await setSyncStatus("synced");
    const receiverRef = data.order_number || data.id || "";
    const refSuffix = receiverRef ? ` (receiver ref: ${receiverRef})` : "";
    await logSync(
      base44,
      "push_sent",
      order.order_number,
      data.duplicate ? `duplicate — already synced${refSuffix}` : `delivered to manager app${refSuffix}`,
      "customer-app"
    );
    return { success: true, duplicate: !!data.duplicate, receiver_ref: receiverRef };
  } catch (e) {
    await setSyncStatus("failed");
    await logSync(base44, "push_failed", order.order_number, e?.message || String(e), "customer-app");
    return { success: false, error: e?.message || String(e) };
  }
}

// Pulls the latest status of one order from the manager app.
// Returns { success: true, status } or { success: false, reason }.
export async function fetchManagerStatus(order) {
  const apiKey = secrets.get("CUSTOMER_APP_API_KEY");
  if (!apiKey) return { success: false, reason: "CUSTOMER_APP_API_KEY not configured" };
  try {
    // The manager app's getOrderStatus endpoint accepts GET with query params.
    const params = new URLSearchParams({
      order_id: order.id,
      customer_email: order.customer_email || "",
      customer_phone: order.mobile || "",
    });
    const res = await fetch(`${STATUS_ENDPOINT}?${params}`, {
      method: "GET",
      headers: { "x-api-key": apiKey },
    });
    if (!res.ok) return { success: false, reason: `Manager app responded ${res.status}` };
    const data = await res.json().catch(() => ({}));
    if (data.error) return { success: false, reason: data.error };
    // Receiver statuses arrive uppercase (e.g. "NEW") — normalize to the
    // lowercase vocabulary used by MANAGER_TO_LOCAL_STATUS.
    const status = data.status ? String(data.status).toLowerCase() : "";
    if (!status) return { success: false, reason: "Malformed response from manager app" };
    return { success: true, status };
  } catch (e) {
    return { success: false, reason: e?.message || String(e) };
  }
}