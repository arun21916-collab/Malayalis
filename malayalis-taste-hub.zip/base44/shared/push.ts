// Shared server-side device push notifications for the restaurant manager.
// Sends a native mobile push to every admin user of the app. Used by
// receiveOrder and create_checkout — always via waitUntil so a push failure
// can never block an order.

export async function notifyManagerPush(base44, alert) {
  try {
    const users = await base44.asServiceRole.entities.User.list();
    const admins = (users || []).filter((u) => u.role === "admin");
    if (admins.length === 0) {
      console.error("notifyManagerPush: no admin users found");
      return;
    }
    await Promise.all(
      admins.map((admin) =>
        base44.asServiceRole.integrations.Core.SendPushNotification({
          user_id: admin.id,
          title: alert.title,
          content: alert.content,
          action_label: alert.action_label || "Open Dashboard",
          action_url: alert.action_url || "/admin",
        }).catch((e) => {
          // One user without a mobile build must not break the others.
          console.error(`push to ${admin.email} failed:`, e?.message || e);
        })
      )
    );
  } catch (e) {
    console.error("notifyManagerPush failed:", e?.message || e);
  }
}

// Alert text for an order placed in this app's storefront (Order entity).
export function storefrontPushAlert(order) {
  const type = order.order_type === "delivery" ? "Delivery" : "Pickup";
  return {
    title: "New order received",
    content: `#${order.order_number} — ${order.customer_name}. ${type}. Total €${Number(order.total || 0).toFixed(2)}.`,
  };
}

// Alert text for an order synced in from the customer app (SyncedOrder entity).
export function syncedPushAlert(order) {
  const type = (order.order_type || "").replace(/_/g, " ");
  return {
    title: "New order from customer app",
    content: `#${order.order_number} — ${order.customer_name}. ${type}. Total €${Number(order.grand_total || 0).toFixed(2)}.`,
  };
}