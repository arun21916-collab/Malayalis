// Shared email module — used by create_checkout (cash orders) and stripe_webhook (card orders).
// Customer-facing emails are sent server-side via the Base44 Core SendEmail integration;
// manager alerts are sent from the connected Gmail account (shared connector) via the
// Gmail API. Credentials and OAuth tokens are never exposed to the frontend.

import { createMimeMessage } from "npm:mimetext@2.0.0";

const RESTAURANT = "MALAYALIS";
const CONTACT_PHONE = "+353 1 234 5678";
const CONTACT_EMAIL = "orders@malayalis.example";
const ADDRESS = "Main Street, Kerala Town, Malabar Coast";

export function defaultSettings() {
  return {
    restaurant_order_email: "",
    delivery_fee: 3,
    cash_payment_enabled: true,
    online_payment_enabled: true,
    contact_phone: CONTACT_PHONE,
    contact_email: CONTACT_EMAIL,
    address: ADDRESS,
    currency: "EUR",
    bank_transfer_enabled: true,
    bank_beneficiary_name: "Arunkumar Mahalingam",
    bank_iban: "LT44 3250 0529 2803 7443",
    bank_bic: "REVOLT21",
    bank_name: "Revolut Bank UAB",
    bank_address: "Konstitucijos ave. 21B, 08130, Vilnius, Lithuania",
    bank_correspondent_bic: "CHASDEFX",
    bank_payment_instructions: "Please include your Order ID as the payment reference when making the bank transfer.",
    bank_proof_max_size_mb: 5,
  };
}

export async function getSettings(base44) {
  try {
    const list = await base44.asServiceRole.entities.Settings.list();
    return { ...defaultSettings(), ...(list[0] || {}) };
  } catch {
    return defaultSettings();
  }
}

function money(n) {
  return "€" + Number(n || 0).toFixed(2);
}

function fmtDate(d) {
  try {
    return new Date(d).toLocaleString("en-IE", {
      dateStyle: "medium",
      timeStyle: "short",
    });
  } catch {
    return String(d);
  }
}

function itemsRows(order) {
  return (order.items || [])
    .map(
      (it) =>
        `<tr><td style="padding:8px 0;border-bottom:1px solid #eee">${it.quantity}× ${it.name}</td>` +
        `<td style="text-align:right;padding:8px 0;border-bottom:1px solid #eee">${money(it.price)}</td>` +
        `<td style="text-align:right;padding:8px 0;border-bottom:1px solid #eee">${money(it.subtotal)}</td></tr>`
    )
    .join("");
}

export async function sendOrderEmails(base44, order) {
  const settings = await getSettings(base44);
  const contactPhone = settings.contact_phone || CONTACT_PHONE;
  const address = settings.address || ADDRESS;

  // 1. Customer confirmation email
  if (order.customer_email) {
    try {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: order.customer_email,
        subject: `MALAYALIS – Order Confirmation #${order.order_number}`,
        body: customerEmail(order, contactPhone, address),
      });
    } catch (e) {
      console.error("Customer email failed:", e.message);
    }
  }

}

// Sends an email from the connected Gmail account via the Gmail API.
// The RFC 2822 message is built with a MIME library so non-ASCII content
// (e.g. "€", en-dashes) is encoded correctly.
export async function sendGmail(base44, { to, subject, html }) {
  const { accessToken } = await base44.asServiceRole.connectors.getConnection("gmail");
  const authHeaders = { Authorization: `Bearer ${accessToken}` };

  const profileRes = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/profile", {
    headers: authHeaders,
  });
  if (!profileRes.ok) throw new Error(`Gmail auth failed (${profileRes.status})`);
  const profile = await profileRes.json();

  const msg = createMimeMessage();
  msg.setSender(profile.emailAddress);
  msg.setTo(to);
  msg.setSubject(subject);
  msg.setMessage("text/html", html);

  const res = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
    method: "POST",
    headers: { ...authHeaders, "Content-Type": "application/json" },
    body: JSON.stringify({ raw: msg.asEncoded() }),
  });
  if (!res.ok) throw new Error(`Gmail send failed (${res.status})`);
}

// Manager alert — sent from Gmail the moment a new order is received, for any
// payment method. Accepts the standard Order field shape; falls back to the
// transactional email service if Gmail is unavailable.
export async function notifyManagerNewOrder(base44, order) {
  const settings = await getSettings(base44);
  const to = settings.restaurant_order_email;
  if (!to) return;
  const subject = `NEW ORDER ALERT – MALAYALIS – #${order.order_number}`;
  const body = restaurantEmail(order, settings.contact_phone || CONTACT_PHONE, settings.address || ADDRESS);
  try {
    await sendGmail(base44, { to, subject, html: body });
  } catch (e) {
    console.error("Gmail alert failed, using fallback:", e.message);
    try {
      await base44.asServiceRole.integrations.Core.SendEmail({ to, subject, body });
    } catch (e2) {
      console.error("Manager alert failed:", e2.message);
    }
  }
}

// Notifies the restaurant that a customer has uploaded bank-transfer payment
// proof and it is ready to verify in the admin dashboard.
export async function notifyProofSubmitted(base44, order) {
  const settings = await getSettings(base44);
  const to = settings.restaurant_order_email;
  if (!to) return;
  try {
    await base44.asServiceRole.integrations.Core.SendEmail({
      to,
      subject: `PROOF SUBMITTED – MALAYALIS – #${order.order_number}`,
      body: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;color:#222">
  <h2 style="color:#1A322B">Payment Proof Submitted – #${order.order_number}</h2>
  <p><strong>Customer:</strong> ${order.customer_name}</p>
  <p><strong>Phone:</strong> ${order.mobile}</p>
  <p><strong>Amount:</strong> ${money(order.total)}</p>
  <p><strong>Payment Reference:</strong> ${order.order_number}</p>
  <p>A customer has uploaded payment proof for a bank transfer order. Please verify it in the admin dashboard and confirm or reject the payment.</p>
  </div>`,
    });
  } catch (e) {
    console.error("Proof notification email failed:", e.message);
  }
}

function customerEmail(order, contactPhone, address) {
  return `<div style="font-family:Georgia,serif;max-width:600px;margin:auto;color:#1A322B">
  <h1 style="color:#1A322B;margin-bottom:0">MALAYALIS</h1>
  <p style="color:#AF8B45;margin-top:4px">The soul of Malabar, served.</p>
  <p>Hi ${order.customer_name},</p>
  <p>Thank you for your order! Your Kerala feast is being prepared.</p>
  <h3 style="color:#AF8B45">Order #${order.order_number}</h3>
  <p><strong>Date:</strong> ${fmtDate(order.created_date)}</p>
  <p><strong>Order type:</strong> ${order.order_type}</p>
  ${
    order.order_type === "delivery" && order.address
      ? `<p><strong>Delivery address:</strong> ${order.address}</p>`
      : ""
  }
  <table style="width:100%;border-collapse:collapse;margin:12px 0">
    <tr><th style="text-align:left;border-bottom:2px solid #AF8B45;padding:8px 0">Item</th>
    <th style="text-align:right;border-bottom:2px solid #AF8B45;padding:8px 0">Price</th>
    <th style="text-align:right;border-bottom:2px solid #AF8B45;padding:8px 0">Subtotal</th></tr>
    ${itemsRows(order)}
  </table>
  <p>Subtotal: ${money(order.subtotal)}</p>
  <p>Delivery fee: ${money(order.delivery_fee)}</p>
  <p style="font-size:18px"><strong>Total: ${money(order.total)}</strong></p>
  <p><strong>Payment method:</strong> ${order.payment_method} &nbsp;·&nbsp; <strong>Payment status:</strong> ${order.payment_status}</p>
  <p><strong>Estimated time:</strong> ${order.estimated_time || ""}</p>
  ${order.notes ? `<p><strong>Notes:</strong> ${order.notes}</p>` : ""}
  <hr style="border:none;border-top:1px solid #eee;margin:20px 0" />
  <p style="color:#1A322B">MALAYALIS · ${address}<br/>Contact: ${contactPhone}</p>
  </div>`;
}

function restaurantEmail(order, contactPhone, address) {
  return `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;color:#222">
  <h2 style="color:#1A322B">NEW ORDER – MALAYALIS – #${order.order_number}</h2>
  <p><strong>Order time:</strong> ${fmtDate(order.created_date)}</p>
  <p><strong>Customer:</strong> ${order.customer_name}</p>
  <p><strong>Phone:</strong> ${order.mobile}</p>
  <p><strong>Email:</strong> ${order.customer_email || "—"}</p>
  <p><strong>Order type:</strong> ${order.order_type}</p>
  ${order.address ? `<p><strong>Delivery address:</strong> ${order.address}</p>` : ""}
  <table style="width:100%;border-collapse:collapse;margin:12px 0">
    <tr><th style="text-align:left;border-bottom:1px solid #ccc;padding:6px 0">Item</th>
    <th style="text-align:right;border-bottom:1px solid #ccc;padding:6px 0">Qty</th>
    <th style="text-align:right;border-bottom:1px solid #ccc;padding:6px 0">Subtotal</th></tr>
    ${(order.items || [])
      .map(
        (it) =>
          `<tr><td style="padding:6px 0">${it.name}</td><td style="text-align:right">${it.quantity}</td><td style="text-align:right">${money(it.subtotal)}</td></tr>`
      )
      .join("")}
  </table>
  <p><strong>Subtotal:</strong> ${money(order.subtotal)} · <strong>Delivery fee:</strong> ${money(order.delivery_fee)} · <strong>Total:</strong> ${money(order.total)}</p>
  <p><strong>Payment method:</strong> ${order.payment_method} · <strong>Payment status:</strong> ${order.payment_status}</p>
  ${order.notes ? `<p><strong>Special instructions:</strong> ${order.notes}</p>` : ""}
  </div>`;
}