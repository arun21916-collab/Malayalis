import { createClientFromRequest } from "npm:@base44/sdk@0.8.40";
import { waitUntil } from "base44:runtime";
import { sendOrderEmails, sendGmail, getSettings } from "../../shared/emails.ts";
import { notifyCustomerOrderEvent, orderToCustomerPayload } from "../../shared/customerNotifications.ts";

// Invoked by the "Bank Proof Verification" workflow when a customer uploads
// bank transfer payment proof (Order.payment_status -> "proof_submitted").
// Verifies the proof automatically with an AI check of the attached image:
//   Success -> payment_status "paid", paid true, status "payment_confirmed",
//              confirmation email + customer notifications on all channels.
//   Failure -> BankAuditLog flag + admin alert email (staff review manually;
//              the order is NOT auto-rejected).
// The admin verify_bank_payment function stays untouched for manual reviews.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const { order_id } = (await req.json().catch(() => ({}))) || {};
    if (!order_id) return Response.json({ error: "Order is required." }, { status: 400 });

    let order;
    try {
      order = await base44.asServiceRole.entities.Order.get(order_id);
    } catch (e) {
      return Response.json({ error: "Order not found." }, { status: 404 });
    }

    // --- Basic state checks ---
    let reason = "";
    if (order.payment_method !== "bank_transfer")
      reason = "Order is not a bank transfer order.";
    else if (!order.payment_proof_url)
      reason = "No payment proof attached.";
    else if (!["proof_submitted", "under_verification"].includes(order.payment_status))
      reason = "Order is not awaiting proof verification.";

    // --- AI verification of the proof image ---
    if (!reason) {
      try {
        const check = await base44.asServiceRole.integrations.Core.InvokeLLM({
          prompt:
            "You are verifying a bank transfer payment proof for a restaurant order. " +
            "Look at the attached image and decide whether it appears to be a genuine bank transfer " +
            "payment confirmation: a screenshot or photo from a banking app or online banking showing " +
            "a COMPLETED transfer (not a pending one, not a request for money). " +
            "Also read the transferred amount as a plain number (use 0 if you cannot read it). " +
            "Briefly explain your decision in the reason field.",
          file_urls: [order.payment_proof_url],
          response_json_schema: {
            type: "object",
            properties: {
              is_payment_receipt: { type: "boolean" },
              amount: { type: "number" },
              reason: { type: "string" },
            },
            required: ["is_payment_receipt", "reason"],
          },
        });
        if (!check.is_payment_receipt)
          reason = check.reason || "The uploaded proof does not look like a bank transfer receipt.";
        else {
          const amt = Number(check.amount);
          if (!amt)
            reason = "The transfer amount could not be read from the proof.";
          else if (amt + 0.01 < Number(order.total))
            reason = `Proof amount (€${amt.toFixed(2)}) is less than the order total (€${Number(order.total).toFixed(2)}).`;
        }
      } catch (e) {
        reason = "Automatic verification is unavailable: " + e.message;
      }
    }

    // --- Failure: flag BankAuditLog + alert the admin ---
    if (reason) {
      waitUntil(
        base44.asServiceRole.entities.BankAuditLog.create({
          action: "bank_proof_verification_failed",
          changes: [{ field: "auto_verification", from: order.payment_status || "", to: reason }],
          performed_by_email: "bank-proof-workflow",
        })
      );
      waitUntil(alertAdmin(base44, order, reason));
      return Response.json({
        verified: false,
        order_number: order.order_number,
        reason,
      });
    }

    // --- Success: mark the order paid + confirmation to the customer ---
    const updated = await base44.asServiceRole.entities.Order.update(order_id, {
      payment_status: "paid",
      paid: true,
      status: "payment_confirmed",
    });
    waitUntil(sendOrderEmails(base44, updated));
    waitUntil(
      notifyCustomerOrderEvent(base44, orderToCustomerPayload(updated), "payment_confirmed", {
        skipChannels: ["email"],
      })
    );
    return Response.json({
      verified: true,
      order_number: order.order_number,
      payment_status: "paid",
    });
  } catch (error) {
    console.error("process_bank_proof error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// Admin alert email for failed automatic verification — sent from the
// connected Gmail account with a fallback to the transactional email service.
async function alertAdmin(base44, order, reason) {
  const settings = await getSettings(base44);
  const to = settings.restaurant_order_email;
  if (!to) return;
  const subject = `VERIFICATION FAILED – MALAYALIS – #${order.order_number}`;
  const body = `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;color:#222">
  <h2 style="color:#9E2A2B">Bank proof verification failed – #${order.order_number}</h2>
  <p><strong>Customer:</strong> ${order.customer_name} (${order.mobile})</p>
  <p><strong>Amount:</strong> €${Number(order.total || 0).toFixed(2)}</p>
  <p><strong>Reason:</strong> ${reason}</p>
  <p>Please review the payment proof in the admin dashboard and confirm or reject the payment manually.</p>
  </div>`;
  try {
    await sendGmail(base44, { to, subject, html: body });
  } catch (e) {
    console.error("Gmail alert failed, using fallback:", e.message);
    try {
      await base44.asServiceRole.integrations.Core.SendEmail({ to, subject, body });
    } catch (e2) {
      console.error("Verification alert failed:", e2.message);
    }
  }
}