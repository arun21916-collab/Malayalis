import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";
import { waitUntil } from "base44:runtime";
import { notifyCustomerOrderEvent, orderToCustomerPayload } from "../../shared/customerNotifications.ts";

// POST /functions/set_order_status — admin only. Updates a customer-facing
// Order's status and fires the customer notification (push, SMS, WhatsApp,
// email) for the new status. Replaces direct client-side entity updates,
// which silently skipped customer notifications.
const ORDER_STATUSES = [
  "received",
  "payment_confirmed",
  "preparing",
  "ready",
  "out_for_delivery",
  "delivered",
  "completed",
  "cancelled",
];

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== "admin")
      return Response.json({ success: false, error: "Admin access required." }, { status: 403 });

    const body = await req.json().catch(() => null);
    if (!body?.order_id || !String(body.order_id).trim())
      return Response.json({ success: false, error: "order_id is required." }, { status: 400 });
    if (!ORDER_STATUSES.includes(body.status))
      return Response.json(
        { success: false, error: `status must be one of: ${ORDER_STATUSES.join(", ")}.` },
        { status: 400 }
      );

    const order = await base44.asServiceRole.entities.Order.get(String(body.order_id).trim());
    if (!order)
      return Response.json({ success: false, error: "Order not found." }, { status: 404 });

    if (order.status === body.status)
      return Response.json({
        success: true,
        order_id: order.id,
        order_number: order.order_number,
        status: order.status,
        message: "Status unchanged.",
      });

    const updated = await base44.asServiceRole.entities.Order.update(order.id, {
      status: body.status,
    });

    // Customer notification on all enabled channels for the new status.
    waitUntil(notifyCustomerOrderEvent(base44, orderToCustomerPayload(updated), body.status));

    return Response.json({
      success: true,
      order_id: updated.id,
      order_number: updated.order_number,
      status: updated.status,
    });
  } catch (error) {
    console.error("set_order_status error:", error);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
}