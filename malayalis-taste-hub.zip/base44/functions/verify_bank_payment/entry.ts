import { createClientFromRequest } from "npm:@base44/sdk@0.8.40";
import { waitUntil } from "base44:runtime";
import { sendOrderEmails } from "../../shared/emails.ts";
import { notifyCustomerOrderEvent, orderToCustomerPayload } from "../../shared/customerNotifications.ts";

// Admin-only — the restaurant verification process for bank transfer orders.
// Actions:
//   "verify"  → payment_status "under_verification"
//   "confirm" → payment_status "paid", paid true, order advances to payment_confirmed
//   "reject"  → payment_status "payment_rejected"
// The customer can never reach "paid" on their own; only this function can.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== "admin")
      return Response.json({ error: "Admin access required." }, { status: 403 });

    const body = await req.json();
    const { order_id, action } = body || {};
    if (!order_id || !["verify", "confirm", "reject"].includes(action))
      return Response.json({ error: "Invalid request." }, { status: 400 });

    let order;
    try {
      order = await base44.asServiceRole.entities.Order.get(order_id);
    } catch (e) {
      return Response.json({ error: "Order not found." }, { status: 404 });
    }
    if (!order) return Response.json({ error: "Order not found." }, { status: 404 });
    if (order.payment_method !== "bank_transfer")
      return Response.json({ error: "This order is not a bank transfer." }, { status: 400 });

    let update;
    if (action === "verify") {
      if (!["proof_submitted", "under_verification"].includes(order.payment_status))
        return Response.json({ error: "Order is not ready for verification." }, { status: 400 });
      update = { payment_status: "under_verification" };
    } else if (action === "confirm") {
      if (!["proof_submitted", "under_verification"].includes(order.payment_status))
        return Response.json({ error: "Order cannot be confirmed at this stage." }, { status: 400 });
      update = { payment_status: "paid", paid: true, status: "payment_confirmed" };
    } else {
      // reject
      if (order.payment_status === "paid")
        return Response.json({ error: "Paid orders cannot be rejected. Use refund instead." }, { status: 400 });
      update = { payment_status: "payment_rejected" };
    }

    const updated = await base44.asServiceRole.entities.Order.update(order_id, update);

    // On confirmation, send the customer + restaurant confirmation emails,
    // then "Order Accepted" notifications on the remaining channels.
    if (action === "confirm") {
      waitUntil(sendOrderEmails(base44, updated));
      waitUntil(
        notifyCustomerOrderEvent(base44, orderToCustomerPayload(updated), "payment_confirmed", {
          skipChannels: ["email"],
        })
      );
    }

    return Response.json({ ok: true, payment_status: update.payment_status });
  } catch (error) {
    console.error("verify_bank_payment error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}