import { createClientFromRequest } from "npm:@base44/sdk@0.8.40";

// Admin-only settings save. Writes are restricted to admins (Settings RLS also
// enforces this), and every change to a bank-detail field is recorded in the
// BankAuditLog entity for a full audit trail.
const BANK_FIELDS = [
  "bank_transfer_enabled",
  "bank_beneficiary_name",
  "bank_iban",
  "bank_bic",
  "bank_name",
  "bank_address",
  "bank_correspondent_bic",
  "bank_payment_instructions",
  "bank_proof_max_size_mb",
];

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== "admin")
      return Response.json({ error: "Admin access required." }, { status: 403 });

    const body = await req.json() || {};

    if (
      body.restaurant_order_email &&
      !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(body.restaurant_order_email)
    )
      return Response.json({ error: "Invalid restaurant order email." }, { status: 400 });

    const list = await base44.asServiceRole.entities.Settings.list();
    const current = list[0];

    // Detect bank-detail changes for the audit log.
    const changes = [];
    if (current) {
      for (const f of BANK_FIELDS) {
        if (body[f] !== undefined) {
          const before = current[f] ?? null;
          const after = body[f];
          if (JSON.stringify(before) !== JSON.stringify(after)) {
            changes.push({ field: f, from: before, to: after });
          }
        }
      }
    }

    const patch = {
      restaurant_order_email: body.restaurant_order_email ?? "",
      delivery_fee: Number(body.delivery_fee) || 0,
      cash_payment_enabled: !!body.cash_payment_enabled,
      online_payment_enabled: !!body.online_payment_enabled,
      bank_transfer_enabled: !!body.bank_transfer_enabled,
      bank_beneficiary_name: body.bank_beneficiary_name ?? "",
      bank_iban: body.bank_iban ?? "",
      bank_bic: body.bank_bic ?? "",
      bank_name: body.bank_name ?? "",
      bank_address: body.bank_address ?? "",
      bank_correspondent_bic: body.bank_correspondent_bic ?? "",
      bank_payment_instructions: body.bank_payment_instructions ?? "",
      bank_proof_max_size_mb: Number(body.bank_proof_max_size_mb) || 5,
      contact_phone: body.contact_phone ?? "",
      contact_email: body.contact_email ?? "",
      address: body.address ?? "",
    };

    let saved;
    if (current) {
      saved = await base44.asServiceRole.entities.Settings.update(current.id, patch);
    } else {
      saved = await base44.asServiceRole.entities.Settings.create(patch);
    }

    if (changes.length > 0) {
      await base44.asServiceRole.entities.BankAuditLog.create({
        action: "update_bank_details",
        changes,
        performed_by_email: user.email || "",
        performed_by_id: user.id || "",
      });
    }

    return Response.json({ ok: true, settings: saved, bank_changes: changes.length });
  } catch (error) {
    console.error("save_settings error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}