import { createClientFromRequest } from "npm:@base44/sdk@0.8.40";
import { secrets } from "base44:runtime";

// Admin-only: refunds a paid card order via Stripe, or cancels any order.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== "admin")
      return Response.json({ error: "Forbidden" }, { status: 403 });

    const { order_id } = await req.json();
    if (!order_id)
      return Response.json({ error: "Order ID required" }, { status: 400 });

    const order = await base44.asServiceRole.entities.Order.get(order_id);
    if (!order) return Response.json({ error: "Order not found" }, { status: 404 });

    // Refund paid card orders through the payment provider
    if (order.payment_method === "card" && order.paid && order.stripe_payment_intent) {
      const res = await fetch("https://api.stripe.com/v1/refunds", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${secrets.get("STRIPE_SECRET_KEY")}`,
          "Content-Type": "application/x-www-form-urlencoded",
          "Stripe-Version": "2025-10-29.clover",
        },
        body: new URLSearchParams({
          payment_intent: order.stripe_payment_intent,
        }).toString(),
      });
      if (!res.ok) {
        const d = await res.json();
        console.error("Stripe refund error:", JSON.stringify(d));
        return Response.json(
          { error: d?.error?.message || "Refund failed" },
          { status: 400 }
        );
      }
    }

    await base44.asServiceRole.entities.Order.update(order_id, {
      status: "cancelled",
      payment_status: order.paid ? "refunded" : order.payment_status,
    });

    return Response.json({ ok: true });
  } catch (error) {
    console.error("refund_order error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}