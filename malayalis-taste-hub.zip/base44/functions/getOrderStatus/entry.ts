import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";
import { checkApiKey, logSync, findOrderByRef, STATUS_LABELS } from "../../shared/orderSync.ts";

// POST /functions/getOrderStatus — lets the customer app securely retrieve the
// latest status of an order by order_id. Two auth paths:
//  1. The customer app's backend, with the shared ORDER_SYNC_API_KEY — must
//     also prove ownership with the matching customer_email or customer_phone.
//  2. A logged-in restaurant admin — may view any order.
export default async function (req) {
  try {
    const body = await req.json().catch(() => null);
    const base44 = createClientFromRequest(req);

    const auth = checkApiKey(req, body);
    let isAdmin = false;
    if (!auth.valid) {
      try {
        const user = await base44.auth.me();
        isAdmin = !!user && user.role === "admin";
      } catch (e) {
        isAdmin = false;
      }
      if (!isAdmin) {
        if (!auth.configured)
          return Response.json(
            { success: false, error: "Order sync is not configured: the ORDER_SYNC_API_KEY secret is missing." },
            { status: 500 }
          );
        return Response.json({ success: false, error: "Invalid API key." }, { status: 401 });
      }
    }

    const ref = body?.order_id || body?.order_number;
    if (!ref || !String(ref).trim())
      return Response.json({ success: false, error: "order_id is required." }, { status: 400 });

    const order = await findOrderByRef(base44, ref);
    if (!order)
      return Response.json({ success: false, error: "Order not found." }, { status: 404 });

    // Customers (API-key callers) may only view their own orders.
    if (!isAdmin) {
      const email = String(body.customer_email || "").trim().toLowerCase();
      const phone = String(body.customer_phone || "").trim();
      const emailMatch = email && order.customer_email && email === order.customer_email;
      const phoneMatch = phone && order.customer_phone && phone === order.customer_phone;
      if (!emailMatch && !phoneMatch) {
        await logSync(
          base44,
          "auth_error",
          order.order_number,
          "Customer identity did not match on getOrderStatus",
          "unknown"
        );
        return Response.json(
          {
            success: false,
            error:
              "You can only view your own orders. Provide the matching customer_email or customer_phone.",
          },
          { status: 403 }
        );
      }
    }

    return Response.json(
      {
        success: true,
        order_id: order.source_order_id,
        order_number: order.order_number,
        status: order.status,
        status_label: STATUS_LABELS[order.status] || order.status,
        payment_status: order.payment_status,
        grand_total: order.grand_total,
        status_history: order.status_history || [],
        updated_at: order.updated_date || order.source_created_at || "",
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("getOrderStatus error:", error);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
}