import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";
import { sendGmail, getSettings } from "../../shared/emails.ts";

// Monthly sales summary — invoked by the "Monthly Sales Summary" scheduled
// workflow on the 1st of every month. Summarizes the PREVIOUS calendar month:
// total sales from completed orders, most popular dishes, and customer
// feedback trends. Sent to the restaurant's order email (Settings).
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));

    // Period: previous calendar month by default; overridable for testing.
    const now = new Date();
    const start = body.start
      ? new Date(body.start)
      : new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const end = body.end ? new Date(body.end) : new Date(now.getFullYear(), now.getMonth(), 1);
    if (isNaN(start) || isNaN(end) || end <= start)
      return Response.json({ error: "Invalid period." }, { status: 400 });

    const inPeriod = (d) => {
      const t = new Date(d).getTime();
      return !isNaN(t) && t >= start.getTime() && t < end.getTime();
    };

    // --- Completed orders in the period ---
    const orders = await base44.asServiceRole.entities.Order.list("-created_date", 1000);
    const completed = orders.filter(
      (o) =>
        (o.status === "completed" || o.status === "delivered") &&
        inPeriod(o.created_date)
    );

    const totalSales = completed.reduce((s, o) => s + Number(o.total ?? 0), 0);
    const deliveryCount = completed.filter((o) => o.order_type === "delivery").length;

    // --- Most popular dishes (by quantity sold) ---
    const dishCount = {};
    for (const o of completed) {
      for (const it of o.items || []) {
        const name = String(it.name || "").trim();
        if (!name) continue;
        dishCount[name] = (dishCount[name] || 0) + Number(it.quantity || 0);
      }
    }
    const topDishes = Object.entries(dishCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);

    // --- Customer feedback trends ---
    const reviews = await base44.asServiceRole.entities.Review.list("-created_date", 1000);
    const periodReviews = reviews.filter((r) => inPeriod(r.created_date));
    const avgRating = periodReviews.length
      ? +(periodReviews.reduce((s, r) => s + Number(r.rating ?? 0), 0) / periodReviews.length).toFixed(1)
      : null;
    const byDish = {};
    for (const r of periodReviews) {
      const dish = String(r.item_name || "").trim();
      if (!dish) continue;
      if (!byDish[dish]) byDish[dish] = { sum: 0, n: 0 };
      byDish[dish].sum += Number(r.rating ?? 0);
      byDish[dish].n += 1;
    }
    const topRated = Object.entries(byDish)
      .map(([dish, v]) => ({ dish, avg: +(v.sum / v.n).toFixed(1), n: v.n }))
      .sort((a, b) => b.avg - a.avg || b.n - a.n)
      .slice(0, 3);
    const quotes = periodReviews
      .filter((r) => String(r.review_text || "").trim())
      .slice(0, 3)
      .map((r) => ({ name: r.customer_name || "Guest", rating: r.rating, text: String(r.review_text).trim() }));

    // --- Email ---
    const settings = await getSettings(base44);
    const to = body.to || settings.restaurant_order_email;
    const fmt = (d) =>
      d.toLocaleDateString("en-IE", { year: "numeric", month: "long" });
    const monthName = fmt(start);

    const dishRows = topDishes
      .map(
        ([name, qty], i) =>
          `<tr><td style="padding:6px 0;border-bottom:1px solid #eee">${i + 1}. ${name}</td><td style="padding:6px 0;border-bottom:1px solid #eee;text-align:right">${qty} sold</td></tr>`
      )
      .join("");
    const ratedRows = topRated
      .map(
        (d) =>
          `<tr><td style="padding:6px 0;border-bottom:1px solid #eee">${d.dish}</td><td style="padding:6px 0;border-bottom:1px solid #eee;text-align:right">${"★".repeat(Math.round(d.avg))} ${d.avg}/5 (${d.n})</td></tr>`
      )
      .join("");
    const quoteHtml = quotes
      .map(
        (q) =>
          `<p style="margin:8px 0;padding:10px;border-left:3px solid #AF8B45;background:#faf7f0;font-size:13px">&ldquo;${q.text.replace(/</g, "&lt;")}&rdquo; — ${q.name}, ${q.rating}/5</p>`
      )
      .join("");

    const html = `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;color:#1A322B">
  <h1 style="color:#1A322B;margin-bottom:0">MALAYALIS</h1>
  <p style="color:#AF8B45;margin-top:4px">Monthly Summary — ${monthName}</p>
  <table style="width:100%;border-collapse:collapse;margin:12px 0">
    <tr><td style="padding:8px 0;border-bottom:2px solid #AF8B45"><strong>Total sales</strong></td>
    <td style="padding:8px 0;border-bottom:2px solid #AF8B45;text-align:right;font-size:18px"><strong>&euro;${totalSales.toFixed(2)}</strong></td></tr>
    <tr><td style="padding:8px 0;border-bottom:1px solid #eee">Completed orders</td>
    <td style="padding:8px 0;border-bottom:1px solid #eee;text-align:right">${completed.length}</td></tr>
    <tr><td style="padding:8px 0;border-bottom:1px solid #eee">Delivery / Pickup</td>
    <td style="padding:8px 0;border-bottom:1px solid #eee;text-align:right">${deliveryCount} / ${completed.length - deliveryCount}</td></tr>
  </table>
  <h3 style="color:#AF8B45">Most popular dishes</h3>
  ${topDishes.length ? `<table style="width:100%;border-collapse:collapse;font-size:14px">${dishRows}</table>` : "<p>No completed orders this month.</p>"}
  <h3 style="color:#AF8B45">Customer feedback</h3>
  <p style="font-size:14px">Average rating: <strong>${avgRating !== null ? avgRating + "/5" : "—"}</strong> from ${periodReviews.length} review${periodReviews.length === 1 ? "" : "s"}.</p>
  ${ratedRows ? `<table style="width:100%;border-collapse:collapse;font-size:14px">${ratedRows}</table>` : ""}
  ${quoteHtml}
  <hr style="border:none;border-top:1px solid #eee;margin:20px 0" />
  <p style="color:#777;font-size:12px">Automated monthly report from your MALAYALIS ordering app.</p>
</div>`;

    const subject = `Monthly Summary – MALAYALIS – ${monthName}`;
    if (to) {
      try {
        await sendGmail(base44, { to, subject, html });
      } catch (e) {
        console.error("Gmail send failed, using fallback:", e.message);
        await base44.asServiceRole.integrations.Core.SendEmail({ to, subject, body: html });
      }
    }

    return Response.json({
      period: { start: start.toISOString(), end: end.toISOString() },
      sent_to: to || null,
      total_sales: +totalSales.toFixed(2),
      completed_orders: completed.length,
      delivery_orders: deliveryCount,
      top_dishes: topDishes.map(([name, qty]) => ({ name, qty })),
      reviews: { count: periodReviews.length, avg_rating: avgRating },
    });
  } catch (error) {
    console.error("monthly_sales_summary error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}