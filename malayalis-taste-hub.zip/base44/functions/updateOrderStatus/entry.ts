import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";
import { waitUntil } from "base44:runtime";
import { logSync, findOrderByRef, ORDER_STATUSES, STATUS_LABELS } from "../../shared/orderSync.ts";
import {
  notifyCustomerOrderEvent,
  syncedOrderToCustomerPayload,
} from "../../shared/customerNotifications.ts";

// POST /functions/updateOrderStatus — restaurant staff only. Requires a
// logged-in admin user, validates the new status, records a full status
// history entry, and logs the change. The customer app picks the change up
// through getOrderStatus.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== "admin")
      return Response.json({ success: false, error: "Admin access required." }, { status: 403 });

    const body = await req.json().catch(() => null);
    if (!body?.order_id || !String(body.order_id).trim())
      return Response.json({ success: false, error: "order_id is required." }, { status: 400 });
    if (!ORDER_STATUSES.includes(body.status))
      return Response.json(
        { success: false, error: `status must be one of: ${ORDER_STATUSES.join(", ")}.` },
        { status: 400 }
      );

    const order = await findOrderByRef(base44, body.order_id);
    if (!order)
      return Response.json({ success: false, error: "Order not found." }, { status: 404 });

    if (order.status === body.status)
      return Response.json({
        success: true,
        order_id: order.source_order_id,
        order_number: order.order_number,
        status: order.status,
        status_label: STATUS_LABELS[order.status] || order.status,
        status_history: order.status_history || [],
        message: "Status unchanged.",
      });

    const history = [
      ...(order.status_history || []),
      { status: body.status, changed_by: user.email || "staff", changed_at: new Date().toISOString() },
    ];
    const updated = await base44.asServiceRole.entities.SyncedOrder.update(order.id, {
      status: body.status,
      status_history: history,
    });
    await logSync(
      base44,
      "status_updated",
      order.order_number,
      `${order.status} -> ${body.status}`,
      user.email || "staff"
    );

    // Status changed → notify the customer on all enabled channels. Manager
    // statuses map onto the customer notification vocabulary.
    const notifyStatusKey =
      body.status === "pending" ? "received" : body.status === "accepted" ? "payment_confirmed" : body.status;
    waitUntil(
      notifyCustomerOrderEvent(base44, syncedOrderToCustomerPayload(updated), notifyStatusKey)
    );

    return Response.json(
      {
        success: true,
        order_id: order.source_order_id,
        order_number: order.order_number,
        status: updated.status,
        status_label: STATUS_LABELS[updated.status] || updated.status,
        status_history: history,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("updateOrderStatus error:", error);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
}