import { createClientFromRequest } from "npm:@base44/sdk@0.8.40";
import { getSettings } from "../../shared/emails.ts";

// Public (no auth) — returns only the non-sensitive settings the storefront needs.
// Bank details are intentionally public (customers need them to make a transfer).
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const s = await getSettings(base44);
    return Response.json({
      delivery_fee: s.delivery_fee ?? 3,
      cash_payment_enabled: !!s.cash_payment_enabled,
      online_payment_enabled: !!s.online_payment_enabled,
      bank_transfer_enabled: !!s.bank_transfer_enabled,
      bank_beneficiary_name: s.bank_beneficiary_name || "",
      bank_iban: s.bank_iban || "",
      bank_bic: s.bank_bic || "",
      bank_name: s.bank_name || "",
      bank_address: s.bank_address || "",
      bank_correspondent_bic: s.bank_correspondent_bic || "",
      bank_payment_instructions: s.bank_payment_instructions || "",
      bank_proof_max_size_mb: s.bank_proof_max_size_mb ?? 5,
      contact_phone: s.contact_phone || "",
      address: s.address || "",
    });
  } catch (e) {
    return Response.json({
      delivery_fee: 3,
      cash_payment_enabled: true,
      online_payment_enabled: true,
      bank_transfer_enabled: true,
      bank_beneficiary_name: "",
      bank_iban: "",
      bank_bic: "",
      bank_name: "",
      bank_address: "",
      bank_correspondent_bic: "",
      bank_payment_instructions: "",
      bank_proof_max_size_mb: 5,
      contact_phone: "",
      address: "",
    });
  }
}