import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";
import { waitUntil } from "base44:runtime";
import { fetchManagerStatus, shouldApplyStatus, MANAGER_TO_LOCAL_STATUS, pushOrderToManager } from "../../shared/orderSync.ts";
import { notifyCustomerOrderEvent, orderToCustomerPayload } from "../../shared/customerNotifications.ts";

// POST /functions/refresh_order_status — customer-app side of the two-way
// sync. Looks up the local order by order_number, asks the restaurant
// manager app for its latest status, and applies it locally when it moves
// the order forward. The caller cannot choose a status — it can only trigger
// a pull for an order that exists in this app's database.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const orderNumber = String(body?.order_number || "").trim();
    if (!orderNumber)
      return Response.json({ success: false, error: "order_number is required." }, { status: 400 });

    const list = await base44.asServiceRole.entities.Order.filter({ order_number: orderNumber });
    const order = list && list[0];
    if (!order)
      return Response.json({ success: false, error: "Order not found." }, { status: 404 });

    // Retry the push to the manager app if it never succeeded (e.g. the
    // receiver was temporarily down when the order was placed).
    // pushOrderToManager records the outcome in sync_status and the sync log.
    if (order.sync_status !== "synced") {
      await pushOrderToManager(base44, order);
    }

    const remote = await fetchManagerStatus(order);
    // Manager app unreachable / order not synced yet → nothing to apply.
    if (!remote.success)
      return Response.json({ success: true, updated: false, reason: remote.reason || "unavailable", status: order.status });

    const mapped = MANAGER_TO_LOCAL_STATUS[remote.status] || null;
    if (!mapped || !shouldApplyStatus(order.status, mapped))
      return Response.json({ success: true, updated: false, status: order.status });

    await base44.asServiceRole.entities.Order.update(order.id, { status: mapped });
    // Status changed by the restaurant → notify the customer on all enabled
    // channels (Push + SMS + WhatsApp + Email). Deduplicated per status.
    waitUntil(notifyCustomerOrderEvent(base44, orderToCustomerPayload(order), mapped));
    return Response.json({ success: true, updated: true, status: mapped });
  } catch (error) {
    console.error("refresh_order_status error:", error);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
}