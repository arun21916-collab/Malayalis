import { createClientFromRequest } from "npm:@base44/sdk@0.8.40";
import { secrets, waitUntil } from "base44:runtime";
import { sendOrderEmails, getSettings, notifyManagerNewOrder } from "../../shared/emails.ts";
import { notifyManagerPush, storefrontPushAlert } from "../../shared/push.ts";
import { notifyCustomerOrderEvent, orderToCustomerPayload } from "../../shared/customerNotifications.ts";
import { pushOrderToManager } from "../../shared/orderSync.ts";

// Server-side order creation + Stripe Checkout session.
// The final amount is ALWAYS calculated from menu prices stored in the database —
// never from amounts sent by the customer's browser.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const {
      items,
      customer_name,
      customer_email,
      mobile,
      order_type,
      address,
      notes,
      payment_method,
    } = body || {};

    // --- Input validation ---
    if (!Array.isArray(items) || items.length === 0)
      return Response.json({ error: "Your cart is empty." }, { status: 400 });
    if (!customer_name || !customer_name.trim())
      return Response.json({ error: "Please enter your full name." }, { status: 400 });
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(customer_email || ""))
      return Response.json({ error: "A valid email address is required." }, { status: 400 });
    if (!mobile || !mobile.trim())
      return Response.json({ error: "A valid mobile number is required." }, { status: 400 });
    if (!["delivery", "pickup"].includes(order_type))
      return Response.json({ error: "Select an order type." }, { status: 400 });
    if (order_type === "delivery" && !address?.trim())
      return Response.json({ error: "A delivery address is required." }, { status: 400 });
    if (!["card", "cash", "bank_transfer"].includes(payment_method))
      return Response.json({ error: "Select a payment method." }, { status: 400 });

    const settings = await getSettings(base44);

    // --- Verify prices server-side from the database ---
    const menu = await base44.asServiceRole.entities.MenuItem.list("display_order", 500);
    const lineItems = [];
    let subtotal = 0;
    for (const ci of items) {
      const mi = menu.find((m) => m.id === ci.id);
      if (!mi)
        return Response.json(
          {
            error: `"${ci.name || "An item in your cart"}" is no longer on the menu. Please remove it from your cart to continue.`,
          },
          { status: 400 }
        );
      if (mi.sold_out || !mi.available)
        return Response.json({ error: `${mi.name} is currently sold out.` }, { status: 400 });
      const qty = Math.max(1, parseInt(ci.quantity, 10) || 1);
      const lineSubtotal = +(Number(mi.price) * qty).toFixed(2);
      subtotal += lineSubtotal;
      lineItems.push({ name: mi.name, price: Number(mi.price), quantity: qty, subtotal: lineSubtotal });
    }
    subtotal = +subtotal.toFixed(2);
    const deliveryFee = order_type === "delivery" ? +(settings.delivery_fee || 0) : 0;
    const discount = 0;
    const total = +Math.max(0, subtotal + deliveryFee - discount).toFixed(2);

    // Unique order ID — also serves as the unique bank transfer payment reference.
    const orderNumber =
      "MLY" + Date.now().toString().slice(-7) + Math.floor(Math.random() * 90 + 10);
    const estimated =
      order_type === "delivery" ? "45–60 minutes" : "20–30 minutes";

    const order = await base44.asServiceRole.entities.Order.create({
      order_number: orderNumber,
      customer_name: customer_name.trim(),
      customer_email: customer_email.trim(),
      mobile: mobile.trim(),
      order_type,
      address: address || "",
      notes: notes || "",
      items: lineItems,
      subtotal,
      delivery_fee: deliveryFee,
      discount,
      total,
      payment_method,
      payment_status: payment_method === "bank_transfer" ? "pending_transfer" : "pending",
      paid: false,
      status: "received",
      sync_status: "pending",
      estimated_time: estimated,
    });

    // Push the new order to the restaurant manager app — non-blocking. The
    // customer order always succeeds even when the receiver app is
    // temporarily unavailable: the failure is logged, the order keeps
    // sync_status "failed", and the push is retried automatically by
    // refresh_order_status.
    waitUntil(pushOrderToManager(base44, order));

    // Native push notification to the manager's phone for every new order.
    waitUntil(notifyManagerPush(base44, storefrontPushAlert(order)));

    // Gmail alert to the restaurant manager for every new order, whatever
    // the payment method. Fire-and-forget as well.
    waitUntil(notifyManagerNewOrder(base44, order));

    // --- Cash on delivery / pickup ---
    if (payment_method === "cash") {
      if (!settings.cash_payment_enabled)
        return Response.json({ error: "Cash payment is not available." }, { status: 400 });
      waitUntil(sendOrderEmails(base44, order));
      // "Order Received" on Push + SMS + WhatsApp. The email channel is
      // skipped here — sendOrderEmails already sends the confirmation email.
      waitUntil(
        notifyCustomerOrderEvent(base44, orderToCustomerPayload(order), "received", {
          skipChannels: ["email"],
        })
      );
      return Response.json({ order_id: order.id, order_number: orderNumber });
    }

    // --- Bank transfer (payment verified manually by restaurant staff) ---
    if (payment_method === "bank_transfer") {
      if (!settings.bank_transfer_enabled)
        return Response.json({ error: "Bank transfer is not available." }, { status: 400 });
      // No confirmation email yet — payment is pending verification by staff.
      // "Order Received" goes out on all 4 channels.
      waitUntil(notifyCustomerOrderEvent(base44, orderToCustomerPayload(order), "received"));
      return Response.json({ order_id: order.id, order_number: orderNumber });
    }

    // --- Online card payment via Stripe Checkout ---
    if (!settings.online_payment_enabled)
      return Response.json({ error: "Online payment is not available." }, { status: 400 });

    const params = new URLSearchParams();
    params.append("mode", "payment");
    params.append("currency", "eur");
    const origin = new URL(req.url).origin;
    params.append("success_url", `${origin}/order-confirmation?order=${order.id}`);
    params.append("cancel_url", `${origin}/checkout?cancelled=1`);
    params.append("client_reference_id", order.id);
    // Pre-fill the customer's email on the Stripe page so it doesn't have to
    // be typed again there.
    params.append("customer_email", customer_email.trim());
    lineItems.forEach((it, i) => {
      params.append(`line_items[${i}][quantity]`, String(it.quantity));
      params.append(`line_items[${i}][price_data][currency]`, "eur");
      params.append(`line_items[${i}][price_data][unit_amount]`, String(Math.round(it.price * 100)));
      params.append(`line_items[${i}][price_data][product_data][name]`, it.name);
    });
    if (deliveryFee > 0) {
      const idx = lineItems.length;
      params.append(`line_items[${idx}][quantity]`, "1");
      params.append(`line_items[${idx}][price_data][currency]`, "eur");
      params.append(`line_items[${idx}][price_data][unit_amount]`, String(Math.round(deliveryFee * 100)));
      params.append(`line_items[${idx}][price_data][product_data][name]`, "Delivery Fee");
    }
    params.append("metadata[order_id]", order.id);
    params.append("metadata[base44_app_id]", secrets.get("BASE44_APP_ID") || "");

    const res = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${secrets.get("STRIPE_SECRET_KEY")}`,
        "Content-Type": "application/x-www-form-urlencoded",
        "Stripe-Version": "2025-10-29.clover",
      },
      body: params.toString(),
    });
    const data = await res.json();
    if (!res.ok) {
      console.error("Stripe session error:", JSON.stringify(data));
      // mark the pending order as failed so it is not left dangling
      await base44.asServiceRole.entities.Order.update(order.id, {
        payment_status: "failed",
      });
      return Response.json(
        { error: data?.error?.message || "Payment setup failed. Please try again." },
        { status: 400 }
      );
    }

    await base44.asServiceRole.entities.Order.update(order.id, {
      stripe_session_id: data.id,
    });

    // "Order Received" goes out on all 4 channels once the session is created.
    waitUntil(notifyCustomerOrderEvent(base44, orderToCustomerPayload(order), "received"));

    return Response.json({ checkout_url: data.url, order_id: order.id });
  } catch (error) {
    console.error("create_checkout error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}