import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";

// POST /functions/delete_account — lets a signed-in user permanently delete
// their own account. Requires an explicit "DELETE" confirmation token so the
// endpoint can never be triggered accidentally. The user record is removed
// with the service role only AFTER verifying the caller's own session.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user)
      return Response.json({ success: false, error: "You must be signed in." }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    if (body?.confirm !== "DELETE")
      return Response.json({ success: false, error: "Confirmation required to delete the account." }, { status: 400 });

    // Delete only the caller's own record — the id comes from their session,
    // never from the request body.
    await base44.asServiceRole.entities.User.delete(user.id);
    console.log(`Account deleted for user ${user.id}`);

    return Response.json({ success: true });
  } catch (error) {
    console.error("delete_account error:", error);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
}