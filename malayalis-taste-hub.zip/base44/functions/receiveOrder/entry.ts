import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";
import { waitUntil } from "base44:runtime";
import { notifyManagerNewOrder } from "../../shared/emails.ts";
import { notifyManagerPush, syncedPushAlert } from "../../shared/push.ts";
import {
  checkApiKey,
  logSync,
  generateOrderNumber,
  validateOrderPayload,
  buildOrderRecord,
} from "../../shared/orderSync.ts";

// POST /functions/receiveOrder — called server-to-server by the customer
// ordering app after a customer places an order. Authenticates with the
// shared ORDER_SYNC_API_KEY secret, validates the payload, rejects
// duplicates, and saves the order with status "pending".
export default async function (req) {
  try {
    const body = await req.json().catch(() => null);
    const base44 = createClientFromRequest(req);

    const auth = checkApiKey(req, body);
    if (!auth.configured) {
      return Response.json(
        {
          success: false,
          error:
            "Order sync is not configured: the ORDER_SYNC_API_KEY secret is missing. Set it in the app's Secrets settings.",
        },
        { status: 500 }
      );
    }
    if (!auth.valid) {
      await logSync(base44, "auth_error", body?.order_id, "Invalid API key on receiveOrder", "unknown");
      return Response.json({ success: false, error: "Invalid API key." }, { status: 401 });
    }

    const validationError = validateOrderPayload(body);
    if (validationError) {
      await logSync(base44, "validation_error", body?.order_id, validationError, "customer-app");
      return Response.json({ success: false, error: validationError }, { status: 400 });
    }

    // Duplicate protection: the same order_id is never saved twice.
    const existing = await base44.asServiceRole.entities.SyncedOrder.filter({
      source_order_id: String(body.order_id).trim(),
    });
    if (existing && existing.length > 0) {
      await logSync(
        base44,
        "duplicate_ignored",
        existing[0].order_number,
        `Duplicate submission of source order ${body.order_id}`,
        "customer-app"
      );
      return Response.json(
        {
          success: true,
          duplicate: true,
          order_id: existing[0].source_order_id,
          order_number: existing[0].order_number,
          status: existing[0].status,
          message: "This order was already received.",
        },
        { status: 200 }
      );
    }

    const record = buildOrderRecord(body);
    const orderNumber = generateOrderNumber();
    const created = await base44.asServiceRole.entities.SyncedOrder.create({
      ...record,
      order_number: orderNumber,
    });
    await logSync(
      base44,
      "order_received",
      orderNumber,
      `Order ${orderNumber} received from customer app (source ${record.source_order_id})`,
      "customer-app"
    );

    // Native push notification to the manager's phone. Fire-and-forget.
    waitUntil(
      notifyManagerPush(base44, {
        ...syncedPushAlert({ ...record, order_number: orderNumber }),
        action_label: "Open Dashboard",
        action_url: "/admin",
      })
    );

    // Gmail alert to the restaurant manager. Fire-and-forget: an email
    // failure never blocks the sync response to the customer app.
    waitUntil(
      notifyManagerNewOrder(base44, {
        order_number: orderNumber,
        customer_name: record.customer_name,
        mobile: record.customer_phone,
        customer_email: record.customer_email,
        order_type: record.order_type,
        address: record.delivery_address,
        items: (record.items || []).map((it) => ({
          name: it.name,
          quantity: it.quantity,
          subtotal: it.total,
        })),
        subtotal: record.subtotal,
        delivery_fee: record.delivery_fee,
        total: record.grand_total,
        payment_method: record.payment_method,
        payment_status: record.payment_status,
        notes: record.customer_notes,
        created_date: created.created_date || record.source_created_at,
      })
    );

    return Response.json(
      {
        success: true,
        duplicate: false,
        order_id: record.source_order_id,
        order_number: orderNumber,
        status: "pending",
        received_at: created.created_date || new Date().toISOString(),
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("receiveOrder error:", error);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
}