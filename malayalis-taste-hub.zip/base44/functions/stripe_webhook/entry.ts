import { createClientFromRequest } from "npm:@base44/sdk@0.8.40";
import { secrets, waitUntil } from "base44:runtime";
import { sendOrderEmails } from "../../shared/emails.ts";
import { notifyCustomerOrderEvent, orderToCustomerPayload } from "../../shared/customerNotifications.ts";

// Stripe webhook — verifies the request signature, then on successful payment
// marks the order PAID and advances the status. Emails are sent only after the
// payment provider confirms the payment (never on the client).
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const sig = req.headers.get("Stripe-Signature") || "";
    const payload = await req.text();
    const secret = secrets.get("STRIPE_WEBHOOK_SECRET");

    const valid = await verifyStripeSignature(payload, sig, secret);
    if (!valid) return Response.json({ error: "Invalid signature" }, { status: 400 });

    const event = JSON.parse(payload);

    if (event.type === "checkout.session.completed") {
      const session = event.data?.object || {};
      const orderId = session.metadata?.order_id || session.client_reference_id;
      if (orderId) {
        const updated = await base44.asServiceRole.entities.Order.update(orderId, {
          payment_status: "paid",
          paid: true,
          status: "payment_confirmed",
          stripe_payment_intent: session.payment_intent || "",
        });
        // Send confirmation + restaurant emails only after payment confirmed.
        waitUntil(sendOrderEmails(base44, updated));
        // "Order Accepted" customer notifications — email channel skipped,
        // sendOrderEmails already sends the payment confirmation email.
        waitUntil(
          notifyCustomerOrderEvent(base44, orderToCustomerPayload(updated), "payment_confirmed", {
            skipChannels: ["email"],
          })
        );
      }
    } else if (
      event.type === "checkout.session.async_payment_failed" ||
      event.type === "payment_intent.payment_failed"
    ) {
      const obj = event.data?.object || {};
      const orderId = obj.metadata?.order_id || obj.client_reference_id;
      if (orderId) {
        await base44.asServiceRole.entities.Order.update(orderId, {
          payment_status: "failed",
        });
      }
    }

    return Response.json({ received: true });
  } catch (error) {
    console.error("stripe_webhook error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

// Manual HMAC-SHA256 signature verification using Web Crypto (no SDK dependency).
async function verifyStripeSignature(payload, sigHeader, secret) {
  if (!secret || !sigHeader) return false;
  let t = null;
  let v1 = null;
  for (const part of sigHeader.split(",")) {
    const [k, v] = part.split("=");
    if (k === "t") t = v;
    if (k === "v1") v1 = v;
  }
  if (!t || !v1) return false;

  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sigBuf = await crypto.subtle.sign("HMAC", key, enc.encode(`${t}.${payload}`));
  const computed = [...new Uint8Array(sigBuf)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  if (computed.length !== v1.length) return false;
  let diff = 0;
  for (let i = 0; i < computed.length; i++)
    diff |= computed.charCodeAt(i) ^ v1.charCodeAt(i);
  if (diff !== 0) return false;

  // Reject stale signatures (> 5 minutes old)
  const age = Math.abs(Date.now() / 1000 - parseInt(t, 10));
  return age < 300;
}