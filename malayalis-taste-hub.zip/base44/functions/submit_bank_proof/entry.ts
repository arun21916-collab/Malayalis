import { createClientFromRequest } from "npm:@base44/sdk@0.8.40";
import { waitUntil } from "base44:runtime";
import { notifyProofSubmitted } from "../../shared/emails.ts";

// Public (no login) — lets a customer attach payment proof to their own bank
// transfer order. The customer can ONLY move the order to "proof_submitted";
// payment is never marked paid here. Staff verification is required.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { order_id, proof_url } = body || {};

    if (!order_id || !proof_url)
      return Response.json({ error: "Order and payment proof are required." }, { status: 400 });
    if (typeof proof_url !== "string" || !/^https?:\/\//.test(proof_url))
      return Response.json({ error: "Invalid payment proof file." }, { status: 400 });

    let order;
    try {
      order = await base44.asServiceRole.entities.Order.get(order_id);
    } catch (e) {
      return Response.json({ error: "Order not found." }, { status: 404 });
    }
    if (!order) return Response.json({ error: "Order not found." }, { status: 404 });
    if (order.payment_method !== "bank_transfer")
      return Response.json({ error: "This order is not a bank transfer." }, { status: 400 });

    if (!["pending_transfer", "payment_rejected", "proof_submitted"].includes(order.payment_status))
      return Response.json({ error: "Payment proof cannot be submitted at this stage." }, { status: 400 });

    const updated = await base44.asServiceRole.entities.Order.update(order_id, {
      payment_proof_url: proof_url,
      payment_status: "proof_submitted",
    });

    // Notify the restaurant that proof is ready to verify.
    waitUntil(notifyProofSubmitted(base44, updated));

    return Response.json({ ok: true, payment_status: "proof_submitted" });
  } catch (error) {
    console.error("submit_bank_proof error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}