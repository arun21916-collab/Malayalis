import React from 'react';
import { Flame, Leaf, ShieldCheck, Wheat, Droplet, Sparkles } from 'lucide-react';

// Available dietary / highlight badges. Keys are stored on the MenuItem `tags` array.
export const BADGE_OPTIONS = [
  { key: 'Spicy', label: 'Spicy', icon: Flame, classes: 'bg-red-500/10 text-red-700 border-red-500/30' },
  { key: 'Vegan', label: 'Vegan', icon: Leaf, classes: 'bg-emerald-500/10 text-emerald-700 border-emerald-500/30' },
  { key: 'Nut-Free', label: 'Nut-Free', icon: ShieldCheck, classes: 'bg-amber-500/10 text-amber-700 border-amber-500/30' },
  { key: 'Gluten-Free', label: 'Gluten-Free', icon: Wheat, classes: 'bg-sky-500/10 text-sky-700 border-sky-500/30' },
  { key: 'Dairy-Free', label: 'Dairy-Free', icon: Droplet, classes: 'bg-teal-500/10 text-teal-700 border-teal-500/30' },
  { key: "Chef's Special", label: "Chef's Special", icon: Sparkles, classes: 'bg-[#AF8B45]/10 text-[#AF8B45] border-[#AF8B45]/40' },
];

const MAP = Object.fromEntries(BADGE_OPTIONS.map((b) => [b.key, b]));

export default function DietaryBadges({ tags = [], className = '' }) {
  const list = (tags || []).map((t) => MAP[t]).filter(Boolean);
  if (!list.length) return null;
  return (
    <div className={`flex flex-wrap gap-1.5 ${className}`}>
      {list.map((b) => (
        <span
          key={b.key}
          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-semibold uppercase tracking-wide ${b.classes}`}
        >
          <b.icon className="w-3 h-3" /> {b.label}
        </span>
      ))}
    </div>
  );
}