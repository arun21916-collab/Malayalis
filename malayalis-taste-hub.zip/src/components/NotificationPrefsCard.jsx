import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { BellRing, Smartphone, MessageCircle, Mail, Loader2, Save } from 'lucide-react';

const CHANNELS = [
  { key: 'push_enabled', label: 'Push', icon: BellRing, hint: 'On your phone' },
  { key: 'sms_enabled', label: 'SMS', icon: Smartphone, hint: 'Text message' },
  { key: 'whatsapp_enabled', label: 'WhatsApp', icon: MessageCircle, hint: 'To your WhatsApp' },
  { key: 'email_enabled', label: 'Email', icon: Mail, hint: 'Order updates by email' },
];

export default function NotificationPrefsCard({ mobile }) {
  const { toast } = useToast();
  const [record, setRecord] = useState(null);
  const [form, setForm] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let active = true;
    (async () => {
      setLoading(true);
      try {
        const records = await base44.entities.CustomerNotificationPref.filter({ mobile });
        const rec = records && records[0];
        if (!active) return;
        setRecord(rec || null);
        setForm({
          push_enabled: rec ? rec.push_enabled !== false : true,
          sms_enabled: rec ? rec.sms_enabled !== false : true,
          whatsapp_enabled: rec ? rec.whatsapp_enabled !== false : true,
          email_enabled: rec ? rec.email_enabled !== false : true,
          whatsapp_number: rec?.whatsapp_number || '',
        });
      } catch (e) {
        // ignore
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [mobile]);

  const save = async () => {
    setSaving(true);
    try {
      if (record) {
        await base44.entities.CustomerNotificationPref.update(record.id, form);
      } else {
        await base44.entities.CustomerNotificationPref.create({ ...form, mobile });
      }
      toast({ title: 'Preferences saved', description: 'Order updates will use only the channels you enabled.' });
    } catch (e) {
      toast({ title: 'Could not save preferences', description: 'Please try again.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading || !form) return null;

  return (
    <div className="bg-white border border-[#AF8B45]/15 rounded p-5">
      <div className="flex items-center gap-2 mb-1">
        <BellRing className="w-4 h-4 text-[#AF8B45]" />
        <h2 className="font-display text-lg font-bold text-[#1A322B]">Order Notifications</h2>
      </div>
      <p className="text-xs text-[#1A322B]/55 mb-4">
        Choose how we should send you updates about your orders.
      </p>

      <div className="grid grid-cols-2 gap-2 mb-4">
        {CHANNELS.map((c) => (
          <label
            key={c.key}
            className={`flex items-center gap-2.5 border rounded-lg p-3 cursor-pointer select-none transition-colors ${
              form[c.key] ? 'border-[#AF8B45]/50 bg-[#AF8B45]/5' : 'border-[#AF8B45]/15'
            }`}
          >
            <input
              type="checkbox"
              checked={form[c.key]}
              onChange={(e) => setForm({ ...form, [c.key]: e.target.checked })}
              className="accent-[#AF8B45] w-4 h-4"
            />
            <c.icon className="w-4 h-4 text-[#1A322B]/70" />
            <span className="text-sm font-semibold text-[#1A322B]">{c.label}</span>
          </label>
        ))}
      </div>

      <label className="block text-xs font-semibold uppercase tracking-wide text-[#1A322B]/70 mb-1.5">
        WhatsApp Number <span className="normal-case font-normal text-[#1A322B]/45">(optional)</span>
      </label>
      <input
        value={form.whatsapp_number}
        onChange={(e) => setForm({ ...form, whatsapp_number: e.target.value })}
        className="w-full h-11 px-4 rounded bg-[#FDFBF7] border border-[#AF8B45]/25 text-sm focus:outline-none focus:border-[#AF8B45]"
        placeholder="Leave blank to use your mobile number"
        inputMode="tel"
      />

      <button
        onClick={save}
        disabled={saving}
        className="mt-4 w-full h-11 rounded-full bg-[#1A322B] text-[#FDFBF7] font-semibold text-sm flex items-center justify-center gap-2 hover:bg-[#AF8B45] hover:text-[#1A322B] transition-colors disabled:opacity-50 select-none"
      >
        {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
        Save preferences
      </button>
    </div>
  );
}