import React, { useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';

// Plays a short two-tone chime. Browsers may block audio before the user has
// interacted with the page — best-effort, never throws.
function playAlertChime() {
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    [0, 0.4].forEach((delay) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = delay ? 1175 : 880;
      gain.gain.setValueAtTime(0.001, ctx.currentTime + delay);
      gain.gain.exponentialRampToValueAtTime(0.4, ctx.currentTime + delay + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + delay + 0.35);
      osc.connect(gain).connect(ctx.destination);
      osc.start(ctx.currentTime + delay);
      osc.stop(ctx.currentTime + delay + 0.4);
    });
  } catch (e) {
    // ignore
  }
}

function showBrowserNotification(title, body) {
  try {
    if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return;
    new Notification(title, { body });
  } catch (e) {
    // ignore
  }
}

// Mounted in the admin dashboard: the moment a new order arrives — from this
// storefront or synced in from the customer app — it plays a chime and shows a
// prominent toast plus a browser notification so staff can react immediately.
export default function NewOrderAlertWatcher() {
  const { toast } = useToast();
  const toastRef = useRef(toast);
  toastRef.current = toast;

  useEffect(() => {
    // Ask once for browser notification permission (no prompt if already decided).
    try {
      if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
        Notification.requestPermission();
      }
    } catch (e) {
      // ignore
    }

    const alertNewOrder = (source, data) => {
      const number = data.order_number || '';
      const name = data.customer_name || '';
      const total = source === 'storefront' ? data.total : data.grand_total;
      const label = source === 'storefront' ? 'New order received' : 'New order from customer app';
      const body = number
        ? `#${number}${name ? ` — ${name}` : ''} · €${Number(total ?? 0).toFixed(2)}`
        : 'Open the dashboard to accept it.';
      playAlertChime();
      showBrowserNotification(label, body);
      toastRef.current({
        title: label,
        description: body,
        duration: 15000,
      });
    };

    const unsubOrders = base44.entities.Order.subscribe((event) => {
      if (event?.type === 'create' && event.data) alertNewOrder('storefront', event.data);
    });
    const unsubSynced = base44.entities.SyncedOrder.subscribe((event) => {
      if (event?.type === 'create' && event.data) alertNewOrder('customer-app', event.data);
    });
    return () => {
      unsubOrders && unsubOrders();
      unsubSynced && unsubSynced();
    };
  }, []);

  return null;
}