import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import {
  RefreshCw, Phone, Mail, Truck, Store, UtensilsCrossed, MapPin,
  Landmark, CreditCard, Banknote, Wallet, StickyNote,
} from 'lucide-react';

const STATUSES = ['pending', 'accepted', 'preparing', 'ready', 'out_for_delivery', 'delivered', 'cancelled'];
const LABELS = {
  pending: 'Pending',
  accepted: 'Accepted',
  preparing: 'Preparing',
  ready: 'Ready',
  out_for_delivery: 'Out for Delivery',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
};
const STYLE = {
  pending: 'bg-amber-500/15 text-amber-300 border-amber-500/40',
  accepted: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40',
  preparing: 'bg-sky-500/15 text-sky-300 border-sky-500/40',
  ready: 'bg-teal-500/15 text-teal-300 border-teal-500/40',
  out_for_delivery: 'bg-violet-500/15 text-violet-300 border-violet-500/40',
  delivered: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/40',
  cancelled: 'bg-red-500/15 text-red-300 border-red-500/40',
};

function nextAction(order) {
  switch (order.status) {
    case 'pending': return { label: 'Accept Order', status: 'accepted', className: 'bg-emerald-600 text-white hover:bg-emerald-500' };
    case 'accepted': return { label: 'Start Preparing', status: 'preparing', className: 'bg-sky-600 text-white hover:bg-sky-500' };
    case 'preparing': return { label: 'Mark Ready', status: 'ready', className: 'bg-teal-600 text-white hover:bg-teal-500' };
    case 'ready':
      return order.order_type === 'delivery'
        ? { label: 'Out for Delivery', status: 'out_for_delivery', className: 'bg-violet-600 text-white hover:bg-violet-500' }
        : { label: 'Mark Collected', status: 'delivered', className: 'bg-indigo-600 text-white hover:bg-indigo-500' };
    case 'out_for_delivery': return { label: 'Mark Delivered', status: 'delivered', className: 'bg-indigo-600 text-white hover:bg-indigo-500' };
    default: return null;
  }
}

function PayIcon({ method }) {
  if (method === 'card') return <CreditCard className="w-3 h-3" />;
  if (method === 'bank_transfer') return <Landmark className="w-3 h-3" />;
  if (method === 'cash') return <Banknote className="w-3 h-3" />;
  return <Wallet className="w-3 h-3" />;
}

export default function SyncedOrdersPanel() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [busy, setBusy] = useState(null);

  const load = async () => {
    try {
      const list = await base44.entities.SyncedOrder.list('-created_date', 200);
      setOrders(list);
    } catch (e) {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // Real-time: new orders appear instantly without refreshing.
    const unsub = base44.entities.SyncedOrder.subscribe((event) => {
      if (!event?.data) return;
      if (event.type === 'create') {
        setOrders((p) => [event.data, ...p.filter((o) => o.id !== event.data.id)]);
      } else if (event.type === 'update') {
        setOrders((p) => p.map((o) => (o.id === event.data.id ? event.data : o)));
      } else if (event.type === 'delete') {
        setOrders((p) => p.filter((o) => o.id !== event.data.id));
      }
    });
    return () => unsub && unsub();
  }, []);

  const changeStatus = async (order, status) => {
    setBusy(order.id + status);
    try {
      const res = await base44.functions.invoke('updateOrderStatus', {
        order_id: order.id,
        status,
      });
      if (res.data?.success === false) {
        alert(res.data.error || 'Could not update the order status.');
        return;
      }
      setOrders((p) =>
        p.map((o) =>
          o.id === order.id
            ? { ...o, status: res.data.status, status_history: res.data.status_history || o.status_history }
            : o
        )
      );
    } catch (e) {
      alert(e.response?.data?.error || 'Could not update the order status.');
    } finally {
      setBusy(null);
    }
  };

  const filtered = filter === 'all' ? orders : orders.filter((o) => o.status === filter);
  const pendingCount = orders.filter((o) => o.status === 'pending').length;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="font-display text-xl font-bold text-[#AF8B45]">Incoming Orders</h2>
          <p className="text-sm text-[#FDFBF7]/60 mt-1">
            Orders placed in the customer app appear here in real time.
            {pendingCount > 0 && (
              <span className="text-amber-300 font-semibold"> {pendingCount} pending.</span>
            )}
          </p>
        </div>
        <button onClick={load} className="p-2 hover:bg-white/5 rounded-full select-none" aria-label="Refresh">
          <RefreshCw className="w-4 h-4 text-[#AF8B45]" />
        </button>
      </div>

      {/* Status filters */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-1">
        <button
          onClick={() => setFilter('all')}
          className={`px-3 h-9 rounded-full text-xs font-medium whitespace-nowrap select-none ${
            filter === 'all' ? 'bg-white/15 text-white' : 'text-[#FDFBF7]/50 hover:text-white'
          }`}
        >
          All ({orders.length})
        </button>
        {STATUSES.map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`px-3 h-9 rounded-full text-xs font-medium whitespace-nowrap select-none ${
              filter === s ? 'bg-white/15 text-white' : 'text-[#FDFBF7]/50 hover:text-white'
            }`}
          >
            {LABELS[s]} ({orders.filter((o) => o.status === s).length})
          </button>
        ))}
      </div>

      {loading ? (
        <div className="text-center py-20 text-[#FDFBF7]/50">Loading…</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20 text-[#FDFBF7]/40">
          No incoming orders yet. Orders placed in the customer app will appear here automatically.
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {filtered.map((o) => {
            const action = nextAction(o);
            return (
              <div key={o.id} className="bg-[#1A322B] border border-[#AF8B45]/15 rounded p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-display text-lg font-bold text-[#AF8B45]">#{o.order_number}</p>
                    <p className="text-[11px] text-[#FDFBF7]/40">Customer app ref: {o.source_order_id}</p>
                    <p className="text-sm text-[#FDFBF7]/80 flex items-center gap-1.5 mt-1">
                      {o.customer_name}
                      <a href={`tel:${o.customer_phone}`} className="text-[#AF8B45] hover:underline flex items-center gap-0.5">
                        <Phone className="w-3 h-3" /> {o.customer_phone}
                      </a>
                    </p>
                    {o.customer_email && (
                      <a href={`mailto:${o.customer_email}`} className="text-xs text-[#FDFBF7]/60 hover:text-[#AF8B45] flex items-center gap-1 mt-0.5">
                        <Mail className="w-3 h-3" /> {o.customer_email}
                      </a>
                    )}
                    <p className="text-xs text-[#FDFBF7]/50 mt-1 flex items-center gap-1">
                      {o.order_type === 'delivery' ? <Truck className="w-3 h-3" /> : o.order_type === 'takeaway' ? <Store className="w-3 h-3" /> : <UtensilsCrossed className="w-3 h-3" />}
                      <span className="capitalize">{(o.order_type || '').replace(/_/g, ' ')}</span>
                      {o.source_created_at && (
                        <> · {new Date(o.source_created_at).toLocaleString('en-IE', { dateStyle: 'short', timeStyle: 'short' })}</>
                      )}
                    </p>
                    {o.order_type === 'delivery' && o.delivery_address && (
                      <p className="text-xs text-[#FDFBF7]/50 mt-1 flex items-start gap-1">
                        <MapPin className="w-3 h-3 mt-0.5 flex-shrink-0" /> {o.delivery_address}
                      </p>
                    )}
                  </div>
                  <span className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full border whitespace-nowrap ${STYLE[o.status] || ''}`}>
                    {LABELS[o.status] || o.status}
                  </span>
                </div>

                <div className="mt-4 space-y-1 border-t border-[#AF8B45]/15 pt-3">
                  {(o.items || []).map((it, i) => (
                    <div key={i} className="flex justify-between text-sm">
                      <span className="text-[#FDFBF7]/80">{it.quantity}× {it.name}</span>
                      <span className="text-[#FDFBF7]/60">€{(it.total ?? (it.price * it.quantity)).toFixed(2)}</span>
                    </div>
                  ))}
                </div>

                <div className="mt-3 pt-2 text-xs text-[#FDFBF7]/60 space-y-0.5">
                  <div className="flex justify-between"><span>Subtotal</span><span>€{(o.subtotal ?? 0).toFixed(2)}</span></div>
                  {(o.delivery_fee ?? 0) > 0 && (
                    <div className="flex justify-between"><span>Delivery fee</span><span>€{(o.delivery_fee ?? 0).toFixed(2)}</span></div>
                  )}
                  {(o.discount ?? 0) > 0 && (
                    <div className="flex justify-between"><span>Discount</span><span>−€{(o.discount ?? 0).toFixed(2)}</span></div>
                  )}
                  <div className="flex justify-between font-display text-base font-bold text-[#FDFBF7] pt-1">
                    <span>Total</span><span>€{(o.grand_total ?? 0).toFixed(2)}</span>
                  </div>
                </div>

                <div className="mt-3 pt-2 border-t border-[#AF8B45]/15 flex items-center justify-between text-xs">
                  <span className="text-[#FDFBF7]/70 flex items-center gap-1.5 capitalize">
                    <PayIcon method={o.payment_method} /> {(o.payment_method || '').replace(/_/g, ' ')}
                  </span>
                  <span className="text-[#FDFBF7]/50 capitalize">{(o.payment_status || '').replace(/_/g, ' ')}</span>
                </div>

                {o.customer_notes && (
                  <p className="mt-2 text-xs text-[#FDFBF7]/50 italic flex items-start gap-1">
                    <StickyNote className="w-3 h-3 mt-0.5 flex-shrink-0" /> "{o.customer_notes}"
                  </p>
                )}

                {(action || (o.status !== 'cancelled' && o.status !== 'delivered')) && (
                  <div className="mt-4 pt-3 border-t border-[#AF8B45]/15 flex items-center gap-2">
                    {action && (
                      <button
                        onClick={() => changeStatus(o, action.status)}
                        disabled={busy === o.id + action.status}
                        className={`flex-1 h-10 rounded text-xs font-semibold disabled:opacity-50 select-none ${action.className}`}
                      >
                        {busy === o.id + action.status ? 'Updating…' : action.label}
                      </button>
                    )}
                    {o.status !== 'cancelled' && o.status !== 'delivered' && (
                      <button
                        onClick={() => {
                          if (confirm(`Cancel order #${o.order_number}?`)) changeStatus(o, 'cancelled');
                        }}
                        disabled={busy === o.id + 'cancelled'}
                        className="px-3 h-10 rounded text-xs font-semibold text-red-300 border border-red-500/40 hover:bg-red-500/10 disabled:opacity-50 select-none"
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}