import React from 'react';
import { Check } from 'lucide-react';

const PICKUP_STAGES = [
  { key: 'received', label: 'Received' },
  { key: 'payment_confirmed', label: 'Paid' },
  { key: 'preparing', label: 'Preparing' },
  { key: 'ready', label: 'Ready' },
  { key: 'completed', label: 'Completed' },
];

const DELIVERY_STAGES = [
  { key: 'received', label: 'Received' },
  { key: 'payment_confirmed', label: 'Paid' },
  { key: 'preparing', label: 'Preparing' },
  { key: 'ready', label: 'Ready' },
  { key: 'out_for_delivery', label: 'Out for Delivery' },
  { key: 'delivered', label: 'Delivered' },
  { key: 'completed', label: 'Completed' },
];

const STATUS_LABELS = {
  received: 'Order Received',
  payment_confirmed: 'Payment Confirmed',
  preparing: 'Preparing',
  ready: 'Ready',
  out_for_delivery: 'Out for Delivery',
  delivered: 'Delivered',
  completed: 'Completed',
  cancelled: 'Cancelled',
};

export function statusLabel(status) {
  return STATUS_LABELS[status] || status;
}

export default function OrderStatusTracker({ order, onChange, readOnly }) {
  if (order.status === 'cancelled') {
    return (
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-red-300">Order cancelled</span>
        {!readOnly && (
          <button
            type="button"
            onClick={() => onChange && onChange('received')}
            className="text-xs text-[#AF8B45] hover:underline"
          >
            Reopen
          </button>
        )}
      </div>
    );
  }

  const stages = order.order_type === 'delivery' ? DELIVERY_STAGES : PICKUP_STAGES;
  const currentIndex = stages.findIndex((s) => s.key === order.status);

  return (
    <div className="flex items-start">
      {stages.map((stage, i) => {
        const done = i < currentIndex;
        const active = i === currentIndex;
        const reached = i <= currentIndex;
        return (
          <div key={stage.key} className="flex-1 flex flex-col items-center relative">
            {i > 0 && (
              <span
                className={`absolute top-3.5 left-[-50%] w-full h-px ${
                  reached ? 'bg-[#AF8B45]/50' : 'bg-[#FDFBF7]/15'
                }`}
              />
            )}
            <button
              type="button"
              disabled={readOnly}
              onClick={() => !readOnly && onChange && onChange(stage.key)}
              className={`relative z-10 w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-bold border transition-colors ${
                readOnly ? 'cursor-default' : 'cursor-pointer'
              } ${
                active
                  ? 'bg-[#AF8B45] text-[#1A322B] border-[#AF8B45]'
                  : done
                  ? 'bg-[#AF8B45]/25 text-[#AF8B45] border-[#AF8B45]/40'
                  : 'bg-[#14241F] text-[#FDFBF7]/40 border-[#FDFBF7]/20 hover:border-[#AF8B45]/50'
              }`}
            >
              {done ? <Check className="w-3.5 h-3.5" /> : i + 1}
            </button>
            <span
              className={`mt-1.5 text-[9px] uppercase tracking-wide text-center leading-tight ${
                active
                  ? 'text-[#AF8B45] font-semibold'
                  : reached
                  ? 'text-[#FDFBF7]/70'
                  : 'text-[#FDFBF7]/35'
              }`}
            >
              {stage.label}
            </span>
          </div>
        );
      })}
    </div>
  );
}