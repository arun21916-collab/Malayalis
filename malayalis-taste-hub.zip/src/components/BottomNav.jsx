import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, UtensilsCrossed, ClipboardList, Info } from 'lucide-react';

// Persistent mobile bottom tab bar — small screens only. The desktop layout
// is untouched. Respects the iOS safe area via the .safe-area-bottom helper.
const TABS = [
  { label: 'Home', path: '/', icon: Home },
  { label: 'Menu', path: '/menu', icon: UtensilsCrossed },
  { label: 'My Orders', path: '/my-orders', icon: ClipboardList },
  { label: 'About', path: '/about-us', icon: Info },
];

// Paths of the bottom-nav tabs — these routes are kept alive by Layout so
// switching tabs preserves scroll position and in-page state.
export const BOTTOM_TAB_PATHS = TABS.map((t) => t.path);

export default function BottomNav() {
  const location = useLocation();
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#FDFBF7]/95 backdrop-blur-md border-t border-[#AF8B45]/20 safe-area-bottom select-none">
      <div className="grid grid-cols-4">
        {TABS.map((t) => {
          const active = t.path === '/' ? location.pathname === '/' : location.pathname.startsWith(t.path);
          return (
            <Link
              key={t.path}
              to={t.path}
              className={`flex flex-col items-center justify-center gap-0.5 h-16 text-[10px] font-semibold uppercase tracking-wide transition-colors ${
                active ? 'text-[#AF8B45]' : 'text-[#1A322B]/60'
              }`}
              aria-label={t.label}
            >
              <t.icon className="w-5 h-5" />
              {t.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}