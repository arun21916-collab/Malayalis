import React, { useState } from 'react';
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';
import { ChevronDown, Check } from 'lucide-react';

// Theme-styled select replacement for native dropdowns (dark admin surfaces).
export default function ThemeSelect({ value, onChange, options, placeholder = 'Select…' }) {
  const [open, setOpen] = useState(false);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          className="w-full flex items-center justify-between gap-2 h-11 rounded px-3 text-sm border border-[#AF8B45]/30 bg-[#14241F] text-[#FDFBF7] focus:outline-none focus:border-[#AF8B45] select-none"
        >
          <span>{value || placeholder}</span>
          <ChevronDown
            className={`w-4 h-4 text-[#AF8B45] transition-transform ${open ? 'rotate-180' : ''}`}
          />
        </button>
      </PopoverTrigger>
      <PopoverContent
        align="start"
        sideOffset={6}
        className="w-[var(--radix-popover-trigger-width)] p-0 bg-[#1A322B] border border-[#AF8B45]/30 rounded-md"
      >
        <div className="max-h-64 overflow-y-auto">
          {options.map((opt) => (
            <button
              key={opt}
              type="button"
              onClick={() => {
                onChange(opt);
                setOpen(false);
              }}
              className="w-full flex items-center justify-between h-11 px-3 text-sm text-[#FDFBF7] hover:bg-[#AF8B45]/15 select-none"
            >
              <span>{opt}</span>
              {value === opt && <Check className="w-4 h-4 text-[#AF8B45]" />}
            </button>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}