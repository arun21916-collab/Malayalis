import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import StarRating from '@/components/StarRating';
import ReviewModal from '@/components/ReviewModal';

// Star rating + expandable text-review section shown on every menu item card.
export default function ItemReviews({ item, reviews = [], ratingInfo, onSubmitted }) {
  const [modalOpen, setModalOpen] = useState(false);
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="mt-2">
      <div className="flex items-center justify-between gap-2">
        {ratingInfo && ratingInfo.count > 0 ? (
          <StarRating value={ratingInfo.avg} count={ratingInfo.count} />
        ) : (
          <span className="text-[11px] text-[#1A322B]/50">No reviews yet</span>
        )}
        <button
          onClick={() => setModalOpen(true)}
          className="text-[11px] font-semibold text-[#AF8B45] hover:underline select-none whitespace-nowrap"
        >
          Leave a review
        </button>
      </div>

      {reviews.length > 0 && (
        <div className="mt-2 border-t border-[#AF8B45]/10 pt-2">
          <button
            onClick={() => setExpanded(!expanded)}
            className="flex items-center gap-1 text-[11px] font-semibold text-[#1A322B]/70 hover:text-[#AF8B45] select-none"
          >
            {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            {expanded ? 'Hide reviews' : `Read ${reviews.length} review${reviews.length > 1 ? 's' : ''}`}
          </button>
          {expanded && (
            <div className="mt-2 space-y-3">
              {reviews.slice(0, 5).map((r) => (
                <div key={r.id} className="text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <StarRating value={r.rating} size="w-3 h-3" />
                    <span className="text-[10px] text-[#1A322B]/40 whitespace-nowrap">
                      {r.customer_name || 'Guest'} ·{' '}
                      {new Date(r.created_date).toLocaleDateString(undefined, { day: 'numeric', month: 'short' })}
                    </span>
                  </div>
                  {r.review_text && (
                    <p className="text-[#1A322B]/70 mt-1 leading-relaxed">"{r.review_text}"</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {modalOpen && (
        <ReviewModal item={item} onClose={() => setModalOpen(false)} onSubmitted={onSubmitted} />
      )}
    </div>
  );
}