import React from 'react';
import { Loader2 } from 'lucide-react';

// Slim spinning indicator shown at the top of a page while a
// pull-to-refresh is running.
export default function PullToRefreshIndicator({ active }) {
  if (!active) return null;
  return (
    <div
      className="flex items-center justify-center gap-2 py-3 text-[#AF8B45]"
      role="status"
      aria-live="polite"
    >
      <Loader2 className="w-5 h-5 animate-spin" />
      <span className="text-xs font-semibold uppercase tracking-wide select-none">Refreshing…</span>
    </div>
  );
}