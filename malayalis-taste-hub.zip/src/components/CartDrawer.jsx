import React from 'react';
import { useCart } from '@/context/CartContext';
import { X, Plus, Minus, Trash2, ShoppingBag } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Image } from '@/components/ui/image';
import { Button } from '@/components/ui/button';

export default function CartDrawer() {
  const { items, isOpen, setIsOpen, updateQuantity, removeItem, subtotal } = useCart();
  const navigate = useNavigate();

  const handleCheckout = () => {
    setIsOpen(false);
    navigate('/checkout');
  };

  return (
    <>
      <div
        className={`fixed inset-0 z-50 bg-[#1A322B]/40 backdrop-blur-sm transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setIsOpen(false)}
      />
      <aside
        className={`fixed top-0 right-0 z-50 h-full w-full max-w-md bg-[#FDFBF7] shadow-2xl transition-transform duration-300 flex flex-col ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between px-6 pb-5 pt-[calc(1.25rem+env(safe-area-inset-top))] border-b border-[#AF8B45]/20">
          <h2 className="font-display text-xl font-bold text-[#1A322B] flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#AF8B45]" /> Your Order
          </h2>
          <button onClick={() => setIsOpen(false)} className="p-2 hover:bg-[#1A322B]/5 rounded-full" aria-label="Close cart">
            <X className="w-5 h-5 text-[#1A322B]" />
          </button>
        </div>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center px-6 text-center gap-3">
            <ShoppingBag className="w-12 h-12 text-[#AF8B45]/40" />
            <p className="font-display text-lg text-[#1A322B]">Your cart is empty</p>
            <p className="text-sm text-[#1A322B]/60">Add some authentic Kerala dishes to get started.</p>
            <Button
              onClick={() => {
                setIsOpen(false);
                navigate('/menu');
              }}
              className="bg-[#1A322B] text-[#FDFBF7] hover:bg-[#1A322B]/90 mt-2"
            >
              Browse Menu
            </Button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
              {items.map((item) => (
                <div key={item.id} className="flex gap-3">
                  <div className="w-16 h-16 rounded overflow-hidden flex-shrink-0 bg-[#1A322B]/5">
                    {item.image_url && (
                      <Image src={item.image_url} alt={item.name} className="w-full h-full object-cover" fittingType="fill" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-semibold text-[#1A322B] leading-tight">{item.name}</h3>
                    <p className="text-sm text-[#AF8B45] font-medium mt-0.5">{item.price_text}</p>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-1 border border-[#AF8B45]/30 rounded-full">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="w-7 h-7 flex items-center justify-center hover:bg-[#1A322B]/5 rounded-full"
                          aria-label="Decrease"
                        >
                          <Minus className="w-3.5 h-3.5 text-[#1A322B]" />
                        </button>
                        <span className="w-7 text-center text-sm font-semibold text-[#1A322B]">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="w-7 h-7 flex items-center justify-center hover:bg-[#1A322B]/5 rounded-full"
                          aria-label="Increase"
                        >
                          <Plus className="w-3.5 h-3.5 text-[#1A322B]" />
                        </button>
                      </div>
                      <button
                        onClick={() => removeItem(item.id)}
                        className="p-1.5 text-[#9E2A2B] hover:bg-[#9E2A2B]/5 rounded-full"
                        aria-label="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-[#1A322B]">€{(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-[#AF8B45]/20 px-6 pt-5 pb-[calc(1.25rem+env(safe-area-inset-bottom))] space-y-4 bg-[#FDFBF7]">
              <div className="flex items-center justify-between">
                <span className="font-display text-lg text-[#1A322B]">Subtotal</span>
                <span className="font-display text-2xl font-bold text-[#1A322B]">€{subtotal.toFixed(2)}</span>
              </div>
              <Button
                onClick={handleCheckout}
                className="w-full bg-[#1A322B] text-[#FDFBF7] hover:bg-[#AF8B45] hover:text-[#1A322B] h-12 text-base font-semibold tracking-wide"
              >
                Proceed to Checkout
              </Button>
              <button
                onClick={() => {
                  setIsOpen(false);
                  navigate('/menu');
                }}
                className="w-full text-sm text-[#1A322B]/70 hover:text-[#AF8B45] font-medium"
              >
                Continue Shopping
              </button>
            </div>
          </>
        )}
      </aside>
    </>
  );
}