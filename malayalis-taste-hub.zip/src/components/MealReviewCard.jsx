import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Star } from 'lucide-react';
import ReviewModal from '@/components/ReviewModal';

// Shown on the tracking page once the order is finished ("delivered"/"completed").
// Lets the customer rate each dish they ordered and leave a short review.
// Ordered items are matched back to current menu items so ratings attach to
// the real menu item id used across the app.
export default function MealReviewCard({ order }) {
  const [menuItems, setMenuItems] = useState(null);
  const [reviewing, setReviewing] = useState(null);
  const [reviewed, setReviewed] = useState({});

  useEffect(() => {
    base44.entities.MenuItem
      .list('display_order', 300)
      .then(setMenuItems)
      .catch(() => setMenuItems([]));
  }, []);

  if (!menuItems) return null;

  // One review prompt per distinct dish in the order.
  const names = [...new Set((order.items || []).map((it) => it.name))];
  const rateable = names
    .map((name) => ({
      name,
      menuItem: menuItems.find(
        (m) => (m.name || '').trim().toLowerCase() === (name || '').trim().toLowerCase()
      ),
    }))
    .filter((it) => it.menuItem);

  if (rateable.length === 0) return null;

  return (
    <div className="bg-white border border-[#AF8B45]/20 rounded p-6 mt-6">
      <h2 className="font-display text-lg font-bold text-[#1A322B] flex items-center gap-2">
        <Star className="w-4 h-4 text-[#AF8B45] fill-[#AF8B45]" /> How was your meal?
      </h2>
      <p className="text-sm text-[#1A322B]/60 mt-1 mb-4">
        Rate the dishes from order #{order.order_number} and share your thoughts.
      </p>
      <div className="space-y-2">
        {rateable.map((it) => (
          <div
            key={it.name}
            className="flex items-center justify-between gap-3 border-b border-[#AF8B45]/10 pb-2 last:border-0 last:pb-0"
          >
            <span className="text-sm text-[#1A322B] min-w-0 truncate">{it.name}</span>
            {reviewed[it.menuItem.id] ? (
              <span className="text-xs text-[#4A6741] font-semibold flex items-center gap-1 whitespace-nowrap">
                <Star className="w-3 h-3 fill-[#AF8B45] text-[#AF8B45]" /> Thank you!
              </span>
            ) : (
              <button
                onClick={() => setReviewing(it.menuItem)}
                className="h-11 px-4 rounded-full border border-[#AF8B45]/40 text-xs font-semibold text-[#AF8B45] hover:bg-[#AF8B45]/10 whitespace-nowrap select-none"
              >
                Rate this dish
              </button>
            )}
          </div>
        ))}
      </div>
      {reviewing && (
        <ReviewModal
          item={reviewing}
          onClose={() => setReviewing(null)}
          onSubmitted={() => setReviewed((p) => ({ ...p, [reviewing.id]: true }))}
        />
      )}
    </div>
  );
}