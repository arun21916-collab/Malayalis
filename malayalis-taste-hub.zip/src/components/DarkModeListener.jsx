import React, { useEffect } from 'react';

// Syncs the app with the device's system dark mode: adds/removes the '.dark'
// class on <html> whenever the OS 'prefers-color-scheme' setting changes.
export default function DarkModeListener() {
  useEffect(() => {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const apply = (dark) => document.documentElement.classList.toggle('dark', dark);
    apply(mq.matches);
    const handler = (e) => apply(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);
  return null;
}