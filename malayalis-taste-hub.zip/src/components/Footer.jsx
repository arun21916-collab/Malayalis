import React from 'react';
import { MapPin, Clock, Phone, Instagram, Facebook } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-[#1A322B] text-[#FDFBF7] mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-3 gap-12">
          <div>
            <h3 className="font-display text-3xl font-bold">
              MALAYA<span className="text-[#AF8B45]">LIS</span>
            </h3>
            <p className="mt-4 text-sm text-[#FDFBF7]/70 leading-relaxed max-w-xs">
              The soul of Malabar, served. Authentic Kerala &amp; Malabar cuisine crafted with traditional spices and
              coastal warmth.
            </p>
            <div className="flex gap-3 mt-6">
              <a href="#" className="w-10 h-10 rounded-full border border-[#AF8B45]/40 flex items-center justify-center hover:bg-[#AF8B45] hover:text-[#1A322B] transition-colors" aria-label="Instagram">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-[#AF8B45]/40 flex items-center justify-center hover:bg-[#AF8B45] hover:text-[#1A322B] transition-colors" aria-label="Facebook">
                <Facebook className="w-4 h-4" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-display text-lg text-[#AF8B45] mb-4">Visit Us</h4>
            <div className="space-y-3 text-sm text-[#FDFBF7]/80">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#AF8B45] mt-0.5 flex-shrink-0" />
                Main Street, Kerala Town
                <br />
                Malabar Coast
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#AF8B45]" /> +353 1 234 5678
              </p>
            </div>
          </div>

          <div>
            <h4 className="font-display text-lg text-[#AF8B45] mb-4">Opening Hours</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-[#FDFBF7]/80">
                <span>Monday – Friday</span>
                <span className="text-[#AF8B45] font-medium">8:00 – 22:00</span>
              </div>
              <div className="flex justify-between text-[#FDFBF7]/80">
                <span>Saturday</span>
                <span className="text-[#AF8B45] font-medium">8:00 – 23:00</span>
              </div>
              <div className="flex justify-between text-[#FDFBF7]/80">
                <span>Sunday</span>
                <span className="text-[#AF8B45] font-medium">9:00 – 22:00</span>
              </div>
            </div>
            <Link
              to="/menu"
              className="inline-block mt-6 text-sm font-semibold text-[#AF8B45] hover:text-[#FDFBF7] transition-colors"
            >
              Order Online →
            </Link>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-[#AF8B45]/20 text-center text-xs text-[#FDFBF7]/50">
          © {new Date().getFullYear()} MALAYALIS. All rights reserved. ·{' '}
          <Link to="/login" className="hover:text-[#AF8B45]">
            Sign In
          </Link>{' '}
          ·{' '}
          <Link to="/admin" className="hover:text-[#AF8B45]">
            Staff
          </Link>
        </div>
      </div>
    </footer>
  );
}