import React, { useState } from 'react';
import { useCart } from '@/context/CartContext';
import ItemDetailDialog from '@/components/ItemDetailDialog';
import { Plus, Minus, Leaf, Star } from 'lucide-react';
import { Image } from '@/components/ui/image';
import ItemReviews from '@/components/ItemReviews';
import DietaryBadges from '@/components/DietaryBadges';

export default function MenuItemCard({ item, reviews, ratingInfo, onReviewSubmitted }) {
  const { items, addItem, updateQuantity } = useCart();
  const cartItem = items.find((i) => i.id === item.id);
  const quantity = cartItem ? cartItem.quantity : 0;
  const asPerSize = item.price_text === 'As per Size';
  const soldOut = item.sold_out || !item.available;
  const [detailOpen, setDetailOpen] = useState(false);

  return (
    <div className="group flex flex-col overflow-hidden rounded bg-white border border-[#AF8B45]/15 hover:border-[#AF8B45]/40 transition-all duration-300 hover:shadow-lg">
      <div
        className="relative aspect-[4/3] overflow-hidden bg-[#1A322B]/5 cursor-pointer"
        onClick={() => setDetailOpen(true)}
        role="button"
        aria-label={`View details for ${item.name}`}
      >
        {item.image_url ? (
          <Image
            src={item.image_url}
            alt={item.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            fittingType="fill"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <span className="font-display text-[#1A322B]/20 text-3xl">M</span>
          </div>
        )}
        {item.is_vegetarian && (
          <span className="absolute top-2 left-2 bg-white/90 backdrop-blur px-1.5 py-1 rounded-full flex items-center gap-1 text-[10px] font-semibold text-[#4A6741]">
            <Leaf className="w-3 h-3" /> VEG
          </span>
        )}
        {ratingInfo && ratingInfo.count > 0 && ratingInfo.avg > 4.5 && (
          <span className="absolute top-2 right-2 bg-[#AF8B45] text-[#1A322B] px-1.5 py-1 rounded-full flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide">
            <Star className="w-3 h-3 fill-[#1A322B]" /> Top Rated
          </span>
        )}
        {soldOut && (
          <div className="absolute inset-0 bg-[#1A322B]/60 flex items-center justify-center">
            <span className="text-white font-display text-base tracking-widest uppercase">Sold Out</span>
          </div>
        )}
      </div>

      <div className="flex flex-col flex-1 p-4">
        <h3
          className="font-display text-lg font-semibold text-[#1A322B] leading-tight cursor-pointer hover:text-[#AF8B45] transition-colors"
          onClick={() => setDetailOpen(true)}
        >
          {item.name}
        </h3>
        {item.description ? (
          <p className="text-xs text-[#1A322B]/55 mt-1 leading-relaxed line-clamp-2">{item.description}</p>
        ) : null}
        <DietaryBadges tags={item.tags} className="mt-2" />
        <ItemReviews
          item={item}
          reviews={reviews}
          ratingInfo={ratingInfo}
          onSubmitted={onReviewSubmitted}
        />
        <div className="flex items-end justify-between mt-3 pt-3 border-t border-[#AF8B45]/10">
          <span className="font-display text-xl font-bold text-[#AF8B45]">{item.price_text}</span>
          {soldOut ? (
            <span className="text-xs text-[#9E2A2B] font-semibold uppercase">Unavailable</span>
          ) : asPerSize ? (
            <span className="text-xs text-[#1A322B]/60 font-medium italic">Enquire</span>
          ) : quantity > 0 ? (
            <div className="flex items-center gap-1 bg-[#1A322B] rounded-full">
              <button
                onClick={() => updateQuantity(item.id, quantity - 1)}
                className="w-11 h-11 flex items-center justify-center text-[#FDFBF7] hover:bg-[#1A322B]/80 rounded-full select-none"
                aria-label="Decrease"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="w-6 text-center text-sm font-bold text-[#FDFBF7]">{quantity}</span>
              <button
                onClick={() => updateQuantity(item.id, quantity + 1)}
                className="w-11 h-11 flex items-center justify-center text-[#FDFBF7] hover:bg-[#1A322B]/80 rounded-full select-none"
                aria-label="Increase"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => addItem(item)}
              className="flex items-center gap-1 bg-[#1A322B] text-[#FDFBF7] px-4 h-11 rounded-full text-xs font-semibold uppercase tracking-wide hover:bg-[#AF8B45] hover:text-[#1A322B] transition-colors select-none"
            >
              <Plus className="w-3.5 h-3.5" /> Add
            </button>
          )}
        </div>
      </div>
      <ItemDetailDialog
        item={item}
        open={detailOpen}
        onOpenChange={setDetailOpen}
        reviews={reviews}
        ratingInfo={ratingInfo}
        onReviewSubmitted={onReviewSubmitted}
      />
    </div>
  );
}