import React, { useEffect, useRef } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import Navbar from './Navbar';
import CartDrawer from './CartDrawer';
import BottomNav, { BOTTOM_TAB_PATHS } from './BottomNav';
import Home from '@/pages/Home';
import MenuPage from '@/pages/MenuPage';
import MyOrders from '@/pages/MyOrders';
import AboutUs from '@/pages/AboutUs';

// Keep-alive: the four bottom-nav tabs stay mounted (hidden when inactive) so
// scroll positions and in-page filters survive tab switches. All other routes
// render through the Outlet with the animated push/pop transition.
const KEPT_TABS = [
  { path: '/', element: <Home /> },
  { path: '/menu', element: <MenuPage /> },
  { path: '/my-orders', element: <MyOrders /> },
  { path: '/about-us', element: <AboutUs /> },
];

export default function Layout() {
  const location = useLocation();
  const scrollPositions = useRef({});
  const prevPath = useRef(location.pathname);

  const isKeptTab = BOTTOM_TAB_PATHS.includes(location.pathname);

  // Save the scroll position of the route we are leaving.
  useEffect(() => {
    if (prevPath.current !== location.pathname) {
      scrollPositions.current[prevPath.current] = window.scrollY;
      prevPath.current = location.pathname;
    }
  }, [location.pathname]);

  // Restore the saved scroll position when arriving at a kept tab
  // (first visits fall back to the top).
  useEffect(() => {
    if (!isKeptTab) return;
    window.scrollTo(0, scrollPositions.current[location.pathname] ?? 0);
  }, [location.pathname, isKeptTab]);

  return (
    <div className="min-h-screen bg-[#FDFBF7] flex flex-col">
      <Navbar />
      <CartDrawer />
      <main className="flex-1 pb-16 md:pb-0">
        {KEPT_TABS.map((tab) => (
          <div key={tab.path} className={location.pathname === tab.path ? undefined : 'hidden'}>
            {tab.element}
          </div>
        ))}
        {!isKeptTab && (
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, x: 32 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -32 }}
              transition={{ duration: 0.25, ease: 'easeOut' }}
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        )}
      </main>
      <BottomNav />
    </div>
  );
}