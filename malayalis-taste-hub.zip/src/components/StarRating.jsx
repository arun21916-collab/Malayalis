import React from 'react';
import { Star } from 'lucide-react';

export default function StarRating({ value = 0, count, size = 'w-3.5 h-3.5' }) {
  return (
    <div className="flex items-center gap-1">
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((n) => (
          <Star
            key={n}
            className={`${size} ${
              n <= Math.round(value) ? 'fill-[#AF8B45] text-[#AF8B45]' : 'text-[#1A322B]/20'
            }`}
          />
        ))}
      </div>
      {typeof count === 'number' && (
        <span className="text-[10px] text-[#1A322B]/50 font-medium">({count})</span>
      )}
    </div>
  );
}