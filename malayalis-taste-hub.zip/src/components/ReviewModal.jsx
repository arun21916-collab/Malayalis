import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Star, X } from 'lucide-react';
import { Image } from '@/components/ui/image';

export default function ReviewModal({ item, onClose, onSubmitted }) {
  const [rating, setRating] = useState(5);
  const [hover, setHover] = useState(0);
  const [reviewText, setReviewText] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    if (rating < 1) {
      setError('Please select a rating.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      await base44.entities.Review.create({
        menu_item_id: item.id,
        item_name: item.name,
        rating,
        review_text: reviewText.trim(),
        customer_name: customerName.trim() || 'Guest',
      });
      onSubmitted && onSubmitted();
      onClose();
    } catch (err) {
      setError('Could not submit your review. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-[#1A322B]/50 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-[#FDFBF7] rounded-lg w-full max-w-md overflow-hidden border border-[#AF8B45]/30"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#AF8B45]/20">
          <h3 className="font-display text-lg font-bold text-[#1A322B]">Rate this dish</h3>
          <button onClick={onClose} className="p-1.5 hover:bg-[#1A322B]/5 rounded-full select-none" aria-label="Close">
            <X className="w-5 h-5 text-[#1A322B]" />
          </button>
        </div>
        <form onSubmit={submit} className="p-5 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded overflow-hidden bg-[#1A322B]/5 flex-shrink-0">
              {item.image_url && (
                <Image src={item.image_url} alt={item.name} className="w-full h-full object-cover" fittingType="fill" />
              )}
            </div>
            <div className="min-w-0">
              <p className="font-display text-base font-semibold text-[#1A322B] leading-tight truncate">{item.name}</p>
              <p className="text-xs text-[#1A322B]/50">{item.price_text}</p>
            </div>
          </div>

          <div className="text-center py-2">
            <div className="flex items-center justify-center gap-1.5">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setRating(n)}
                  onMouseEnter={() => setHover(n)}
                  onMouseLeave={() => setHover(0)}
                  aria-label={`${n} star${n > 1 ? 's' : ''}`}
                  className="p-0.5 select-none"
                >
                  <Star
                    className={`w-8 h-8 ${
                      (hover || rating) >= n ? 'fill-[#AF8B45] text-[#AF8B45]' : 'text-[#1A322B]/25'
                    }`}
                  />
                </button>
              ))}
            </div>
            <p className="text-xs text-[#1A322B]/50 mt-1">{rating} of 5</p>
          </div>

          <textarea
            value={reviewText}
            onChange={(e) => setReviewText(e.target.value)}
            rows={3}
            placeholder="Share your experience..."
            className="w-full p-3 rounded bg-white border border-[#AF8B45]/25 text-sm text-[#1A322B] focus:outline-none focus:border-[#AF8B45]"
          />
          <input
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            placeholder="Your name (optional)"
            className="w-full h-11 px-3 rounded bg-white border border-[#AF8B45]/25 text-sm text-[#1A322B] focus:outline-none focus:border-[#AF8B45]"
          />
          {error && <p className="text-sm text-[#9E2A2B]">{error}</p>}
          <button
            type="submit"
            disabled={saving}
            className="w-full bg-[#1A322B] text-[#FDFBF7] h-12 rounded-full font-semibold disabled:opacity-50 hover:bg-[#AF8B45] hover:text-[#1A322B] transition-colors select-none"
          >
            {saving ? 'Submitting…' : 'Submit Review'}
          </button>
        </form>
      </div>
    </div>
  );
}