import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Image } from '@/components/ui/image';
import { Leaf } from 'lucide-react';
import DietaryBadges from '@/components/DietaryBadges';
import ItemReviews from '@/components/ItemReviews';

// Full item detail view opened by clicking a menu item card.
export default function ItemDetailDialog({ item, open, onOpenChange, reviews, ratingInfo, onReviewSubmitted }) {
  if (!item) return null;
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md p-0 overflow-hidden bg-white border border-[#AF8B45]/20 rounded">
        <div className="relative aspect-[4/3] bg-[#1A322B]/5">
          {item.image_url ? (
            <Image src={item.image_url} alt={item.name} className="w-full h-full object-cover" fittingType="fill" />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <span className="font-display text-[#1A322B]/20 text-4xl">M</span>
            </div>
          )}
          {item.is_vegetarian && (
            <span className="absolute top-2 left-2 bg-white/90 backdrop-blur px-1.5 py-1 rounded-full flex items-center gap-1 text-[10px] font-semibold text-[#4A6741]">
              <Leaf className="w-3 h-3" /> VEG
            </span>
          )}
        </div>
        <div className="p-5">
          <DialogHeader>
            <div className="flex items-start justify-between gap-3 pr-6">
              <DialogTitle className="font-display text-xl font-bold text-[#1A322B] leading-tight">
                {item.name}
              </DialogTitle>
              <span className="font-display text-xl font-bold text-[#AF8B45] whitespace-nowrap">
                {item.price_text}
              </span>
            </div>
          </DialogHeader>
          <p className="text-sm text-[#1A322B]/70 mt-2 leading-relaxed">
            {item.description || 'Authentic Kerala-style preparation, made fresh to order.'}
          </p>
          <DietaryBadges tags={item.tags} className="mt-3" />
          <div className="mt-4 pt-4 border-t border-[#AF8B45]/15">
            <ItemReviews item={item} reviews={reviews} ratingInfo={ratingInfo} onSubmitted={onReviewSubmitted} />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}