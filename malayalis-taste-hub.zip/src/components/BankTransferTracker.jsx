import React from 'react';
import { Check, Landmark, UploadCloud, ShieldCheck, XCircle } from 'lucide-react';

const STAGES = [
  { key: 'pending_transfer', label: 'Bank Transfer', icon: Landmark },
  { key: 'proof_submitted', label: 'Proof Submitted', icon: UploadCloud },
  { key: 'under_verification', label: 'Under Verification', icon: ShieldCheck },
  { key: 'paid', label: 'Payment Confirmed', icon: Check },
];

export default function BankTransferTracker({ paymentStatus, className = '' }) {
  if (paymentStatus === 'payment_rejected') {
    return (
      <div className={`flex items-center gap-3 p-4 rounded bg-red-50 border border-red-200 ${className}`}>
        <XCircle className="w-6 h-6 text-[#9E2A2B] flex-shrink-0" />
        <div>
          <p className="font-display text-base font-bold text-[#9E2A2B]">Payment Rejected</p>
          <p className="text-xs text-[#9E2A2B]/80">Your bank transfer could not be verified. Please contact the restaurant or upload valid payment proof.</p>
        </div>
      </div>
    );
  }

  const currentIndex = STAGES.findIndex((s) => s.key === paymentStatus);
  const reached = currentIndex < 0 ? 0 : currentIndex;

  return (
    <div className={`flex items-start ${className}`}>
      {STAGES.map((stage, i) => {
        const done = i < reached;
        const active = i === reached;
        const isReached = i <= reached;
        const Icon = stage.icon;
        return (
          <div key={stage.key} className="flex-1 flex flex-col items-center relative">
            {i > 0 && (
              <span
                className={`absolute top-5 left-[-50%] w-full h-0.5 ${
                  i <= reached ? 'bg-[#AF8B45]' : 'bg-[#AF8B45]/20'
                }`}
              />
            )}
            <div
              className={`relative z-10 w-10 h-10 rounded-full flex items-center justify-center border-2 transition-colors ${
                active
                  ? 'bg-[#AF8B45] text-white border-[#AF8B45]'
                  : done
                  ? 'bg-[#4A6741] text-white border-[#4A6741]'
                  : 'bg-white text-[#1A322B]/40 border-[#AF8B45]/25'
              }`}
            >
              {done ? <Check className="w-5 h-5" /> : <Icon className="w-4.5 h-4.5" />}
            </div>
            <span
              className={`mt-2 text-[9px] uppercase tracking-wide text-center leading-tight font-semibold ${
                active ? 'text-[#AF8B45]' : isReached ? 'text-[#1A322B]' : 'text-[#1A322B]/40'
              }`}
            >
              {stage.label}
            </span>
          </div>
        );
      })}
    </div>
  );
}