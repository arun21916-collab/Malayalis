import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ShoppingBag, Menu as MenuIcon, X, ChevronLeft } from 'lucide-react';
import { useCart } from '@/context/CartContext';

export default function Navbar() {
  const { totalItems, setIsOpen } = useCart();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const links = [
    { label: 'Home', path: '/' },
    { label: 'Menu', path: '/menu' },
    { label: 'My Orders', path: '/my-orders' },
    { label: 'Track Order', path: '/track' },
    { label: 'Admin', path: '/admin' },
    { label: 'Account', path: '/account-settings' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#FDFBF7]/90 backdrop-blur-md border-b border-[#AF8B45]/20 safe-area-top">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          <div className="flex items-center gap-1">
            {!['/', '/menu', '/my-orders', '/about-us'].includes(location.pathname) && (
              <button
                onClick={() => navigate(-1)}
                className="flex items-center gap-1 h-11 px-1.5 -ml-1.5 text-sm font-semibold text-[#1A322B] hover:text-[#AF8B45] select-none"
                aria-label="Go back"
              >
                <ChevronLeft className="w-5 h-5" /> Back
              </button>
            )}
            <Link to="/" className="flex items-center group" onClick={() => setMobileOpen(false)}>
            <span className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#1A322B]">
              MALAYA<span className="text-[#AF8B45]">LIS</span>
            </span>
          </Link>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            {links.map((l) => (
              <Link
                key={l.path}
                to={l.path}
                className={`text-sm font-medium tracking-wide uppercase transition-colors ${
                  location.pathname === l.path ? 'text-[#AF8B45]' : 'text-[#1A322B] hover:text-[#AF8B45]'
                }`}
              >
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsOpen(true)}
              className="relative h-11 w-11 flex items-center justify-center rounded-full hover:bg-[#1A322B]/5 transition-colors select-none"
              aria-label="Open cart"
            >
              <ShoppingBag className="w-5 h-5 text-[#1A322B]" />
              {totalItems > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-[#9E2A2B] text-white text-[10px] font-bold min-w-5 h-5 px-1 rounded-full flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </button>
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden h-11 w-11 flex items-center justify-center text-[#1A322B] select-none"
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
            </button>
          </div>
        </div>
        {mobileOpen && (
          <nav className="md:hidden pb-4 flex flex-col gap-1 border-t border-[#AF8B45]/20 pt-3">
            {links.map((l) => (
              <Link
                key={l.path}
                to={l.path}
                onClick={() => setMobileOpen(false)}
                className={`text-sm font-medium uppercase py-2.5 tracking-wide ${
                  location.pathname === l.path ? 'text-[#AF8B45]' : 'text-[#1A322B]'
                }`}
              >
                {l.label}
              </Link>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}