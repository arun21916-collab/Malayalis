import { useEffect, useRef, useState } from 'react';

// Pull-to-refresh gesture for touch devices: when the page is scrolled to the
// top and the user swipes down past the threshold, onRefresh fires.
// Returns `refreshing` — true while the refresh callback is in flight.
export default function usePullToRefresh(onRefresh, threshold = 80) {
  const cbRef = useRef(onRefresh);
  cbRef.current = onRefresh;
  const startY = useRef(null);
  const busy = useRef(false);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const onStart = (e) => {
      startY.current = window.scrollY <= 0 ? e.touches[0].clientY : null;
    };
    const onEnd = (e) => {
      if (startY.current === null || busy.current) return;
      const delta = e.changedTouches[0].clientY - startY.current;
      startY.current = null;
      if (delta >= threshold) {
        busy.current = true;
        setRefreshing(true);
        Promise.resolve(cbRef.current()).finally(() => {
          busy.current = false;
          setRefreshing(false);
        });
      }
    };
    window.addEventListener('touchstart', onStart, { passive: true });
    window.addEventListener('touchend', onEnd, { passive: true });
    return () => {
      window.removeEventListener('touchstart', onStart);
      window.removeEventListener('touchend', onEnd);
    };
  }, [threshold]);

  return refreshing;
}