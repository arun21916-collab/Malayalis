import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, ClipboardList, ArrowRight } from 'lucide-react';

export default function TrackOrder() {
  const navigate = useNavigate();
  const [orderNumber, setOrderNumber] = useState('');
  const [error, setError] = useState('');

  const submit = (e) => {
    e.preventDefault();
    const ref = orderNumber.trim().toUpperCase();
    if (!ref) {
      setError('Please enter your order number.');
      return;
    }
    if (ref.startsWith('#')) {
      navigate(`/track/${ref.slice(1)}`);
      return;
    }
    navigate(`/track/${ref}`);
  };

  return (
    <div className="max-w-md mx-auto px-4 sm:px-6 py-12 sm:py-16">
      <div className="bg-white border border-[#AF8B45]/20 rounded-lg p-6 sm:p-8 shadow-sm">
        <div className="text-center">
          <div className="w-14 h-14 rounded-full bg-[#1A322B] flex items-center justify-center mx-auto">
            <Search className="w-6 h-6 text-[#AF8B45]" />
          </div>
          <p className="text-xs uppercase tracking-[0.25em] text-[#AF8B45] font-semibold mt-4">Order Tracking</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#1A322B] mt-2">
            Track your order
          </h1>
          <p className="text-sm text-[#1A322B]/60 mt-2 leading-relaxed">
            Enter the order number from your confirmation email to see the live status of your food preparation.
          </p>
        </div>

        <form onSubmit={submit} className="mt-6">
          <label htmlFor="order-number" className="text-xs font-semibold uppercase tracking-wide text-[#1A322B]/70">
            Order number
          </label>
          <div className="mt-1.5 flex gap-2">
            <div className="relative flex-1">
              <ClipboardList className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#AF8B45]" />
              <input
                id="order-number"
                type="text"
                inputMode="text"
                autoComplete="off"
                autoCapitalize="characters"
                spellCheck={false}
                value={orderNumber}
                onChange={(e) => {
                  setOrderNumber(e.target.value);
                  setError('');
                }}
                placeholder="e.g. MLY123456789"
                className="w-full h-12 pl-10 pr-3 rounded border border-[#AF8B45]/30 bg-[#FDFBF7] text-[#1A322B] font-semibold tracking-wide placeholder:font-normal placeholder:text-[#1A322B]/35 focus:outline-none focus:ring-2 focus:ring-[#AF8B45]/40 focus:border-[#AF8B45]"
              />
            </div>
            <button
              type="submit"
              className="h-12 px-5 rounded bg-[#1A322B] text-[#FDFBF7] font-semibold text-sm inline-flex items-center gap-1.5 hover:bg-[#AF8B45] hover:text-[#1A322B] transition-colors select-none"
            >
              Track <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          {error && <p className="text-xs text-[#9E2A2B] mt-2">{error}</p>}
        </form>

        <p className="text-xs text-[#1A322B]/50 mt-6 text-center leading-relaxed">
          Your order number starts with <span className="font-semibold text-[#AF8B45]">MLY</span> and can also be
          found on the order confirmation page after checkout. The tracking page updates automatically — no
          refreshing needed.
        </p>
      </div>

      <p className="text-center text-sm text-[#1A322B]/60 mt-6">
        Don't have your order number?{' '}
        <Link to="/my-orders" className="text-[#AF8B45] font-semibold hover:underline">
          Find it with your mobile number
        </Link>
      </p>
    </div>
  );
}