import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useCart } from '@/context/CartContext';
import { useToast } from '@/components/ui/use-toast';
import { statusLabel } from '@/components/OrderStatusTracker';
import { ArrowLeft, RotateCw, Receipt, Loader2, ShoppingBag, PackageSearch } from 'lucide-react';
import usePullToRefresh from '@/hooks/use-pull-to-refresh';
import PullToRefreshIndicator from '@/components/PullToRefreshIndicator';
import NotificationPrefsCard from '@/components/NotificationPrefsCard';

const STATUS_TONE = {
  received: 'bg-amber-100 text-amber-800',
  payment_confirmed: 'bg-sky-100 text-sky-800',
  preparing: 'bg-orange-100 text-orange-800',
  ready: 'bg-emerald-100 text-emerald-800',
  out_for_delivery: 'bg-indigo-100 text-indigo-800',
  delivered: 'bg-emerald-100 text-emerald-800',
  completed: 'bg-[#1A322B]/10 text-[#1A322B]',
  cancelled: 'bg-red-100 text-red-700',
};

export default function MyOrders() {
  const { items, addItem, updateQuantity, setIsOpen } = useCart();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [mobile, setMobile] = useState('');
  const [verifiedMobile, setVerifiedMobile] = useState('');
  const [orders, setOrders] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [reorderingId, setReorderingId] = useState(null);

  const handleVerify = async (e) => {
    e.preventDefault();
    setError('');
    if (!mobile.trim()) return setError('Enter the mobile number used to place your orders.');
    setLoading(true);
    try {
      const list = await base44.entities.Order.filter(
        { mobile: mobile.trim() },
        '-created_date',
        50
      );
      setOrders(list);
      setVerifiedMobile(mobile.trim());
    } catch (err) {
      setError('Could not load your orders. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleReorder = async (order) => {
    setReorderingId(order.id);
    try {
      const menu = await base44.entities.MenuItem.list('display_order', 500);
      const byName = {};
      menu.forEach((m) => (byName[m.name.trim().toLowerCase()] = m));

      let added = 0;
      let skipped = [];
      order.items.forEach((oi) => {
        const mi = byName[(oi.name || '').trim().toLowerCase()];
        if (!mi || mi.sold_out || !mi.available) {
          skipped.push(oi.name);
          return;
        }
        const existing = items.find((i) => i.id === mi.id);
        if (existing) {
          updateQuantity(mi.id, existing.quantity + oi.quantity);
        } else {
          addItem(mi);
          updateQuantity(mi.id, oi.quantity);
        }
        added += 1;
      });

      if (added === 0) {
        toast({
          title: 'Nothing to reorder',
          description: 'These items are no longer on the menu.',
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'Added to cart',
          description: skipped.length
            ? `${added} item(s) added. ${skipped.join(', ')} no longer available.`
            : `${added} item(s) from ${order.order_number} added to your cart.`,
        });
        setIsOpen(true);
        navigate('/menu');
      }
    } catch (err) {
      toast({ title: 'Reorder failed', description: 'Please try again.', variant: 'destructive' });
    } finally {
      setReorderingId(null);
    }
  };

  const refresh = async () => {
    if (!verifiedMobile) return;
    try {
      const list = await base44.entities.Order.filter(
        { mobile: verifiedMobile },
        '-created_date',
        50
      );
      setOrders(list);
    } catch (err) {
      // ignore
    }
  };

  const refreshing = usePullToRefresh(refresh);

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10 pb-24">
      <PullToRefreshIndicator active={refreshing} />
      <Link to="/menu" className="inline-flex items-center gap-1 text-sm text-[#1A322B]/60 hover:text-[#AF8B45] mb-6">
        <ArrowLeft className="w-4 h-4" /> Back to menu
      </Link>
      <h1 className="font-display text-4xl font-bold text-[#1A322B] mb-2">My Orders</h1>
      <p className="text-sm text-[#1A322B]/60 mb-8">
        Enter the mobile number you ordered with to view your history and reorder favorites in one tap.
      </p>

      {!verifiedMobile ? (
        <form onSubmit={handleVerify} className="bg-white border border-[#AF8B45]/20 rounded p-6">
          <label className="block text-xs font-semibold uppercase tracking-wide text-[#1A322B]/70 mb-1.5">
            Mobile Number
          </label>
          <input
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
            className="w-full h-12 px-4 rounded bg-[#FDFBF7] border border-[#AF8B45]/25 text-sm focus:outline-none focus:border-[#AF8B45]"
            placeholder="+353 ..."
          />
          {error && <p className="text-sm text-[#9E2A2B] mt-2">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full mt-4 bg-[#1A322B] text-[#FDFBF7] h-12 rounded-full font-semibold disabled:opacity-50 hover:bg-[#AF8B45] hover:text-[#1A322B] transition-colors flex items-center justify-center gap-2"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <PackageSearch className="w-4 h-4" />}
            View my orders
          </button>
        </form>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <p className="text-xs text-[#1A322B]/55">
              Showing orders for <span className="font-semibold text-[#1A322B]">{verifiedMobile}</span>
            </p>
            <button
              onClick={() => {
                setVerifiedMobile('');
                setOrders(null);
                setMobile('');
              }}
              className="text-xs font-semibold text-[#AF8B45] hover:text-[#1A322B] select-none"
            >
              Use a different number
            </button>
          </div>

          <NotificationPrefsCard mobile={verifiedMobile} />

          {loading && (
            <div className="flex justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-[#AF8B45]" />
            </div>
          )}

          {!loading && orders?.length === 0 && (
            <div className="text-center py-16 bg-white border border-[#AF8B45]/15 rounded">
              <Receipt className="w-10 h-10 text-[#AF8B45]/40 mx-auto" />
              <p className="font-display text-xl font-bold text-[#1A322B] mt-3">No orders found</p>
              <p className="text-sm text-[#1A322B]/60 mt-1">We couldn't find any orders for that number.</p>
              <Link
                to="/menu"
                className="inline-flex items-center gap-2 mt-5 bg-[#1A322B] text-[#FDFBF7] px-6 h-11 rounded-full font-semibold"
              >
                Browse the menu
              </Link>
            </div>
          )}

          {orders?.map((o) => (
            <div key={o.id} className="bg-white border border-[#AF8B45]/15 rounded p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-display text-lg font-bold text-[#1A322B] flex flex-wrap items-center gap-2">
                    {o.order_number}
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wide border ${
                        o.order_type === 'delivery'
                          ? 'bg-[#AF8B45]/10 text-[#AF8B45] border-[#AF8B45]/30'
                          : 'bg-[#1A322B]/5 text-[#1A322B] border-[#1A322B]/20'
                      }`}
                    >
                      {o.order_type === 'delivery' ? 'Delivery' : 'Pickup'}
                    </span>
                  </p>
                  <p className="text-xs text-[#1A322B]/55">
                    {new Date(o.created_date).toLocaleDateString(undefined, {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
                <span
                  className={`px-2 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wide ${
                    STATUS_TONE[o.status] || 'bg-gray-100 text-gray-700'
                  }`}
                >
                  {statusLabel(o.status)}
                </span>
              </div>

              <div className="mt-3 space-y-1 text-sm text-[#1A322B]/75">
                {o.items.map((it, i) => (
                  <div key={i} className="flex justify-between">
                    <span className="truncate pr-2">
                      {it.quantity}× {it.name}
                    </span>
                    <span className="text-[#1A322B]/55">€{(it.subtotal || it.price * it.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>

              <div className="mt-3 pt-3 border-t border-[#AF8B45]/15 flex items-center justify-between gap-3 flex-wrap">
                <span className="font-display text-lg font-bold text-[#AF8B45]">€{Number(o.total).toFixed(2)}</span>
                <div className="flex items-center gap-2">
                  <Link
                    to={`/track/${o.order_number}`}
                    className="inline-flex items-center gap-1.5 h-10 px-4 rounded-full border border-[#AF8B45]/30 text-xs font-semibold text-[#1A322B] hover:border-[#AF8B45] select-none"
                  >
                    <Receipt className="w-3.5 h-3.5" /> Track
                  </Link>
                  <button
                    onClick={() => handleReorder(o)}
                    disabled={reorderingId === o.id}
                    className="inline-flex items-center gap-1.5 h-10 px-4 rounded-full bg-[#1A322B] text-[#FDFBF7] text-xs font-semibold hover:bg-[#AF8B45] hover:text-[#1A322B] transition-colors disabled:opacity-50 select-none"
                  >
                    {reorderingId === o.id ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <RotateCw className="w-3.5 h-3.5" />
                    )}
                    Reorder
                  </button>
                </div>
              </div>
            </div>
          ))}

          <div className="mt-6 text-center">
            <Link
              to="/menu"
              className="inline-flex items-center gap-2 text-sm font-semibold text-[#AF8B45] hover:text-[#1A322B]"
            >
              <ShoppingBag className="w-4 h-4" /> Order something new
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}