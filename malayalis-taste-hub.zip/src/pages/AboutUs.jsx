import React from 'react';
import { Link } from 'react-router-dom';
import { Leaf, Heart, UtensilsCrossed, Ship, MapPin } from 'lucide-react';

export default function AboutUs() {
  return (
    <div className="bg-[#FDFBF7]">
      {/* Hero */}
      <section className="relative h-[42vh] min-h-[280px] overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1604908554049-29c4d3a9dadc?auto=format&fit=crop&w=1600&q=80"
          alt="Kerala backwaters"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#1A322B]/70 to-[#1A322B]/30" />
        <div className="relative h-full flex flex-col items-center justify-center text-center px-4">
          <p className="text-[#AF8B45] uppercase tracking-[0.3em] text-xs font-semibold">Our Story</p>
          <h1 className="font-display text-4xl sm:text-5xl font-bold text-[#FDFBF7] mt-3">
            The soul of Malabar, served.
          </h1>
          <p className="text-[#FDFBF7]/80 mt-3 max-w-xl text-sm sm:text-base">
            From the spice coast of Kerala to your table — a taste of home, crafted with tradition.
          </p>
        </div>
      </section>

      {/* Story */}
      <section className="max-w-3xl mx-auto px-4 sm:px-6 py-16">
        <div className="text-center mb-12">
          <div className="kasavu-divider w-24 mx-auto mb-6" />
          <h2 className="font-display text-3xl font-bold text-[#1A322B]">Born from the Coast</h2>
        </div>
        <div className="space-y-6 text-[#1A322B]/75 leading-relaxed">
          <p>
            MALAYALIS began with a simple longing — for the aroma of curry leaves spluttering in
            coconut oil, for the slow-simmered stews of the Malabar coast, for the warmth of a meal
            shared with family. Our founders, homesick for the kitchens of Kerala, set out to bring
            those flavours across the seas.
          </p>
          <p>
            Every dish we serve is a tribute to that heritage. We grind our own masalas, source
            aromatic Malabar spices, and cook each order the way it has been made in Kerala homes for
            generations — patiently, generously, and with deep respect for the craft.
          </p>
          <p>
            From fluffy appams and rich beef curries to the fiery seafood of the backwaters, our menu
            is a journey through the regions that shaped us. This is more than food. It is memory,
            community, and the unmistakable taste of home.
          </p>
        </div>
      </section>

      {/* Values */}
      <section className="bg-[#1A322B] text-[#FDFBF7] py-16">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 grid sm:grid-cols-3 gap-8">
          {[
            { icon: Leaf, title: 'Authentic Ingredients', text: 'Spices sourced from the Malabar coast and ground fresh in our kitchen.' },
            { icon: Heart, title: 'Cooked with Care', text: 'Family recipes, slow-cooked the way they have been for generations.' },
            { icon: UtensilsCrossed, title: 'Generous Portions', text: 'Kerala hospitality means no one leaves the table hungry.' },
          ].map((v) => (
            <div key={v.title} className="text-center">
              <div className="w-14 h-14 rounded-full bg-[#AF8B45]/15 flex items-center justify-center mx-auto mb-4">
                <v.icon className="w-6 h-6 text-[#AF8B45]" />
              </div>
              <h3 className="font-display text-xl font-semibold text-[#AF8B45]">{v.title}</h3>
              <p className="text-sm text-[#FDFBF7]/70 mt-2">{v.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Heritage strip */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 py-16 grid sm:grid-cols-2 gap-8 items-center">
        <div className="rounded overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1583394838336-acd977291f6e?auto=format&fit=crop&w=800&q=80"
            alt="Kerala spices"
            className="w-full h-64 object-cover"
          />
        </div>
        <div>
          <div className="flex items-center gap-2 text-[#AF8B45] mb-3">
            <Ship className="w-5 h-5" />
            <span className="uppercase tracking-widest text-xs font-semibold">The Spice Route</span>
          </div>
          <h2 className="font-display text-2xl font-bold text-[#1A322B] mb-4">
            Flavours that travelled the world
          </h2>
          <p className="text-[#1A322B]/70 leading-relaxed">
            For centuries the Malabar coast was the spice capital of the world — pepper, cardamom
            and cinnamon that shaped cuisines across continents. We honour that legacy in every
            plate, pairing time-honoured technique with the freshest local produce.
          </p>
          <Link
            to="/menu"
            className="inline-flex items-center gap-2 mt-6 bg-[#1A322B] text-[#FDFBF7] px-6 h-12 rounded-full font-semibold hover:bg-[#AF8B45] hover:text-[#1A322B] transition-colors"
          >
            Explore Our Menu
          </Link>
        </div>
      </section>

      {/* Visit */}
      <section className="bg-[#FDFBF7] border-t border-[#AF8B45]/15 py-14">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 text-[#AF8B45] mb-2">
            <MapPin className="w-5 h-5" />
            <span className="uppercase tracking-widest text-xs font-semibold">Visit Us</span>
          </div>
          <h2 className="font-display text-2xl font-bold text-[#1A322B] mb-3">
            Come share a meal with us
          </h2>
          <p className="text-[#1A322B]/70">Main Street, Kerala Town · Malabar Coast</p>
          <p className="text-[#1A322B]/70">+353 1 234 5678</p>
          <Link
            to="/menu"
            className="inline-flex items-center gap-2 mt-6 border border-[#AF8B45]/40 text-[#1A322B] px-6 h-12 rounded-full font-semibold hover:border-[#AF8B45]"
          >
            Order Online
          </Link>
        </div>
      </section>
    </div>
  );
}