import React, { useState, useEffect } from 'react';
import { useNavigate, Link, useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useCart } from '@/context/CartContext';
import { Image } from '@/components/ui/image';
import { ShoppingBag, ArrowLeft, Store, Truck, CreditCard, Banknote, Landmark, Loader2, ShieldCheck } from 'lucide-react';

export default function Checkout() {
  const { items, subtotal, clearCart } = useCart();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const cancelled = searchParams.get('cancelled') === '1';

  const [settings, setSettings] = useState(null);
  const [form, setForm] = useState({
    customer_name: '',
    customer_email: '',
    mobile: '',
    order_type: 'pickup',
    address: '',
    notes: '',
    payment_method: 'card',
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    base44.functions
      .invoke('get_public_settings')
      .then((res) => setSettings(res.data))
      .catch(() =>
        setSettings({ delivery_fee: 3, cash_payment_enabled: true, online_payment_enabled: true })
      );
  }, []);

  // Default to an enabled payment method
  useEffect(() => {
    if (!settings) return;
    const cardOk = settings.online_payment_enabled;
    const cashOk = settings.cash_payment_enabled;
    const bankOk = settings.bank_transfer_enabled;
    if (!cardOk && !cashOk && bankOk) setForm((f) => ({ ...f, payment_method: 'bank_transfer' }));
    else if (!cardOk && cashOk) setForm((f) => ({ ...f, payment_method: 'cash' }));
    else if (cardOk) setForm((f) => ({ ...f, payment_method: 'card' }));
  }, [settings]);

  // A cart item going stale (removed from the menu) should clear any old error
  useEffect(() => {
    setError('');
  }, [items]);

  const deliveryFee = form.order_type === 'delivery' ? settings?.delivery_fee ?? 3 : 0;
  const total = +(subtotal + deliveryFee).toFixed(2);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!form.customer_name.trim()) return setError('Please enter your full name.');
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.customer_email))
      return setError('Please enter a valid email address.');
    if (!form.mobile.trim()) return setError('Please enter your mobile number.');
    if (form.order_type === 'delivery' && !form.address.trim())
      return setError('Please enter a delivery address.');

    // Stripe Checkout redirect only works on the published app, not inside the editor iframe
    if (form.payment_method === 'card' && window.self !== window.top) {
      setError('Card payment is only available on the published app, not in the editor preview.');
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        items: items.map((i) => ({ id: i.id, quantity: i.quantity, name: i.name })),
        customer_name: form.customer_name,
        customer_email: form.customer_email,
        mobile: form.mobile,
        order_type: form.order_type,
        address: form.address,
        notes: form.notes,
        payment_method: form.payment_method,
      };
      const res = await base44.functions.invoke('create_checkout', payload);
      const data = res.data;
      if (data.error) {
        setError(data.error);
        return;
      }
      if (data.checkout_url) {
        // Card: redirect to Stripe; keep cart in case of cancel
        window.location.href = data.checkout_url;
        return;
      }
      if (data.order_id) {
        // Cash or Bank Transfer: order placed
        clearCart();
        if (form.payment_method === 'bank_transfer') {
          navigate(`/bank-transfer?order=${data.order_id}`);
        } else {
          navigate('/order-confirmation', { state: { orderId: data.order_id } });
        }
        return;
      }
      setError('Could not place your order.');
    } catch (err) {
      setError(err.response?.data?.error || 'Could not place your order. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (items.length === 0 && !cancelled) {
    return (
      <div className="max-w-md mx-auto px-4 py-24 text-center">
        <ShoppingBag className="w-12 h-12 text-[#AF8B45]/40 mx-auto" />
        <h1 className="font-display text-2xl font-bold text-[#1A322B] mt-4">Your cart is empty</h1>
        <p className="text-[#1A322B]/60 mt-2">Add some dishes before checking out.</p>
        <Link
          to="/menu"
          className="inline-flex items-center gap-2 mt-6 bg-[#1A322B] text-[#FDFBF7] px-6 h-12 rounded-full font-semibold"
        >
          Browse Menu
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link to="/menu" className="inline-flex items-center gap-1 text-sm text-[#1A322B]/60 hover:text-[#AF8B45] mb-6">
        <ArrowLeft className="w-4 h-4" /> Back to menu
      </Link>
      <h1 className="font-display text-4xl font-bold text-[#1A322B] mb-2">Checkout</h1>
      <p className="text-sm text-[#1A322B]/60 mb-8">
        Secure card payment by Stripe. We never store your card details.
      </p>

      {cancelled && (
        <div className="mb-6 p-4 rounded bg-amber-50 border border-amber-200 text-amber-800 text-sm">
          Your payment was cancelled. Your items are still in the cart — try again when you're ready.
        </div>
      )}

      <form onSubmit={handleSubmit} className="grid lg:grid-cols-2 gap-8">
        <div className="space-y-5">
          <div>
            <label htmlFor="customer_name" className="block text-xs font-semibold uppercase tracking-wide text-[#1A322B]/70 mb-1.5">
              Full Name
            </label>
            <input
              id="customer_name"
              name="customer_name"
              autoComplete="name"
              value={form.customer_name}
              onFocus={(e) => e.target.select()}
              onChange={(e) => setForm({ ...form, customer_name: e.target.value })}
              className="w-full h-12 px-4 rounded bg-white border border-[#AF8B45]/25 text-sm focus:outline-none focus:border-[#AF8B45]"
              placeholder="Your name"
              required
            />
          </div>
          <div>
            <label htmlFor="customer_email" className="block text-xs font-semibold uppercase tracking-wide text-[#1A322B]/70 mb-1.5">
              Email Address
            </label>
            <input
              type="email"
              id="customer_email"
              name="customer_email"
              autoComplete="email"
              value={form.customer_email}
              onFocus={(e) => e.target.select()}
              onChange={(e) => setForm({ ...form, customer_email: e.target.value })}
              className="w-full h-12 px-4 rounded bg-white border border-[#AF8B45]/25 text-sm focus:outline-none focus:border-[#AF8B45]"
              placeholder="you@example.com"
              required
            />
            <p className="text-[11px] text-[#1A322B]/45 mt-1">We'll send your order confirmation here.</p>
          </div>
          <div>
            <label htmlFor="mobile" className="block text-xs font-semibold uppercase tracking-wide text-[#1A322B]/70 mb-1.5">
              Mobile Number
            </label>
            <input
              type="tel"
              id="mobile"
              name="mobile"
              autoComplete="tel"
              value={form.mobile}
              onFocus={(e) => e.target.select()}
              onChange={(e) => setForm({ ...form, mobile: e.target.value })}
              className="w-full h-12 px-4 rounded bg-white border border-[#AF8B45]/25 text-sm focus:outline-none focus:border-[#AF8B45]"
              placeholder="+353 ..."
              required
            />
          </div>
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wide text-[#1A322B]/70 mb-2">
              Delivery Type
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setForm({ ...form, order_type: 'pickup' })}
                className={`flex flex-col items-start gap-1 px-4 py-3 rounded border text-left transition-colors select-none ${
                  form.order_type === 'pickup'
                    ? 'bg-[#1A322B] text-[#FDFBF7] border-[#1A322B]'
                    : 'bg-white text-[#1A322B] border-[#AF8B45]/25'
                }`}
              >
                <span className="flex items-center gap-2 text-sm font-semibold">
                  <Store className="w-4 h-4" /> PICKUP
                </span>
                <span
                  className={`text-[11px] leading-snug ${
                    form.order_type === 'pickup' ? 'text-[#FDFBF7]/70' : 'text-[#1A322B]/55'
                  }`}
                >
                  You collect the order at the restaurant · no delivery fee
                </span>
              </button>
              <button
                type="button"
                onClick={() => setForm({ ...form, order_type: 'delivery' })}
                className={`flex flex-col items-start gap-1 px-4 py-3 rounded border text-left transition-colors select-none ${
                  form.order_type === 'delivery'
                    ? 'bg-[#1A322B] text-[#FDFBF7] border-[#1A322B]'
                    : 'bg-white text-[#1A322B] border-[#AF8B45]/25'
                }`}
              >
                <span className="flex items-center gap-2 text-sm font-semibold">
                  <Truck className="w-4 h-4" /> DELIVERY
                </span>
                <span
                  className={`text-[11px] leading-snug ${
                    form.order_type === 'delivery' ? 'text-[#FDFBF7]/70' : 'text-[#1A322B]/55'
                  }`}
                >
                  We deliver to your address · €{(settings?.delivery_fee ?? 3).toFixed(2)} delivery fee
                </span>
              </button>
            </div>
            {form.order_type === 'pickup' && (
              <p className="text-[11px] text-[#1A322B]/45 mt-1.5">
                No delivery address needed — pickup from the restaurant.
              </p>
            )}
          </div>
          {form.order_type === 'delivery' && (
            <div>
              <label htmlFor="address" className="block text-xs font-semibold uppercase tracking-wide text-[#1A322B]/70 mb-1.5">
                Delivery Address
              </label>
              <textarea
                id="address"
                name="address"
                autoComplete="street-address"
                value={form.address}
                onFocus={(e) => e.target.select()}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                rows={3}
                className="w-full p-4 rounded bg-white border border-[#AF8B45]/25 text-sm focus:outline-none focus:border-[#AF8B45]"
                placeholder="Street, city, postcode"
                required
              />
            </div>
          )}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wide text-[#1A322B]/70 mb-1.5">
              Special Instructions (optional)
            </label>
            <textarea
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              rows={2}
              className="w-full p-4 rounded bg-white border border-[#AF8B45]/25 text-sm focus:outline-none focus:border-[#AF8B45]"
              placeholder="Allergies, preferences..."
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wide text-[#1A322B]/70 mb-2">
              Payment Method
            </label>
            <div className="grid grid-cols-2 gap-3">
              {settings?.online_payment_enabled && (
                <button
                  type="button"
                  onClick={() => setForm({ ...form, payment_method: 'card' })}
                  className={`flex items-center gap-2 h-14 px-4 rounded border text-sm font-semibold transition-colors ${
                    form.payment_method === 'card'
                      ? 'bg-[#1A322B] text-[#FDFBF7] border-[#1A322B]'
                      : 'bg-white text-[#1A322B] border-[#AF8B45]/25'
                  }`}
                >
                  <CreditCard className="w-4 h-4" /> Card
                </button>
              )}
              {settings?.cash_payment_enabled && (
                <button
                  type="button"
                  onClick={() => setForm({ ...form, payment_method: 'cash' })}
                  className={`flex items-center gap-2 h-14 px-4 rounded border text-sm font-semibold transition-colors ${
                    form.payment_method === 'cash'
                      ? 'bg-[#1A322B] text-[#FDFBF7] border-[#1A322B]'
                      : 'bg-white text-[#1A322B] border-[#AF8B45]/25'
                  }`}
                >
                  <Banknote className="w-4 h-4" /> Cash
                </button>
              )}
              {settings?.bank_transfer_enabled && (
                <button
                  type="button"
                  onClick={() => setForm({ ...form, payment_method: 'bank_transfer' })}
                  className={`flex items-center gap-2 h-14 px-4 rounded border text-sm font-semibold transition-colors ${
                    form.payment_method === 'bank_transfer'
                      ? 'bg-[#1A322B] text-[#FDFBF7] border-[#1A322B]'
                      : 'bg-white text-[#1A322B] border-[#AF8B45]/25'
                  }`}
                >
                  <Landmark className="w-4 h-4" /> Bank Transfer
                </button>
              )}
            </div>
            {form.payment_method === 'card' && (
              <p className="text-[11px] text-[#1A322B]/45 mt-1.5">
                Credit / debit cards, Apple Pay &amp; Google Pay are supported at the secure Stripe checkout.
              </p>
            )}
            {form.payment_method === 'cash' && (
              <p className="text-[11px] text-[#1A322B]/45 mt-1.5">
                {form.order_type === 'delivery' ? 'Pay with cash on delivery.' : 'Pay with cash at pickup.'}
              </p>
            )}
            {form.payment_method === 'bank_transfer' && (
              <p className="text-[11px] text-[#1A322B]/45 mt-1.5">
                Transfer to our bank account and upload proof. Payment is verified by our staff before your order is prepared.
              </p>
            )}
          </div>
        </div>

        <div className="bg-white border border-[#AF8B45]/20 rounded p-6 h-fit lg:sticky lg:top-24">
          <h2 className="font-display text-xl font-bold text-[#1A322B] mb-4">Order Summary</h2>
          <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
            {items.map((i) => (
              <div key={i.id} className="flex gap-3 items-center">
                <div className="w-10 h-10 rounded overflow-hidden flex-shrink-0 bg-[#1A322B]/5">
                  {i.image_url && (
                    <Image src={i.image_url} alt={i.name} className="w-full h-full object-cover" fittingType="fill" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[#1A322B] truncate">{i.name}</p>
                  <p className="text-xs text-[#1A322B]/50">
                    {i.quantity} × {i.price_text}
                  </p>
                </div>
                <span className="text-sm font-semibold text-[#1A322B]">€{(i.price * i.quantity).toFixed(2)}</span>
              </div>
            ))}
          </div>
          <div className="border-t border-[#AF8B45]/15 mt-4 pt-4 space-y-2 text-sm">
            <div className="flex justify-between text-[#1A322B]/70">
              <span>Subtotal</span>
              <span>€{subtotal.toFixed(2)}</span>
            </div>
            {form.order_type === 'delivery' && (
              <div className="flex justify-between text-[#1A322B]/70">
                <span>Delivery Fee</span>
                <span>€{deliveryFee.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between font-display text-xl font-bold text-[#1A322B] pt-2">
              <span>Total</span>
              <span>€{total.toFixed(2)}</span>
            </div>
          </div>
          {error && <p className="text-sm text-[#9E2A2B] mt-3">{error}</p>}
          <button
            type="submit"
            disabled={submitting || !settings}
            className="w-full bg-[#1A322B] text-[#FDFBF7] h-14 rounded-full font-semibold mt-4 disabled:opacity-50 hover:bg-[#AF8B45] hover:text-[#1A322B] transition-colors flex items-center justify-center gap-2"
          >
            {submitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" /> Processing…
              </>
            ) : form.payment_method === 'card' ? (
              <>
                <ShieldCheck className="w-4 h-4" /> Pay Securely
              </>
            ) : (
              'Place Order'
            )}
          </button>
          <p className="text-[11px] text-[#1A322B]/45 text-center mt-3 flex items-center justify-center gap-1">
            <ShieldCheck className="w-3 h-3" /> Payments secured by Stripe · PCI-compliant
          </p>
        </div>
      </form>
    </div>
  );
}