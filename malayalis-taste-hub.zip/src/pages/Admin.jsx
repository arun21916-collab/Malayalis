import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import {
  ShoppingBag, UtensilsCrossed, Plus, Trash2, X, ArrowLeft, RefreshCw,
  Mail, Phone, Settings as SettingsIcon, CreditCard, Banknote, Save, TrendingUp, DollarSign, CalendarDays, CheckCircle2, Truck, Store, Landmark, ExternalLink, Inbox,
} from 'lucide-react';
import OrderStatusTracker, { statusLabel } from '@/components/OrderStatusTracker';
import DietaryBadges, { BADGE_OPTIONS } from '@/components/DietaryBadges';
import SyncedOrdersPanel from '@/components/SyncedOrdersPanel';
import NewOrderAlertWatcher from '@/components/NewOrderAlertWatcher';
import ThemeSelect from '@/components/ThemeSelect';

const STATUSES = ['received', 'payment_confirmed', 'preparing', 'ready', 'out_for_delivery', 'delivered', 'completed', 'cancelled'];
const STATUS_STYLE = {
  received: 'bg-amber-500/15 text-amber-300 border-amber-500/40',
  payment_confirmed: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40',
  preparing: 'bg-sky-500/15 text-sky-300 border-sky-500/40',
  ready: 'bg-teal-500/15 text-teal-300 border-teal-500/40',
  out_for_delivery: 'bg-violet-500/15 text-violet-300 border-violet-500/40',
  delivered: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/40',
  completed: 'bg-zinc-500/15 text-zinc-300 border-zinc-500/40',
  cancelled: 'bg-red-500/15 text-red-300 border-red-500/40',
};
const PAY_STYLE = {
  paid: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40',
  pending: 'bg-amber-500/15 text-amber-300 border-amber-500/40',
  failed: 'bg-red-500/15 text-red-300 border-red-500/40',
  refunded: 'bg-zinc-500/15 text-zinc-300 border-zinc-500/40',
};
const BANK_PAY_STYLE = {
  pending_transfer: 'bg-zinc-500/15 text-zinc-300 border-zinc-500/40',
  proof_submitted: 'bg-sky-500/15 text-sky-300 border-sky-500/40',
  under_verification: 'bg-violet-500/15 text-violet-300 border-violet-500/40',
  payment_rejected: 'bg-red-500/15 text-red-300 border-red-500/40',
  paid: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40',
};
const CATS = [
  'Hot', 'Juice', 'Snacks', 'Breakfast', 'Chinese', 'Vegetables', 'Chicken Variety',
  'Beef Variety', 'Seafood', 'Fry & Dry', 'Fried Rice', 'Lunch', 'Soup', 'Soft Drinks', 'Water',
];
const DEFAULT_SETTINGS = {
  restaurant_order_email: '',
  delivery_fee: 3,
  cash_payment_enabled: true,
  online_payment_enabled: true,
  contact_phone: '+353 1 234 5678',
  contact_email: 'orders@malayalis.example',
  address: 'Main Street, Kerala Town, Malabar Coast',
  bank_transfer_enabled: true,
  bank_beneficiary_name: 'Arunkumar Mahalingam',
  bank_iban: 'LT44 3250 0529 2803 7443',
  bank_bic: 'REVOLT21',
  bank_name: 'Revolut Bank UAB',
  bank_address: 'Konstitucijos ave. 21B, 08130, Vilnius, Lithuania',
  bank_correspondent_bic: 'CHASDEFX',
  bank_payment_instructions: 'Please include your Order ID as the payment reference when making the bank transfer.',
  bank_proof_max_size_mb: 5,
};

export default function Admin() {
  const [tab, setTab] = useState('orders');
  const [orders, setOrders] = useState([]);
  const [menu, setMenu] = useState([]);
  const [settings, setSettings] = useState(null);
  const [settingsForm, setSettingsForm] = useState(DEFAULT_SETTINGS);
  const [savingSettings, setSavingSettings] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [statusFilter, setStatusFilter] = useState('all');
  const [actioning, setActioning] = useState(null);
  const [audit, setAudit] = useState([]);

  const load = async () => {
    try {
      const [o, m, s, a] = await Promise.all([
        base44.entities.Order.list('-created_date', 100),
        base44.entities.MenuItem.list('display_order', 300),
        base44.entities.Settings.list(),
        base44.entities.BankAuditLog.list('-created_date', 20),
      ]);
      setOrders(o);
      setMenu(m);
      setSettings(s[0] || null);
      setSettingsForm({ ...DEFAULT_SETTINGS, ...(s[0] || {}) });
      setAudit(a);
    } catch (e) {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const updateOrderStatus = async (id, status) => {
    try {
      const res = await base44.functions.invoke('set_order_status', { order_id: id, status });
      if (res.data?.error) { alert(res.data.error); return; }
      setOrders((p) => p.map((o) => (o.id === id ? { ...o, status } : o)));
    } catch (e) {
      alert(e.response?.data?.error || 'Could not update order status.');
    }
  };

  const acceptOrder = async (id) => {
    await updateOrderStatus(id, 'preparing');
  };

  const refundOrCancel = async (o) => {
    if (!confirm(`Cancel order #${o.order_number}?${o.paid ? ' A refund will be issued via Stripe.' : ''}`)) return;
    setActioning(o.id);
    try {
      await base44.functions.invoke('refund_order', { order_id: o.id });
      setOrders((p) =>
        p.map((x) => (x.id === o.id ? { ...x, status: 'cancelled', payment_status: x.paid ? 'refunded' : x.payment_status } : x))
      );
    } catch (e) {
      alert(e.response?.data?.error || 'Could not process refund.');
    } finally {
      setActioning(null);
    }
  };

  const verifyBank = async (o, action) => {
    try {
      const res = await base44.functions.invoke('verify_bank_payment', { order_id: o.id, action });
      if (res.data?.error) { alert(res.data.error); return; }
      setOrders((p) => p.map((x) => (x.id === o.id ? {
        ...x,
        payment_status: res.data.payment_status,
        paid: action === 'confirm' ? true : x.paid,
        status: action === 'confirm' ? 'payment_confirmed' : x.status,
      } : x)));
    } catch (e) {
      alert(e.response?.data?.error || 'Could not update payment status.');
    }
  };

  const saveSettings = async () => {
    setSavingSettings(true);
    try {
      const res = await base44.functions.invoke('save_settings', settingsForm);
      if (res.data?.error) { alert(res.data.error); return; }
      setSettings(res.data.settings || null);
      try {
        const a = await base44.entities.BankAuditLog.list('-created_date', 20);
        setAudit(a);
      } catch (e) {}
      alert(res.data.bank_changes ? `Settings saved. ${res.data.bank_changes} bank-detail change(s) audit-logged.` : 'Settings saved.');
    } catch (e) {
      alert(e.response?.data?.error || 'Could not save settings.');
    } finally {
      setSavingSettings(false);
    }
  };

  const toggleField = async (id, field, val) => {
    await base44.entities.MenuItem.update(id, { [field]: val });
    setMenu((p) => p.map((i) => (i.id === id ? { ...i, [field]: val } : i)));
  };

  const toggleTag = async (item, key) => {
    const current = item.tags || [];
    const tags = current.includes(key) ? current.filter((t) => t !== key) : [...current, key];
    await base44.entities.MenuItem.update(item.id, { tags });
    setMenu((p) => p.map((i) => (i.id === item.id ? { ...i, tags } : i)));
  };

  const savePrice = async (id, price) => {
    const p = parseFloat(price);
    if (isNaN(p) || p < 0) return;
    const price_text = '€' + p.toFixed(2);
    await base44.entities.MenuItem.update(id, { price: p, price_text });
    setMenu((prev) => prev.map((i) => (i.id === id ? { ...i, price: p, price_text } : i)));
  };

  const deleteItem = async (id) => {
    if (!confirm('Remove this menu item?')) return;
    await base44.entities.MenuItem.delete(id);
    setMenu((p) => p.filter((i) => i.id !== id));
  };

  // --- Stats ---
  const todayStr = new Date().toDateString();
  const todayOrders = orders.filter((o) => new Date(o.created_date).toDateString() === todayStr);
  const totalSales = orders.filter((o) => o.paid).reduce((s, o) => s + (o.total || 0), 0);
  const todayRevenue = todayOrders.filter((o) => o.paid).reduce((s, o) => s + (o.total || 0), 0);
  const newCount = orders.filter((o) => o.status === 'received' || o.status === 'payment_confirmed').length;
  const preparingCount = orders.filter((o) => o.status === 'preparing').length;
  const readyCount = orders.filter((o) => o.status === 'ready').length;

  const filteredOrders = statusFilter === 'all' ? orders : orders.filter((o) => o.status === statusFilter);

  const StatCard = ({ icon: Icon, label, value }) => (
    <div className="bg-[#1A322B] border border-[#AF8B45]/15 rounded p-4">
      <div className="flex items-center gap-2 text-[#AF8B45] mb-1">
        <Icon className="w-4 h-4" />
        <span className="text-[11px] uppercase tracking-wide text-[#FDFBF7]/50">{label}</span>
      </div>
      <p className="font-display text-2xl font-bold text-[#FDFBF7]">{value}</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#14241F] text-[#FDFBF7]">
      <NewOrderAlertWatcher />
      <header className="border-b border-[#AF8B45]/20 bg-[#1A322B] sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="font-display text-xl font-bold">
              MALAYA<span className="text-[#AF8B45]">LIS</span>
            </span>
            <span className="text-xs uppercase tracking-widest text-[#AF8B45] border-l border-[#AF8B45]/30 pl-3 hidden sm:inline">
              Kitchen Command
            </span>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={load} className="p-2 hover:bg-white/5 rounded-full" aria-label="Refresh">
              <RefreshCw className="w-4 h-4 text-[#AF8B45]" />
            </button>
            <Link to="/" className="flex items-center gap-1 text-sm text-[#FDFBF7]/70 hover:text-[#AF8B45]">
              <ArrowLeft className="w-4 h-4" /> Storefront
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-2 mb-8 overflow-x-auto">
          {[
            { key: 'orders', icon: ShoppingBag, label: 'Orders' },
            { key: 'menu', icon: UtensilsCrossed, label: `Menu (${menu.length})` },
            { key: 'incoming', icon: Inbox, label: 'Incoming Orders' },
            { key: 'settings', icon: SettingsIcon, label: 'Settings' },
          ].map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex items-center gap-2 px-5 h-11 rounded-full text-sm font-semibold transition-colors whitespace-nowrap ${
                tab === t.key ? 'bg-[#AF8B45] text-[#1A322B]' : 'bg-white/5 text-[#FDFBF7]/70 hover:bg-white/10'
              }`}
            >
              <t.icon className="w-4 h-4" /> {t.label}
              {t.key === 'orders' && newCount > 0 && (
                <span className="bg-red-500 text-white text-[10px] px-1.5 rounded-full">{newCount}</span>
              )}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="text-center py-20 text-[#FDFBF7]/50">Loading…</div>
        ) : tab === 'orders' ? (
          <>
            {/* Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
              <StatCard icon={DollarSign} label="Total Sales" value={`€${totalSales.toFixed(2)}`} />
              <StatCard icon={CalendarDays} label="Today's Orders" value={todayOrders.length} />
              <StatCard icon={TrendingUp} label="Today's Revenue" value={`€${todayRevenue.toFixed(2)}`} />
              <StatCard icon={CheckCircle2} label="New / Preparing / Ready" value={`${newCount} / ${preparingCount} / ${readyCount}`} />
            </div>

            {/* Filters */}
            <div className="flex gap-2 mb-6 overflow-x-auto pb-1">
              <button
                onClick={() => setStatusFilter('all')}
                className={`px-3 h-8 rounded-full text-xs font-medium whitespace-nowrap ${
                  statusFilter === 'all' ? 'bg-white/15 text-white' : 'text-[#FDFBF7]/50 hover:text-white'
                }`}
              >
                All ({orders.length})
              </button>
              {STATUSES.map((s) => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={`px-3 h-8 rounded-full text-xs font-medium whitespace-nowrap capitalize ${
                    statusFilter === s ? 'bg-white/15 text-white' : 'text-[#FDFBF7]/50 hover:text-white'
                  }`}
                >
                  {s.replace(/_/g, ' ')} ({orders.filter((o) => o.status === s).length})
                </button>
              ))}
            </div>

            {filteredOrders.length === 0 ? (
              <div className="text-center py-20 text-[#FDFBF7]/40">No orders yet.</div>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {filteredOrders.map((o) => (
                  <div key={o.id} className="bg-[#1A322B] border border-[#AF8B45]/15 rounded p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="font-display text-lg font-bold text-[#AF8B45]">#{o.order_number}</p>
                        <p className="text-sm text-[#FDFBF7]/80 flex items-center gap-1.5">
                          {o.customer_name}
                          <a href={`tel:${o.mobile}`} className="text-[#AF8B45] hover:underline flex items-center gap-0.5">
                            <Phone className="w-3 h-3" /> {o.mobile}
                          </a>
                        </p>
                        {o.customer_email && (
                          <a href={`mailto:${o.customer_email}`} className="text-xs text-[#FDFBF7]/60 hover:text-[#AF8B45] flex items-center gap-1 mt-0.5">
                            <Mail className="w-3 h-3" /> {o.customer_email}
                          </a>
                        )}
                        <p className="text-xs text-[#FDFBF7]/50 mt-1 capitalize flex items-center gap-1">
                          {o.order_type === 'delivery' ? <Truck className="w-3 h-3 inline" /> : <Store className="w-3 h-3 inline" />} {o.order_type} · {o.estimated_time}
                        </p>
                        <p className="text-xs text-[#FDFBF7]/40 mt-0.5">
                          {new Date(o.created_date).toLocaleString('en-IE', { dateStyle: 'medium', timeStyle: 'short' })}
                        </p>
                        {o.address && <p className="text-xs text-[#FDFBF7]/50 mt-1">{o.address}</p>}
                        {o.notes && <p className="text-xs text-[#FDFBF7]/50 mt-1 italic">"{o.notes}"</p>}
                      </div>
                      <div className="flex flex-col items-end gap-1.5">
                        <span className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full border whitespace-nowrap ${STATUS_STYLE[o.status]}`}>
                          {statusLabel(o.status)}
                        </span>
                        <span className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full border whitespace-nowrap flex items-center gap-1 ${PAY_STYLE[o.payment_status] || BANK_PAY_STYLE[o.payment_status] || ''}`}>
                          {o.payment_method === 'card' ? <CreditCard className="w-3 h-3" /> : o.payment_method === 'bank_transfer' ? <Landmark className="w-3 h-3" /> : <Banknote className="w-3 h-3" />}
                          {o.payment_status.replace(/_/g, ' ')}
                        </span>
                      </div>
                    </div>

                    <div className="mt-4 space-y-1 border-t border-[#AF8B45]/15 pt-3">
                      {(o.items || []).map((it, i) => (
                        <div key={i} className="flex justify-between text-sm">
                          <span className="text-[#FDFBF7]/80">{it.quantity}× {it.name}</span>
                          <span className="text-[#FDFBF7]/60">€{it.subtotal.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>

                    <div className="mt-3 pt-2 text-xs text-[#FDFBF7]/60 space-y-0.5">
                      <div className="flex justify-between"><span>Subtotal</span><span>€{(o.subtotal ?? o.total ?? 0).toFixed(2)}</span></div>
                      {o.delivery_fee > 0 && <div className="flex justify-between"><span>Delivery fee</span><span>€{(o.delivery_fee ?? 0).toFixed(2)}</span></div>}
                      <div className="flex justify-between font-display text-base font-bold text-[#FDFBF7] pt-1"><span>Total</span><span>€{(o.total ?? 0).toFixed(2)}</span></div>
                    </div>

                    {o.payment_method === 'bank_transfer' && o.payment_status !== 'paid' && (
                      <div className="mt-4 pt-3 border-t border-[#AF8B45]/15">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs uppercase tracking-wide text-[#AF8B45] font-semibold flex items-center gap-1"><Landmark className="w-3.5 h-3.5" /> Bank Transfer</span>
                          <span className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full border ${BANK_PAY_STYLE[o.payment_status] || 'bg-amber-500/15 text-amber-300 border-amber-500/40'}`}>
                            {o.payment_status.replace(/_/g, ' ')}
                          </span>
                        </div>
                        {o.payment_proof_url && (
                          <a href={o.payment_proof_url} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 text-xs text-[#AF8B45] hover:underline mb-3">
                            <ExternalLink className="w-3 h-3" /> View Payment Proof
                          </a>
                        )}
                        {['proof_submitted', 'under_verification'].includes(o.payment_status) && (
                          <div className="flex flex-wrap gap-2 mt-2">
                            {o.payment_status === 'proof_submitted' && (
                              <button onClick={() => verifyBank(o, 'verify')} className="bg-white/10 text-[#FDFBF7] px-3 h-9 rounded text-xs font-semibold hover:bg-white/20">Start Verification</button>
                            )}
                            <button onClick={() => verifyBank(o, 'confirm')} className="bg-emerald-600 text-white px-3 h-9 rounded text-xs font-semibold hover:bg-emerald-500">Confirm Payment</button>
                            <button onClick={() => verifyBank(o, 'reject')} className="bg-red-500/80 text-white px-3 h-9 rounded text-xs font-semibold hover:bg-red-500">Reject Payment</button>
                          </div>
                        )}
                      </div>
                    )}

                    <div className="mt-4 pt-3 border-t border-[#AF8B45]/15">
                      {(o.status === 'received' || o.status === 'payment_confirmed') && (
                        <button
                          onClick={() => acceptOrder(o.id)}
                          className="w-full mb-3 bg-[#AF8B45] text-[#1A322B] h-10 rounded font-semibold text-sm hover:bg-[#FDFBF7]"
                        >
                          Accept Order
                        </button>
                      )}
                      <OrderStatusTracker order={o} onChange={(s) => updateOrderStatus(o.id, s)} />
                      {o.status !== 'cancelled' && (
                        <button
                          onClick={() => refundOrCancel(o)}
                          disabled={actioning === o.id}
                          className="mt-3 text-xs text-red-300 hover:text-red-200 hover:underline disabled:opacity-50"
                        >
                          {actioning === o.id ? 'Processing…' : o.paid ? 'Refund & Cancel' : 'Cancel order'}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        ) : tab === 'menu' ? (
          <>
            <div className="flex justify-between items-center mb-6">
              <p className="text-sm text-[#FDFBF7]/60">Manage items, prices &amp; availability</p>
              <button
                onClick={() => setShowAdd(true)}
                className="flex items-center gap-1.5 bg-[#AF8B45] text-[#1A322B] px-4 h-10 rounded-full text-sm font-semibold hover:bg-[#FDFBF7]"
              >
                <Plus className="w-4 h-4" /> Add Item
              </button>
            </div>
            <div className="space-y-2">
              {menu.map((item) => (
                <div key={item.id} className="flex flex-wrap items-center gap-3 bg-[#1A322B] border border-[#AF8B45]/15 rounded p-3">
                  <div className="w-12 h-12 rounded overflow-hidden bg-white/5 flex-shrink-0">
                    {item.image_url && <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">{item.name}</p>
                    <p className="text-xs text-[#FDFBF7]/50">{item.category}</p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {BADGE_OPTIONS.map((b) => {
                        const active = (item.tags || []).includes(b.key);
                        return (
                          <button
                            key={b.key}
                            type="button"
                            onClick={() => toggleTag(item, b.key)}
                            className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full border text-[9px] font-semibold uppercase tracking-wide select-none ${
                              active
                                ? 'bg-[#AF8B45]/20 text-[#AF8B45] border-[#AF8B45]/40'
                                : 'bg-[#14241F] text-[#FDFBF7]/35 border-[#FDFBF7]/15 hover:border-[#AF8B45]/40'
                            }`}
                          >
                            <b.icon className="w-2.5 h-2.5" /> {b.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <input
                    type="number"
                    step="0.25"
                    defaultValue={item.price}
                    onBlur={(e) => savePrice(item.id, e.target.value)}
                    className="w-20 bg-[#14241F] text-sm rounded px-2 h-9 border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45]"
                    aria-label="Price"
                  />
                  <label className="flex items-center gap-1.5 text-xs cursor-pointer whitespace-nowrap">
                    <input type="checkbox" checked={item.available} onChange={(e) => toggleField(item.id, 'available', e.target.checked)} className="accent-[#AF8B45]" /> Available
                  </label>
                  <label className="flex items-center gap-1.5 text-xs cursor-pointer whitespace-nowrap">
                    <input type="checkbox" checked={item.sold_out} onChange={(e) => toggleField(item.id, 'sold_out', e.target.checked)} className="accent-[#9E2A2B]" /> Sold Out
                  </label>
                  <button onClick={() => deleteItem(item.id)} className="p-2 text-red-300 hover:bg-red-500/10 rounded-full" aria-label="Delete">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </>
        ) : tab === 'incoming' ? (
          <SyncedOrdersPanel />
        ) : (
          /* Settings tab */
          <div className="max-w-xl bg-[#1A322B] border border-[#AF8B45]/15 rounded p-6 space-y-5">
            <div>
              <h2 className="font-display text-xl font-bold text-[#AF8B45]">Restaurant Settings</h2>
              <p className="text-sm text-[#FDFBF7]/60 mt-1">Configure payments, delivery fees and order notifications.</p>
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wide text-[#FDFBF7]/60 mb-1.5">Restaurant Order Email</label>
              <input
                type="email"
                value={settingsForm.restaurant_order_email}
                onChange={(e) => setSettingsForm({ ...settingsForm, restaurant_order_email: e.target.value })}
                className="w-full bg-[#14241F] rounded px-3 h-11 text-sm border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45]"
                placeholder="orders@malayalis.example"
              />
              <p className="text-[11px] text-[#FDFBF7]/40 mt-1">New order notifications are sent here.</p>
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wide text-[#FDFBF7]/60 mb-1.5">Delivery Fee (€)</label>
              <input
                type="number"
                step="0.5"
                value={settingsForm.delivery_fee}
                onChange={(e) => setSettingsForm({ ...settingsForm, delivery_fee: parseFloat(e.target.value) || 0 })}
                className="w-full bg-[#14241F] rounded px-3 h-11 text-sm border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-[#14241F] rounded p-3 border border-[#AF8B45]/20">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-sm font-medium">Online Payment</span>
                  <input
                    type="checkbox"
                    checked={settingsForm.online_payment_enabled}
                    onChange={(e) => setSettingsForm({ ...settingsForm, online_payment_enabled: e.target.checked })}
                    className="accent-[#AF8B45] w-4 h-4"
                  />
                </label>
              </div>
              <div className="bg-[#14241F] rounded p-3 border border-[#AF8B45]/20">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-sm font-medium">Cash Payment</span>
                  <input
                    type="checkbox"
                    checked={settingsForm.cash_payment_enabled}
                    onChange={(e) => setSettingsForm({ ...settingsForm, cash_payment_enabled: e.target.checked })}
                    className="accent-[#AF8B45] w-4 h-4"
                  />
                </label>
              </div>
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wide text-[#FDFBF7]/60 mb-1.5">Contact Phone</label>
              <input
                value={settingsForm.contact_phone}
                onChange={(e) => setSettingsForm({ ...settingsForm, contact_phone: e.target.value })}
                className="w-full bg-[#14241F] rounded px-3 h-11 text-sm border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45]"
              />
            </div>
            <div>
              <label className="block text-xs uppercase tracking-wide text-[#FDFBF7]/60 mb-1.5">Restaurant Address</label>
              <input
                value={settingsForm.address}
                onChange={(e) => setSettingsForm({ ...settingsForm, address: e.target.value })}
                className="w-full bg-[#14241F] rounded px-3 h-11 text-sm border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45]"
              />
            </div>

            <div className="pt-2 border-t border-[#AF8B45]/15">
              <h3 className="font-display text-base font-bold text-[#AF8B45] mt-3 mb-1 flex items-center gap-2">
                <Landmark className="w-4 h-4" /> Bank Transfer
              </h3>
              <p className="text-sm text-[#FDFBF7]/60 mb-3">Bank details shown to customers at checkout. Every change is audit-logged.</p>
              <label className="flex items-center justify-between bg-[#14241F] rounded p-3 border border-[#AF8B45]/20 cursor-pointer mb-3">
                <span className="text-sm font-medium">Enable Bank Transfer</span>
                <input type="checkbox" checked={!!settingsForm.bank_transfer_enabled} onChange={(e) => setSettingsForm({ ...settingsForm, bank_transfer_enabled: e.target.checked })} className="accent-[#AF8B45] w-4 h-4" />
              </label>
              <input value={settingsForm.bank_beneficiary_name || ''} onChange={(e) => setSettingsForm({ ...settingsForm, bank_beneficiary_name: e.target.value })} placeholder="Beneficiary name" className="w-full bg-[#14241F] rounded px-3 h-11 text-sm border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45] mb-2" />
              <input value={settingsForm.bank_iban || ''} onChange={(e) => setSettingsForm({ ...settingsForm, bank_iban: e.target.value })} placeholder="IBAN" className="w-full bg-[#14241F] rounded px-3 h-11 text-sm border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45] mb-2" />
              <input value={settingsForm.bank_bic || ''} onChange={(e) => setSettingsForm({ ...settingsForm, bank_bic: e.target.value })} placeholder="BIC / SWIFT" className="w-full bg-[#14241F] rounded px-3 h-11 text-sm border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45] mb-2" />
              <input value={settingsForm.bank_name || ''} onChange={(e) => setSettingsForm({ ...settingsForm, bank_name: e.target.value })} placeholder="Bank name" className="w-full bg-[#14241F] rounded px-3 h-11 text-sm border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45] mb-2" />
              <input value={settingsForm.bank_address || ''} onChange={(e) => setSettingsForm({ ...settingsForm, bank_address: e.target.value })} placeholder="Bank address" className="w-full bg-[#14241F] rounded px-3 h-11 text-sm border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45] mb-2" />
              <input value={settingsForm.bank_correspondent_bic || ''} onChange={(e) => setSettingsForm({ ...settingsForm, bank_correspondent_bic: e.target.value })} placeholder="Correspondent BIC" className="w-full bg-[#14241F] rounded px-3 h-11 text-sm border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45] mb-2" />
              <textarea value={settingsForm.bank_payment_instructions || ''} onChange={(e) => setSettingsForm({ ...settingsForm, bank_payment_instructions: e.target.value })} rows={2} placeholder="Payment instructions" className="w-full bg-[#14241F] rounded p-3 text-sm border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45] mb-2" />
              <label className="block text-xs uppercase tracking-wide text-[#FDFBF7]/60 mb-1.5">Payment Proof Max Size (MB)</label>
              <input type="number" step="1" min="1" value={settingsForm.bank_proof_max_size_mb ?? 5} onChange={(e) => setSettingsForm({ ...settingsForm, bank_proof_max_size_mb: parseFloat(e.target.value) || 5 })} className="w-full bg-[#14241F] rounded px-3 h-11 text-sm border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45]" />
            </div>

            <button
              onClick={saveSettings}
              disabled={savingSettings}
              className="w-full bg-[#AF8B45] text-[#1A322B] h-11 rounded font-semibold flex items-center justify-center gap-2 hover:bg-[#FDFBF7] disabled:opacity-50"
            >
              <Save className="w-4 h-4" /> {savingSettings ? 'Saving…' : 'Save Settings'}
            </button>
            <p className="text-[11px] text-[#FDFBF7]/40">
              Sensitive keys (Stripe, email service) are stored server-side as environment secrets — never in the frontend. Bank-detail changes require admin access and are audit-logged.
            </p>

            {audit.length > 0 && (
              <div className="pt-4 border-t border-[#AF8B45]/15">
                <h3 className="font-display text-base font-bold text-[#AF8B45] mb-2">Bank Detail Audit Log</h3>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {audit.map((log) => (
                    <div key={log.id} className="bg-[#14241F] rounded p-2.5 border border-[#AF8B45]/15">
                      <div className="flex justify-between text-[10px] text-[#FDFBF7]/50 mb-1">
                        <span>{log.performed_by_email || 'admin'}</span>
                        <span>{new Date(log.created_date).toLocaleString('en-IE', { dateStyle: 'short', timeStyle: 'short' })}</span>
                      </div>
                      {(log.changes || []).map((c, i) => (
                        <p key={i} className="text-[11px] text-[#FDFBF7]/70">
                          <span className="text-[#AF8B45]">{c.field}</span>: {String(c.from ?? '') || '∅'} → {String(c.to ?? '') || '∅'}
                        </p>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {showAdd && <AddItemModal cats={CATS} onClose={() => setShowAdd(false)} onAdded={() => { setShowAdd(false); load(); }} />}
    </div>
  );
}

function AddItemModal({ cats, onClose, onAdded }) {
  const [form, setForm] = useState({
    name: '', category: cats[0], price: '', is_vegetarian: false, is_popular: false, image_url: '', tags: [],
  });
  const [saving, setSaving] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (!form.name) return;
    setSaving(true);
    const p = parseFloat(form.price) || 0;
    await base44.entities.MenuItem.create({
      name: form.name, category: form.category, price: p, price_text: '€' + p.toFixed(2),
      description: '', image_url: form.image_url, is_vegetarian: form.is_vegetarian,
      is_popular: form.is_popular, available: true, sold_out: false, display_order: 999, tags: form.tags,
    });
    onAdded();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-[#1A322B] rounded-lg w-full max-w-md p-6 border border-[#AF8B45]/30" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-display text-xl font-bold text-[#AF8B45]">Add Menu Item</h3>
          <button onClick={onClose} className="p-1 hover:bg-white/5 rounded" aria-label="Close"><X className="w-5 h-5" /></button>
        </div>
        <form onSubmit={submit} className="space-y-3">
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Item name" className="w-full bg-[#14241F] rounded px-3 h-11 text-sm border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45]" required />
          <ThemeSelect value={form.category} onChange={(v) => setForm({ ...form, category: v })} options={cats} />
          <input value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="Price (€)" type="number" step="0.25" className="w-full bg-[#14241F] rounded px-3 h-11 text-sm border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45]" />
          <input value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} placeholder="Image URL (optional)" className="w-full bg-[#14241F] rounded px-3 h-11 text-sm border border-[#AF8B45]/30 focus:outline-none focus:border-[#AF8B45]" />
          <div>
            <p className="text-xs text-[#FDFBF7]/60 mb-1.5">Dietary badges</p>
            <div className="flex flex-wrap gap-1.5">
              {BADGE_OPTIONS.map((b) => {
                const active = form.tags.includes(b.key);
                return (
                  <button
                    key={b.key}
                    type="button"
                    onClick={() =>
                      setForm((f) => ({
                        ...f,
                        tags: active ? f.tags.filter((t) => t !== b.key) : [...f.tags, b.key],
                      }))
                    }
                    className={`inline-flex items-center gap-1 px-2 py-1 rounded-full border text-[10px] font-semibold uppercase tracking-wide select-none ${
                      active
                        ? 'bg-[#AF8B45]/20 text-[#AF8B45] border-[#AF8B45]/40'
                        : 'bg-[#14241F] text-[#FDFBF7]/40 border-[#FDFBF7]/15 hover:border-[#AF8B45]/40'
                    }`}
                  >
                    <b.icon className="w-3 h-3" /> {b.label}
                  </button>
                );
              })}
            </div>
          </div>
          <div className="flex gap-6">
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.is_vegetarian} onChange={(e) => setForm({ ...form, is_vegetarian: e.target.checked })} className="accent-[#AF8B45]" /> Vegetarian</label>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.is_popular} onChange={(e) => setForm({ ...form, is_popular: e.target.checked })} className="accent-[#AF8B45]" /> Popular</label>
          </div>
          <button type="submit" disabled={saving} className="w-full bg-[#AF8B45] text-[#1A322B] h-11 rounded font-semibold disabled:opacity-50">{saving ? 'Adding…' : 'Add Item'}</button>
        </form>
      </div>
    </div>
  );
}