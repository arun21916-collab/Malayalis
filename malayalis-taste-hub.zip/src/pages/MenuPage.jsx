import React, { useEffect, useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Search, Leaf, X, Flame, Sparkles, Clock } from 'lucide-react';
import MenuItemCard from '@/components/MenuItemCard';
import Footer from '@/components/Footer';
import usePullToRefresh from '@/hooks/use-pull-to-refresh';
import PullToRefreshIndicator from '@/components/PullToRefreshIndicator';

const HIGHLIGHTS = [
  { key: 'Popular', label: 'Popular', icon: Flame },
  { key: 'New Arrivals', label: 'New Arrivals', icon: Clock },
  { key: "Chef's Recommendations", label: "Chef's Recommendations", icon: Sparkles },
];

export default function MenuPage() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [vegOnly, setVegOnly] = useState(false);
  const [activeCat, setActiveCat] = useState('All');
  const [highlight, setHighlight] = useState('All');
  const [searchParams] = useSearchParams();

  const [reviews, setReviews] = useState([]);

  const loadReviews = async () => {
    try {
      const r = await base44.entities.Review.list('-created_date', 500);
      setReviews(r);
    } catch (e) {
      // ignore
    }
  };

  const refresh = async () => {
    try {
      const [data, revs] = await Promise.all([
        base44.entities.MenuItem.list('display_order', 300),
        base44.entities.Review.list('-created_date', 500),
      ]);
      setItems(data);
      setReviews(revs);
    } catch (e) {
      // ignore
    }
  };

  const refreshing = usePullToRefresh(refresh);

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.MenuItem.list('display_order', 300);
        setItems(data);
        const cat = searchParams.get('cat');
        if (cat) setActiveCat(cat);
        loadReviews();
      } catch (e) {
        // ignore
      } finally {
        setLoading(false);
      }
    })();
  }, [searchParams]);

  const ratings = useMemo(() => {
    const map = {};
    reviews.forEach((r) => {
      if (!map[r.menu_item_id]) map[r.menu_item_id] = { sum: 0, count: 0 };
      map[r.menu_item_id].sum += r.rating;
      map[r.menu_item_id].count += 1;
    });
    const out = {};
    Object.keys(map).forEach((id) => {
      out[id] = { avg: map[id].sum / map[id].count, count: map[id].count };
    });
    return out;
  }, [reviews]);

  const reviewsByItem = useMemo(() => {
    const map = {};
    reviews.forEach((r) => {
      if (r.menu_item_id) {
        if (!map[r.menu_item_id]) map[r.menu_item_id] = [];
        map[r.menu_item_id].push(r);
      }
    });
    Object.keys(map).forEach((id) => {
      map[id].sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    });
    return map;
  }, [reviews]);

  const categories = useMemo(() => [...new Set(items.map((i) => i.category))], [items]);

  const filtered = useMemo(() => {
    let list = items.filter((i) => {
      if (activeCat !== 'All' && i.category !== activeCat) return false;
      if (vegOnly && !i.is_vegetarian) return false;
      if (search && !i.name.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
    if (highlight === 'Popular') {
      list = list.filter((i) => i.is_popular);
    } else if (highlight === "Chef's Recommendations") {
      list = list.filter((i) => (i.tags || []).includes("Chef's Special"));
    } else if (highlight === 'New Arrivals') {
      list = [...list]
        .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
        .slice(0, 12);
    }
    return list;
  }, [items, activeCat, search, vegOnly, highlight]);

  const grouped = useMemo(() => {
    const map = {};
    filtered.forEach((i) => {
      if (!map[i.category]) map[i.category] = [];
      map[i.category].push(i);
    });
    return map;
  }, [filtered]);

  return (
    <div className="bg-[#FDFBF7] min-h-screen">
      <PullToRefreshIndicator active={refreshing} />
      {/* header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-6">
        <p className="text-[#AF8B45] text-xs font-semibold tracking-[0.3em] uppercase">À La Carte</p>
        <h1 className="font-display text-4xl sm:text-5xl font-bold text-[#1A322B] mt-2">Our Menu</h1>
        <p className="text-[#1A322B]/60 mt-3 max-w-xl">
          The complete Malayalis menu — every dish prepared fresh to order.
        </p>
      </div>

      {/* search + filter bar */}
      <div className="sticky top-16 sm:top-20 z-30 bg-[#FDFBF7]/95 backdrop-blur border-y border-[#AF8B45]/15">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#1A322B]/40" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search dishes..."
              className="w-full h-11 pl-10 pr-10 rounded-full bg-white border border-[#AF8B45]/25 text-sm text-[#1A322B] focus:outline-none focus:border-[#AF8B45]"
            />
            {search && (
              <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2" aria-label="Clear">
                <X className="w-4 h-4 text-[#1A322B]/40" />
              </button>
            )}
          </div>
          <button
            onClick={() => setVegOnly(!vegOnly)}
            className={`flex items-center gap-2 h-11 px-4 rounded-full text-sm font-semibold border transition-colors whitespace-nowrap ${
              vegOnly
                ? 'bg-[#4A6741] text-white border-[#4A6741]'
                : 'bg-white text-[#1A322B] border-[#AF8B45]/25 hover:border-[#AF8B45]'
            }`}
          >
            <Leaf className="w-4 h-4" /> Veg Only
          </button>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-3 overflow-x-auto no-scrollbar">
          <div className="flex gap-2 min-w-max items-center mb-2">
            <span className="text-[10px] uppercase tracking-wide text-[#1A322B]/40 font-semibold pr-1 select-none">Highlights</span>
            {HIGHLIGHTS.map((h) => (
              <button
                key={h.key}
                onClick={() => setHighlight(highlight === h.key ? 'All' : h.key)}
                className={`flex items-center gap-1.5 px-4 h-9 rounded-full text-xs font-semibold uppercase tracking-wide whitespace-nowrap transition-colors select-none ${
                  highlight === h.key ? 'bg-[#AF8B45] text-[#1A322B]' : 'bg-white text-[#1A322B] border border-[#AF8B45]/25 hover:border-[#AF8B45]'
                }`}
              >
                <h.icon className="w-3.5 h-3.5" /> {h.label}
              </button>
            ))}
          </div>
          {highlight === 'All' && (
            <div className="flex gap-2 min-w-max">
              <button
                onClick={() => setActiveCat('All')}
                className={`px-4 h-9 rounded-full text-xs font-semibold uppercase tracking-wide whitespace-nowrap transition-colors ${
                  activeCat === 'All' ? 'bg-[#1A322B] text-[#FDFBF7]' : 'bg-white text-[#1A322B] border border-[#AF8B45]/25 hover:border-[#AF8B45]'
                }`}
              >
                All
              </button>
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCat(cat)}
                  className={`px-4 h-9 rounded-full text-xs font-semibold uppercase tracking-wide whitespace-nowrap transition-colors ${
                    activeCat === cat ? 'bg-[#1A322B] text-[#FDFBF7]' : 'bg-white text-[#1A322B] border border-[#AF8B45]/25 hover:border-[#AF8B45]'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* menu sections */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
        {loading ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="aspect-[4/3] bg-[#1A322B]/5 rounded animate-pulse" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <p className="text-center text-[#1A322B]/50 py-20 font-display text-lg">No dishes match your filters.</p>
        ) : highlight !== 'All' ? (
          <section>
            <div className="flex items-center gap-4 mb-6">
              <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#1A322B]">{highlight}</h2>
              <div className="flex-1 h-px bg-[#AF8B45]/30" />
              <span className="text-sm text-[#AF8B45] font-semibold">{filtered.length} items</span>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              {filtered.map((item) => (
                <MenuItemCard
                  key={item.id}
                  item={item}
                  reviews={reviewsByItem[item.id]}
                  ratingInfo={ratings[item.id]}
                  onReviewSubmitted={loadReviews}
                />
              ))}
            </div>
          </section>
        ) : (
          categories
            .filter((c) => grouped[c])
            .map((cat) => (
              <section key={cat} id={cat}>
                <div className="flex items-center gap-4 mb-6">
                  <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#1A322B]">{cat}</h2>
                  <div className="flex-1 h-px bg-[#AF8B45]/30" />
                  <span className="text-sm text-[#AF8B45] font-semibold">{grouped[cat].length} items</span>
                </div>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                  {grouped[cat].map((item) => (
                    <MenuItemCard
                      key={item.id}
                      item={item}
                      reviews={reviewsByItem[item.id]}
                      ratingInfo={ratings[item.id]}
                      onReviewSubmitted={loadReviews}
                    />
                  ))}
                </div>
              </section>
            ))
        )}
      </div>

      <div className="hidden md:block">
        <Footer />
      </div>
    </div>
  );
}