import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import OrderStatusTracker, { statusLabel } from '@/components/OrderStatusTracker';
import { Clock, MapPin, Store, Truck, CreditCard, Banknote, Landmark, Mail, Phone, ArrowLeft, Loader2, Search } from 'lucide-react';
import BankTransferTracker from '@/components/BankTransferTracker';
import MealReviewCard from '@/components/MealReviewCard';

export default function OrderTracking() {
  const { orderNumber } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsub;
    (async () => {
      try {
        const list = await base44.entities.Order.filter({ order_number: orderNumber });
        const o = list[0];
        setOrder(o);
        if (o) {
          // Auto-update whenever the restaurant changes the status
          unsub = base44.entities.Order.subscribe((event) => {
            if (event?.data?.id === o.id) setOrder(event.data);
          });
        }
      } catch (e) {
        // ignore
      } finally {
        setLoading(false);
      }
    })();
    return () => unsub && unsub();
  }, [orderNumber]);

  // Poll the restaurant manager app for status changes made by staff there.
  // Stops automatically once the order reaches a final state.
  useEffect(() => {
    if (!order || ['delivered', 'completed', 'cancelled'].includes(order.status)) return;
    const interval = setInterval(async () => {
      try {
        const res = await base44.functions.invoke('refresh_order_status', { order_number: orderNumber });
        if (res.data?.updated && res.data.status && res.data.status !== order.status) {
          setOrder((prev) => (prev ? { ...prev, status: res.data.status } : prev));
        }
      } catch (e) {
        // Polling is best-effort — ignore transient errors.
      }
    }, 20000);
    return () => clearInterval(interval);
  }, [order, orderNumber]);

  if (loading)
    return <div className="max-w-md mx-auto py-24 text-center text-[#1A322B]/50">Loading…</div>;

  if (!order)
    return (
      <div className="max-w-md mx-auto px-4 py-24 text-center">
        <Search className="w-10 h-10 text-[#AF8B45]/40 mx-auto" />
        <h1 className="font-display text-2xl font-bold text-[#1A322B] mt-4">Order not found</h1>
        <p className="text-[#1A322B]/60 mt-2">We couldn't find order #{orderNumber}.</p>
        <Link
          to="/menu"
          className="inline-flex mt-6 bg-[#1A322B] text-[#FDFBF7] px-6 h-12 rounded-full items-center font-semibold"
        >
          Back to Menu
        </Link>
      </div>
    );

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-10">
      <Link to="/" className="inline-flex items-center gap-1 text-sm text-[#1A322B]/60 hover:text-[#AF8B45] mb-6">
        <ArrowLeft className="w-4 h-4" /> Back home
      </Link>

      <div className="text-center mb-8">
        <p className="text-xs uppercase tracking-[0.25em] text-[#AF8B45] font-semibold">Order Tracking</p>
        <h1 className="font-display text-4xl font-bold text-[#1A322B] mt-2">#{order.order_number}</h1>
        <p className="text-sm text-[#1A322B]/60 mt-1">
          Placed {new Date(order.created_date).toLocaleString('en-IE', { dateStyle: 'medium', timeStyle: 'short' })}
        </p>
      </div>

      {/* Tracker card */}
      <div className="bg-[#1A322B] text-[#FDFBF7] rounded p-6 sm:p-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-xl font-bold">Order progress</h2>
          <span
            className={`text-xs font-semibold uppercase px-2.5 py-1 rounded-full border ${
              order.payment_status === 'paid'
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : order.payment_status === 'payment_rejected'
                ? 'bg-red-500/20 text-red-300 border-red-500/40'
                : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
            }`}
          >
            {order.status === 'cancelled' ? 'Cancelled' : `Payment: ${order.payment_status.replace(/_/g, ' ')}`}
          </span>
        </div>
        <OrderStatusTracker order={order} readOnly />
        <p className="text-center text-xs text-[#FDFBF7]/50 mt-6 flex items-center justify-center gap-1.5">
          <Loader2 className="w-3 h-3 animate-spin" /> This page updates automatically as your order progresses.
        </p>
      </div>

      {order.payment_method === 'bank_transfer' && (
        <div className="bg-white border border-[#AF8B45]/20 rounded p-6 mt-6">
          <h2 className="font-display text-lg font-bold text-[#1A322B] mb-4">Bank Transfer Payment</h2>
          <BankTransferTracker paymentStatus={order.payment_status} />
          <p className="text-xs text-[#1A322B]/55 mt-4">
            Payment status is synced from the central order system and cannot be changed here.
          </p>
        </div>
      )}

      {/* Details */}
      <div className="bg-white border border-[#AF8B45]/20 rounded p-6 mt-6 space-y-4">
        <div className="flex items-center gap-2 text-[#1A322B]">
          {order.order_type === 'delivery' ? <Truck className="w-4 h-4 text-[#AF8B45]" /> : <Store className="w-4 h-4 text-[#AF8B45]" />}
          <span className="text-sm font-semibold uppercase tracking-wide">
            {order.order_type === 'delivery' ? 'Delivery' : 'Pickup'}
          </span>
          <span className="text-xs text-[#1A322B]/55">
            {order.order_type === 'delivery' ? '· delivered to your address' : '· Pickup from Restaurant'}
          </span>
          <span className="text-sm text-[#1A322B]/40">·</span>
          <span className="text-sm text-[#1A322B]/70 flex items-center gap-1">
            {order.payment_method === 'card' ? <CreditCard className="w-3.5 h-3.5" /> : order.payment_method === 'bank_transfer' ? <Landmark className="w-3.5 h-3.5" /> : <Banknote className="w-3.5 h-3.5" />}
            {order.payment_method.replace('_', ' ')}
          </span>
        </div>
        <div className="text-sm text-[#1A322B]/80 space-y-1">
          <p className="font-semibold text-[#1A322B]">{order.customer_name}</p>
          <p className="flex items-center gap-1.5"><Phone className="w-3.5 h-3.5 text-[#AF8B45]" /> {order.mobile}</p>
          <p className="flex items-center gap-1.5"><Mail className="w-3.5 h-3.5 text-[#AF8B45]" /> {order.customer_email}</p>
          {order.order_type === 'delivery' && order.address && (
            <p className="flex items-start gap-1.5"><MapPin className="w-3.5 h-3.5 text-[#AF8B45] mt-0.5" /> {order.address}</p>
          )}
        </div>
        <div className="border-t border-[#AF8B45]/15 pt-3 space-y-2">
          {(order.items || []).map((it, i) => (
            <div key={i} className="flex justify-between text-sm">
              <span className="text-[#1A322B]">
                <span className="font-semibold text-[#AF8B45]">{it.quantity}×</span> {it.name}
              </span>
              <span className="text-[#1A322B]/70">€{it.subtotal.toFixed(2)}</span>
            </div>
          ))}
        </div>
        <div className="border-t border-[#AF8B45]/15 pt-3 flex justify-between font-display text-lg font-bold text-[#1A322B]">
          <span>Total</span>
          <span>€{(order.total ?? 0).toFixed(2)}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-[#1A322B]/70 pt-2 border-t border-[#AF8B45]/15">
          <Clock className="w-4 h-4 text-[#AF8B45]" /> Estimated time: {order.estimated_time}
        </div>
      </div>

      {['delivered', 'completed'].includes(order.status) && <MealReviewCard order={order} />}

      <div className="flex justify-center mt-8">
        <Link
          to="/menu"
          className="border border-[#AF8B45]/30 text-[#1A322B] px-6 h-12 rounded-full inline-flex items-center font-semibold hover:border-[#AF8B45]"
        >
          Order More
        </Link>
      </div>
    </div>
  );
}