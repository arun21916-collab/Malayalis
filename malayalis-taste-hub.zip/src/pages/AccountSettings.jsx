import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { UserCircle, Mail, AlertTriangle, Loader2, ArrowLeft } from 'lucide-react';

export default function AccountSettings() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [confirming, setConfirming] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    base44.auth
      .me()
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setLoading(false));
  }, []);

  const deleteAccount = async () => {
    setDeleting(true);
    setError('');
    try {
      const res = await base44.functions.invoke('delete_account', { confirm: 'DELETE' });
      if (res.data?.success === false) {
        setError(res.data.error || 'Could not delete your account.');
        setDeleting(false);
        return;
      }
      await base44.auth.logout('/');
    } catch (e) {
      setError(e.response?.data?.error || 'Could not delete your account. Please try again.');
      setDeleting(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto px-4 sm:px-6 py-10">
      <Link to="/" className="inline-flex items-center gap-1 text-sm text-[#1A322B]/60 hover:text-[#AF8B45] mb-6">
        <ArrowLeft className="w-4 h-4" /> Back to home
      </Link>
      <h1 className="font-display text-4xl font-bold text-[#1A322B] mb-2">Account Settings</h1>
      <p className="text-sm text-[#1A322B]/60 mb-8">Manage your MALAYALIS account.</p>

      {loading ? (
        <div className="text-center py-20 text-[#1A322B]/50">Loading…</div>
      ) : !user ? (
        <div className="text-center py-20">
          <p className="text-[#1A322B]/60 mb-4">You need to be signed in to view account settings.</p>
          <Link to="/login" className="inline-flex bg-[#1A322B] text-[#FDFBF7] px-6 h-12 rounded-full items-center font-semibold">
            Sign In
          </Link>
        </div>
      ) : (
        <>
          {/* Profile */}
          <div className="bg-white border border-[#AF8B45]/20 rounded p-6 mb-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-full bg-[#1A322B]/5 flex items-center justify-center">
                <UserCircle className="w-8 h-8 text-[#AF8B45]" />
              </div>
              <div className="min-w-0">
                <p className="font-display text-lg font-bold text-[#1A322B]">{user.full_name || 'MALAYALIS Member'}</p>
                <p className="text-sm text-[#1A322B]/60 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-[#AF8B45]" /> {user.email}
                </p>
              </div>
            </div>
          </div>

          {/* Danger zone */}
          <div className="bg-white border border-[#9E2A2B]/25 rounded p-6">
            <h2 className="font-display text-lg font-bold text-[#9E2A2B] flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" /> Delete Account
            </h2>
            <p className="text-sm text-[#1A322B]/60 mt-2">
              Permanently delete your account and sign-in access. This cannot be undone.
            </p>

            {confirming ? (
              <div className="mt-4 p-4 rounded bg-[#9E2A2B]/5 border border-[#9E2A2B]/25">
                <p className="text-sm font-semibold text-[#9E2A2B]">Are you absolutely sure?</p>
                <p className="text-xs text-[#1A322B]/60 mt-1">
                  Your account will be removed immediately and you will be signed out.
                </p>
                {error && <p className="text-sm text-[#9E2A2B] mt-2">{error}</p>}
                <div className="flex flex-col sm:flex-row gap-2 mt-4">
                  <button
                    onClick={deleteAccount}
                    disabled={deleting}
                    className="flex-1 h-11 rounded bg-[#9E2A2B] text-white text-sm font-semibold hover:bg-[#7E2223] disabled:opacity-50 flex items-center justify-center gap-2 select-none"
                  >
                    {deleting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" /> Deleting…
                      </>
                    ) : (
                      'Yes, Delete My Account'
                    )}
                  </button>
                  <button
                    onClick={() => { setConfirming(false); setError(''); }}
                    disabled={deleting}
                    className="flex-1 h-11 rounded border border-[#1A322B]/20 text-sm font-semibold text-[#1A322B] hover:border-[#1A322B]/40 disabled:opacity-50 select-none"
                  >
                    Keep My Account
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setConfirming(true)}
                className="mt-4 h-11 px-5 rounded bg-[#9E2A2B] text-white text-sm font-semibold hover:bg-[#7E2223] select-none"
              >
                Delete My Account
              </button>
            )}
          </div>
        </>
      )}
    </div>
  );
}