import React, { useEffect, useState, useRef } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import {
  Landmark, Copy, Check, ArrowLeft, UploadCloud, ShieldCheck, Loader2, FileText, AlertCircle, CheckCircle2, Image as ImageIcon,
} from 'lucide-react';
import BankTransferTracker from '@/components/BankTransferTracker';

const ACCEPTED = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];

export default function BankTransfer() {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get('order');
  const [order, setOrder] = useState(null);
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(null);
  const [file, setFile] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const fileRef = useRef(null);

  const loadOrder = async () => {
    if (!orderId) { setLoading(false); return; }
    try {
      const o = await base44.entities.Order.get(orderId);
      setOrder(o);
    } catch (e) {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    base44.functions
      .invoke('get_public_settings')
      .then((res) => setSettings(res.data))
      .catch(() => setSettings({}));
    loadOrder();
  }, [orderId]);

  // Live updates so the customer sees confirmed/rejected automatically
  useEffect(() => {
    let unsub;
    if (order?.id) {
      unsub = base44.entities.Order.subscribe((event) => {
        if (event?.data?.id === order.id) setOrder(event.data);
      });
    }
    return () => unsub && unsub();
  }, [order?.id]);

  const copy = async (key, value) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(key);
      setTimeout(() => setCopied(null), 2000);
    } catch (e) {
      // ignore
    }
  };

  const maxBytes = (settings?.bank_proof_max_size_mb || 5) * 1024 * 1024;

  const onFileChange = (e) => {
    setError('');
    const f = e.target.files?.[0];
    if (!f) return setFile(null);
    const okType = ACCEPTED.includes(f.type) || /\.(jpg|jpeg|png|pdf)$/i.test(f.name);
    if (!okType) { setError('Only JPG, JPEG, PNG or PDF files are accepted.'); return; }
    if (f.size > maxBytes) { setError(`File is too large. Maximum ${settings?.bank_proof_max_size_mb || 5} MB.`); return; }
    setFile(f);
  };

  const submitProof = async () => {
    if (!file) { setError('Please upload your payment proof first.'); return; }
    if (!order) return;
    setSubmitting(true);
    setError('');
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const res = await base44.functions.invoke('submit_bank_proof', {
        order_id: order.id,
        proof_url: file_url,
      });
      if (res.data?.error) { setError(res.data.error); return; }
      setOrder((o) => ({ ...o, payment_status: 'proof_submitted', payment_proof_url: file_url }));
      setFile(null);
      if (fileRef.current) fileRef.current.value = '';
    } catch (err) {
      setError(err.response?.data?.error || 'Could not submit proof. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading)
    return <div className="max-w-md mx-auto py-24 text-center text-[#1A322B]/50">Loading…</div>;

  if (!order)
    return (
      <div className="max-w-md mx-auto px-4 py-24 text-center">
        <AlertCircle className="w-10 h-10 text-[#9E2A2B]/50 mx-auto" />
        <h1 className="font-display text-2xl font-bold text-[#1A322B] mt-4">Order not found</h1>
        <Link to="/menu" className="inline-flex mt-6 bg-[#1A322B] text-[#FDFBF7] px-6 h-12 rounded-full items-center font-semibold">
          Back to Menu
        </Link>
      </div>
    );

  const paid = order.payment_status === 'paid' || order.paid;
  const rejected = order.payment_status === 'payment_rejected';
  const proofSubmitted = ['proof_submitted', 'under_verification'].includes(order.payment_status);

  const bankFields = [
    { key: 'beneficiary', label: 'Beneficiary', value: settings?.bank_beneficiary_name },
    { key: 'iban', label: 'IBAN', value: settings?.bank_iban },
    { key: 'bic', label: 'BIC / SWIFT code', value: settings?.bank_bic },
    { key: 'bank', label: 'Bank Name & Address', value: settings?.bank_name && settings?.bank_address ? `${settings.bank_name}, ${settings.bank_address}` : settings?.bank_name || settings?.bank_address },
    { key: 'correspondent', label: 'Correspondent BIC', value: settings?.bank_correspondent_bic },
  ].filter((f) => f.value);

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8 pb-20">
      <Link to="/menu" className="inline-flex items-center gap-1 text-sm text-[#1A322B]/60 hover:text-[#AF8B45] mb-5">
        <ArrowLeft className="w-4 h-4" /> Back to menu
      </Link>

      <div className="text-center mb-6">
        <div className="w-14 h-14 rounded-full bg-[#1A322B] flex items-center justify-center mx-auto">
          <Landmark className="w-7 h-7 text-[#AF8B45]" />
        </div>
        <h1 className="font-display text-3xl font-bold text-[#1A322B] mt-4">Bank Transfer</h1>
        <p className="text-sm text-[#1A322B]/55 mt-1">For local and international transfers</p>
      </div>

      {/* Status banner */}
      {paid ? (
        <div className="mb-6 p-4 rounded bg-[#4A6741]/10 border border-[#4A6741]/30 flex items-center gap-3">
          <CheckCircle2 className="w-6 h-6 text-[#4A6741] flex-shrink-0" />
          <div>
            <p className="font-display text-base font-bold text-[#4A6741]">Bank transfer payment confirmed ✓</p>
            <p className="text-xs text-[#1A322B]/70">Your payment has been verified. Your order is now being prepared.</p>
          </div>
        </div>
      ) : rejected ? (
        <div className="mb-6 p-4 rounded bg-[#9E2A2B]/10 border border-[#9E2A2B]/30 flex items-center gap-3">
          <AlertCircle className="w-6 h-6 text-[#9E2A2B] flex-shrink-0" />
          <div>
            <p className="font-display text-base font-bold text-[#9E2A2B]">Payment could not be verified</p>
            <p className="text-xs text-[#1A322B]/70">Your bank transfer could not be verified. Please contact the restaurant or upload valid payment proof.</p>
          </div>
        </div>
      ) : proofSubmitted ? (
        <div className="mb-6 p-4 rounded bg-amber-50 border border-amber-200 flex items-center gap-3">
          <ShieldCheck className="w-6 h-6 text-amber-600 flex-shrink-0" />
          <div>
            <p className="font-display text-base font-bold text-amber-700">Payment verification pending</p>
            <p className="text-xs text-[#1A322B]/70">Order status: <span className="font-semibold uppercase">Payment Under Verification</span></p>
          </div>
        </div>
      ) : null}

      {/* Tracker */}
      <div className="bg-white border border-[#AF8B45]/20 rounded p-5 mb-6">
        <BankTransferTracker paymentStatus={order.payment_status} />
      </div>

      {/* Bank details */}
      <div className="bg-white border border-[#AF8B45]/20 rounded p-5 mb-6">
        <h2 className="font-display text-lg font-bold text-[#1A322B] mb-1">Bank Details</h2>
        <p className="text-xs text-[#1A322B]/55 mb-4">Transfer the exact amount below to these account details.</p>
        <div className="space-y-3">
          {bankFields.map((f) => (
            <div key={f.key} className="border border-[#AF8B45]/15 rounded p-3">
              <p className="text-[10px] uppercase tracking-wide text-[#1A322B]/50 font-semibold">{f.label}</p>
              <div className="flex items-center justify-between gap-3 mt-1">
                <p className="text-sm font-semibold text-[#1A322B] break-all">{f.value}</p>
                <button
                  type="button"
                  onClick={() => copy(f.key, f.value)}
                  className="flex items-center gap-1 px-2.5 h-8 rounded-full bg-[#1A322B] text-[#FDFBF7] text-[10px] font-semibold uppercase tracking-wide flex-shrink-0 hover:bg-[#AF8B45] hover:text-[#1A322B] transition-colors select-none"
                >
                  {copied === f.key ? (
                    <><Check className="w-3 h-3" /> Copied</>
                  ) : (
                    <><Copy className="w-3 h-3" /> Copy</>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Amount + reference */}
      <div className="bg-[#1A322B] text-[#FDFBF7] rounded p-5 mb-6">
        <div className="flex items-center justify-between pb-3 border-b border-[#AF8B45]/25">
          <span className="text-xs uppercase tracking-wide text-[#FDFBF7]/60">Amount to transfer</span>
          <span className="font-display text-2xl font-bold text-[#AF8B45]">€{(order.total ?? 0).toFixed(2)}</span>
        </div>
        <div className="flex items-center justify-between pt-3">
          <div>
            <p className="text-[10px] uppercase tracking-wide text-[#FDFBF7]/50">Order ID / Payment Reference</p>
            <p className="font-display text-xl font-bold text-[#FDFBF7] mt-0.5">#{order.order_number}</p>
          </div>
          <button
            type="button"
            onClick={() => copy('ref', order.order_number)}
            className="flex items-center gap-1 px-3 h-9 rounded-full bg-[#AF8B45] text-[#1A322B] text-[10px] font-semibold uppercase tracking-wide hover:bg-[#FDFBF7] transition-colors select-none"
          >
            {copied === 'ref' ? <><Check className="w-3.5 h-3.5" /> Copied</> : <><Copy className="w-3.5 h-3.5" /> Copy</>}
          </button>
        </div>
        <p className="text-xs text-[#FDFBF7]/70 mt-3">
          {settings?.bank_payment_instructions || 'Please use this Order ID as your bank transfer payment reference.'}
        </p>
      </div>

      {/* Upload proof */}
      {!paid && (
        <div className="bg-white border border-[#AF8B45]/20 rounded p-5">
          <h2 className="font-display text-lg font-bold text-[#1A322B] mb-1">Upload Payment Proof</h2>
          <p className="text-xs text-[#1A322B]/55 mb-4">
            After making the transfer, upload your proof of payment (JPG, JPEG, PNG or PDF · max {settings?.bank_proof_max_size_mb || 5} MB).
          </p>

          {order.payment_proof_url && proofSubmitted && (
            <div className="mb-3 flex items-center gap-2 text-xs text-[#4A6741] bg-[#4A6741]/10 border border-[#4A6741]/30 rounded p-2.5">
              <CheckCircle2 className="w-4 h-4" /> Proof submitted — awaiting restaurant verification.
            </div>
          )}

          <label className="block border-2 border-dashed border-[#AF8B45]/30 rounded p-6 text-center cursor-pointer hover:border-[#AF8B45] transition-colors">
            <input
              ref={fileRef}
              type="file"
              accept=".jpg,.jpeg,.png,.pdf,image/jpeg,image/png,application/pdf"
              onChange={onFileChange}
              className="hidden"
            />
            {file ? (
              <div className="flex items-center justify-center gap-2 text-sm text-[#1A322B]">
                {file.type === 'application/pdf' ? <FileText className="w-5 h-5 text-[#AF8B45]" /> : <ImageIcon className="w-5 h-5 text-[#AF8B45]" />}
                <span className="font-semibold">{file.name}</span>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-1.5">
                <UploadCloud className="w-8 h-8 text-[#AF8B45]/60" />
                <span className="text-sm font-semibold text-[#1A322B]">Tap to upload payment proof</span>
                <span className="text-[11px] text-[#1A322B]/45">JPG, JPEG, PNG or PDF</span>
              </div>
            )}
          </label>

          {error && <p className="text-sm text-[#9E2A2B] mt-3">{error}</p>}

          <button
            type="button"
            onClick={submitProof}
            disabled={submitting || !file}
            className="w-full bg-[#1A322B] text-[#FDFBF7] h-12 rounded-full font-semibold mt-4 disabled:opacity-50 hover:bg-[#AF8B45] hover:text-[#1A322B] transition-colors flex items-center justify-center gap-2 select-none"
          >
            {submitting ? <><Loader2 className="w-4 h-4 animate-spin" /> Submitting…</> : <><UploadCloud className="w-4 h-4" /> Submit Payment Proof</>}
          </button>
        </div>
      )}

      <div className="flex flex-wrap gap-3 mt-6 justify-center">
        <Link
          to={`/track/${order.order_number}`}
          className="border border-[#AF8B45]/30 text-[#1A322B] px-6 h-12 rounded-full inline-flex items-center font-semibold hover:border-[#AF8B45]"
        >
          Track My Order
        </Link>
        {paid && (
          <Link
            to="/menu"
            className="bg-[#1A322B] text-[#FDFBF7] px-6 h-12 rounded-full inline-flex items-center font-semibold"
          >
            Order More
          </Link>
        )}
      </div>
    </div>
  );
}