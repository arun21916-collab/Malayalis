import React, { useEffect, useState } from 'react';
import { useLocation, useSearchParams, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useCart } from '@/context/CartContext';
import { CheckCircle2, Clock, MapPin, Store, Truck, Loader2, CreditCard, Banknote, Landmark, ShieldCheck, Mail, Phone, AlertCircle } from 'lucide-react';

export default function OrderConfirmation() {
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const orderId = location.state?.orderId || searchParams.get('order');
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const { clearCart } = useCart();

  // Clear the cart now that the order is placed/paid
  useEffect(() => {
    clearCart();
  }, [clearCart]);

  useEffect(() => {
    let unsub;
    (async () => {
      if (!orderId) {
        setLoading(false);
        return;
      }
      try {
        const o = await base44.entities.Order.get(orderId);
        setOrder(o);
        // Live updates if payment confirmation / status changes arrive
        unsub = base44.entities.Order.subscribe((event) => {
          if (event?.data?.id === orderId) setOrder(event.data);
        });
      } catch (e) {
        // ignore
      } finally {
        setLoading(false);
      }
    })();
    return () => unsub && unsub();
  }, [orderId]);

  if (loading)
    return <div className="max-w-md mx-auto py-24 text-center text-[#1A322B]/50">Loading…</div>;

  if (!order)
    return (
      <div className="max-w-md mx-auto px-4 py-24 text-center">
        <h1 className="font-display text-2xl font-bold text-[#1A322B]">Order not found</h1>
        <Link
          to="/menu"
          className="inline-flex mt-4 bg-[#1A322B] text-[#FDFBF7] px-6 h-12 rounded-full items-center font-semibold"
        >
          Back to Menu
        </Link>
      </div>
    );

  const isCard = order.payment_method === 'card';
  const isBank = order.payment_method === 'bank_transfer';
  const awaitingPayment = isCard && order.payment_status === 'pending';
  const paymentFailed = order.payment_status === 'failed';
  const bankPending = isBank && ['pending_transfer', 'proof_submitted', 'under_verification'].includes(order.payment_status);
  const bankRejected = isBank && order.payment_status === 'payment_rejected';

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-12">
      <div className="text-center mb-10">
        {awaitingPayment ? (
          <>
            <div className="w-20 h-20 rounded-full bg-[#AF8B45]/15 flex items-center justify-center mx-auto">
              <Loader2 className="w-10 h-10 text-[#AF8B45] animate-spin" />
            </div>
            <h1 className="font-display text-3xl font-bold text-[#1A322B] mt-6">Confirming your payment…</h1>
            <p className="text-[#1A322B]/60 mt-2">We're verifying your payment with our secure provider.</p>
          </>
        ) : paymentFailed ? (
          <>
            <div className="w-20 h-20 rounded-full bg-[#9E2A2B]/15 flex items-center justify-center mx-auto">
              <AlertCircle className="w-10 h-10 text-[#9E2A2B]" />
            </div>
            <h1 className="font-display text-3xl font-bold text-[#1A322B] mt-6">Payment failed</h1>
            <p className="text-[#1A322B]/60 mt-2">Your payment could not be processed. Please try again.</p>
          </>
        ) : bankPending ? (
          <>
            <div className="w-20 h-20 rounded-full bg-amber-100 flex items-center justify-center mx-auto">
              <ShieldCheck className="w-10 h-10 text-amber-600" />
            </div>
            <h1 className="font-display text-3xl font-bold text-[#1A322B] mt-6">Payment under verification</h1>
            <p className="text-[#1A322B]/60 mt-2">We're verifying your bank transfer. Your order begins once confirmed.</p>
            <Link to={`/bank-transfer?order=${order.id}`} className="inline-flex mt-5 bg-[#1A322B] text-[#FDFBF7] px-6 h-12 rounded-full items-center font-semibold gap-2">
              <Landmark className="w-4 h-4" /> Bank Transfer Details
            </Link>
          </>
        ) : bankRejected ? (
          <>
            <div className="w-20 h-20 rounded-full bg-[#9E2A2B]/15 flex items-center justify-center mx-auto">
              <AlertCircle className="w-10 h-10 text-[#9E2A2B]" />
            </div>
            <h1 className="font-display text-3xl font-bold text-[#1A322B] mt-6">Payment could not be verified</h1>
            <p className="text-[#1A322B]/60 mt-2">Please contact the restaurant or upload valid payment proof.</p>
            <Link to={`/bank-transfer?order=${order.id}`} className="inline-flex mt-5 bg-[#1A322B] text-[#FDFBF7] px-6 h-12 rounded-full items-center font-semibold gap-2">
              <Landmark className="w-4 h-4" /> Re-upload Payment Proof
            </Link>
          </>
        ) : (
          <>
            <div className="w-20 h-20 rounded-full bg-[#4A6741]/15 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10 text-[#4A6741]" />
            </div>
            <h1 className="font-display text-4xl font-bold text-[#1A322B] mt-6">Thank you for your order!</h1>
            <p className="text-[#1A322B]/60 mt-2">Your delicious Kerala feast is being prepared.</p>
          </>
        )}
      </div>

      {/* Receipt */}
      <div className="bg-white border border-[#AF8B45]/20 rounded p-6 sm:p-8">
        <div className="text-center pb-5 border-b border-[#AF8B45]/15">
          <p className="font-display text-2xl font-bold text-[#1A322B]">
            MALAYA<span className="text-[#AF8B45]">LIS</span>
          </p>
          <p className="text-[11px] uppercase tracking-[0.25em] text-[#1A322B]/45 mt-1">Order Receipt</p>
        </div>

        <div className="flex items-center justify-between py-4 border-b border-[#AF8B45]/15">
          <div>
            <p className="text-xs uppercase tracking-wide text-[#1A322B]/50">Order Number</p>
            <p className="font-display text-2xl font-bold text-[#AF8B45]">#{order.order_number}</p>
          </div>
          <div className="text-right">
            <p className="text-xs uppercase tracking-wide text-[#1A322B]/50">Date &amp; Time</p>
            <p className="text-sm font-semibold text-[#1A322B]">
              {new Date(order.created_date).toLocaleString('en-IE', { dateStyle: 'medium', timeStyle: 'short' })}
            </p>
          </div>
        </div>

        {/* Customer */}
        <div className="py-4 border-b border-[#AF8B45]/15 space-y-1.5">
          <p className="text-xs uppercase tracking-wide text-[#1A322B]/50 mb-2">Customer</p>
          <p className="text-sm font-semibold text-[#1A322B]">{order.customer_name}</p>
          <p className="text-sm text-[#1A322B]/70 flex items-center gap-1.5">
            <Mail className="w-3.5 h-3.5 text-[#AF8B45]" /> {order.customer_email}
          </p>
          <p className="text-sm text-[#1A322B]/70 flex items-center gap-1.5">
            <Phone className="w-3.5 h-3.5 text-[#AF8B45]" /> {order.mobile}
          </p>
          <p className="text-sm text-[#1A322B]/70 flex items-center gap-1.5 mt-1">
            {order.order_type === 'delivery' ? <Truck className="w-3.5 h-3.5 text-[#AF8B45]" /> : <Store className="w-3.5 h-3.5 text-[#AF8B45]" />}
            <span className="font-semibold uppercase tracking-wide text-[#1A322B]">
              {order.order_type === 'delivery' ? 'Delivery' : 'Pickup'}
            </span>
            <span className="text-[#1A322B]/60">
              {order.order_type === 'delivery' ? '— delivered to your address' : '— Pickup from Restaurant'}
            </span>
          </p>
          {order.order_type === 'delivery' && order.address && (
            <p className="text-sm text-[#1A322B]/70 flex items-start gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#AF8B45] mt-0.5" /> {order.address}
            </p>
          )}
        </div>

        {/* Items */}
        <div className="py-4 border-b border-[#AF8B45]/15">
          <p className="text-xs uppercase tracking-wide text-[#1A322B]/50 mb-3">Ordered Items</p>
          <div className="space-y-2">
            {(order.items || []).map((it, i) => (
              <div key={i} className="flex justify-between text-sm">
                <span className="text-[#1A322B]">
                  <span className="font-semibold text-[#AF8B45]">{it.quantity}×</span> {it.name}{' '}
                  <span className="text-[#1A322B]/45">· €{it.price.toFixed(2)} ea</span>
                </span>
                <span className="text-[#1A322B]/70">€{it.subtotal.toFixed(2)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Totals */}
        <div className="py-4 border-b border-[#AF8B45]/15 space-y-2 text-sm">
          <div className="flex justify-between text-[#1A322B]/70">
            <span>Subtotal</span>
            <span>€{(order.subtotal ?? order.total ?? 0).toFixed(2)}</span>
          </div>
          {order.order_type === 'delivery' && (
            <div className="flex justify-between text-[#1A322B]/70">
              <span>Delivery Fee</span>
              <span>€{(order.delivery_fee ?? 0).toFixed(2)}</span>
            </div>
          )}
          {(order.discount || 0) > 0 && (
            <div className="flex justify-between text-[#1A322B]/70">
              <span>Discount</span>
              <span>−€{(order.discount ?? 0).toFixed(2)}</span>
            </div>
          )}
          <div className="flex justify-between font-display text-xl font-bold text-[#1A322B] pt-2">
            <span>Total</span>
            <span>€{(order.total ?? 0).toFixed(2)}</span>
          </div>
        </div>

        {/* Payment */}
        <div className="py-4 border-b border-[#AF8B45]/15 flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-[#1A322B]">
            {isCard ? <CreditCard className="w-4 h-4 text-[#AF8B45]" /> : isBank ? <Landmark className="w-4 h-4 text-[#AF8B45]" /> : <Banknote className="w-4 h-4 text-[#AF8B45]" />}
            <span className="capitalize">{order.payment_method.replace('_', ' ')} payment</span>
          </div>
          <span
            className={`text-xs font-semibold uppercase px-2.5 py-1 rounded-full border ${
              order.payment_status === 'paid'
                ? 'bg-emerald-500/10 text-emerald-700 border-emerald-500/30'
                : order.payment_status === 'failed' || order.payment_status === 'payment_rejected'
                ? 'bg-red-500/10 text-red-700 border-red-500/30'
                : order.payment_status === 'refunded'
                ? 'bg-zinc-500/10 text-zinc-700 border-zinc-500/30'
                : 'bg-amber-500/10 text-amber-700 border-amber-500/30'
            }`}
          >
            {order.payment_status.replace(/_/g, ' ')}
          </span>
        </div>

        <div className="pt-4 flex items-center gap-3 text-[#1A322B]/70">
          <Clock className="w-5 h-5 text-[#AF8B45]" />
          <div>
            <p className="text-sm font-semibold text-[#1A322B]">Estimated time</p>
            <p className="text-sm">{order.estimated_time}</p>
          </div>
        </div>
        {order.notes && (
          <p className="mt-3 text-sm text-[#1A322B]/70 italic">Notes: "{order.notes}"</p>
        )}
      </div>

      <div className="flex flex-wrap gap-3 mt-8 justify-center">
        <Link
          to={`/track/${order.order_number}`}
          className="bg-[#1A322B] text-[#FDFBF7] px-6 h-12 rounded-full inline-flex items-center font-semibold"
        >
          Track My Order
        </Link>
        <Link
          to="/menu"
          className="border border-[#AF8B45]/30 text-[#1A322B] px-6 h-12 rounded-full inline-flex items-center font-semibold hover:border-[#AF8B45]"
        >
          Order More
        </Link>
      </div>
    </div>
  );
}