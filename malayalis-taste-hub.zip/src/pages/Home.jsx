import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Image } from '@/components/ui/image';
import {
  ArrowRight,
  UtensilsCrossed,
  Coffee,
  Fish,
  Beef,
  Drumstick,
  Soup,
  Salad,
  Cookie,
  GlassWater,
  Flame,
} from 'lucide-react';
import MenuItemCard from '@/components/MenuItemCard';
import Footer from '@/components/Footer';

const HERO = 'https://media.base44.com/images/public/6a8593a0114fede240a9979c/cda3053ac_generated_ed5bdf7f.png';

const CATEGORY_ICONS = {
  Hot: Coffee,
  Juice: GlassWater,
  Snacks: Cookie,
  Breakfast: UtensilsCrossed,
  Chinese: Flame,
  Vegetables: Salad,
  'Chicken Variety': Drumstick,
  'Beef Variety': Beef,
  Seafood: Fish,
  'Fry & Dry': Flame,
  'Fried Rice': UtensilsCrossed,
  Lunch: UtensilsCrossed,
  Soup: Soup,
  'Soft Drinks': GlassWater,
  Water: GlassWater,
};

export default function Home() {
  const [popular, setPopular] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const items = await base44.entities.MenuItem.list('display_order', 300);
        setPopular(items.filter((i) => i.is_popular && i.available && !i.sold_out).slice(0, 8));
        setCategories([...new Set(items.map((i) => i.category))]);
      } catch (e) {
        // ignore
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <div className="bg-[#FDFBF7]">
      {/* Hero */}
      <section className="relative h-[85vh] min-h-[600px] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <Image src={HERO} alt="Malabar feast" className="w-full h-full object-cover" fittingType="fill" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#1A322B]/90 via-[#1A322B]/60 to-transparent" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-xl">
            <p className="text-[#AF8B45] text-sm font-semibold tracking-[0.3em] uppercase mb-4">
              Authentic Kerala · Malabar Coast
            </p>
            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold text-[#FDFBF7] leading-[1.05]">
              The Soul of
              <br />
              Malabar, Served.
            </h1>
            <p className="mt-6 text-lg text-[#FDFBF7]/85 leading-relaxed max-w-md">
              From smoky beef varattu to fragrant Malabar biriyani — experience the spice-laden heritage of God's Own
              Country, crafted the traditional way.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link
                to="/menu"
                className="inline-flex items-center gap-2 bg-[#AF8B45] text-[#1A322B] px-7 h-14 rounded-full font-semibold tracking-wide hover:bg-[#FDFBF7] transition-colors"
              >
                Order Now <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/menu"
                className="inline-flex items-center gap-2 border border-[#FDFBF7]/40 text-[#FDFBF7] px-7 h-14 rounded-full font-semibold tracking-wide hover:bg-[#FDFBF7]/10 transition-colors"
              >
                View Menu
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Welcome */}
      <section className="max-w-3xl mx-auto px-4 sm:px-6 py-20 text-center">
        <p className="text-[#AF8B45] text-xs font-semibold tracking-[0.3em] uppercase mb-4">Namaskaram</p>
        <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#1A322B] leading-tight">
          A warm welcome to Malayalis
        </h2>
        <div className="w-16 h-px bg-[#AF8B45] mx-auto my-6" />
        <p className="text-[#1A322B]/70 text-lg leading-relaxed">
          Step into the flavours of the Malabar coast. Every dish is a tribute to generations of Kerala home cooking —
          slow-simmered curries, charcoal-grilled meats, and the unmistakable aroma of roasted coconut and curry leaves.
        </p>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="text-center mb-10">
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#1A322B]">Explore Our Kitchen</h2>
          <p className="text-[#1A322B]/60 mt-2">From the first cup of chai to the last spoon of biriyani</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {categories.map((cat) => {
            const Icon = CATEGORY_ICONS[cat] || UtensilsCrossed;
            return (
              <Link
                key={cat}
                to={`/menu?cat=${encodeURIComponent(cat)}`}
                className="group flex flex-col items-center justify-center gap-3 p-6 rounded bg-white border border-[#AF8B45]/15 hover:border-[#AF8B45] hover:shadow-md transition-all"
              >
                <div className="w-12 h-12 rounded-full bg-[#1A322B]/5 flex items-center justify-center group-hover:bg-[#AF8B45]/15 transition-colors">
                  <Icon className="w-6 h-6 text-[#1A322B] group-hover:text-[#AF8B45] transition-colors" />
                </div>
                <span className="text-xs font-semibold text-[#1A322B] text-center uppercase tracking-wide">{cat}</span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Popular */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="text-[#AF8B45] text-xs font-semibold tracking-[0.3em] uppercase mb-2">Guest Favourites</p>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#1A322B]">Popular Dishes</h2>
          </div>
          <Link
            to="/menu"
            className="hidden sm:inline-flex items-center gap-1 text-sm font-semibold text-[#1A322B] hover:text-[#AF8B45] transition-colors"
          >
            View all <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
        {loading ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="aspect-[4/3] bg-[#1A322B]/5 rounded animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {popular.map((item) => (
              <MenuItemCard key={item.id} item={item} />
            ))}
          </div>
        )}
      </section>

      <div className="hidden md:block">
        <Footer />
      </div>
    </div>
  );
}